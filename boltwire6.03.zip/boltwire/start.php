<?php

########################################
##  BOLTWIRE START SCRIPT             ##
##  Copyright 2019 Dan Vis            ##
##  See license.txt for details       ##
########################################

## USE THIS SCRIPT TO CREATE NEW SITES
## NAVIGATE TO SCRIPT AND FOLLOW ONSCREEN INSTRUCTIONS
## FOR DOCUMENTATION GO TO WWW.BOLTWIRE.COM

// SETUP MAIN VARS FROM INIT
if (file_exists('myinit.txt')) $content = getPage('myinit.txt');
elseif (file_exists('../myinit.txt')) $content = getPage('../myinit.txt');
elseif (file_exists('init.txt')) $content = getPage('init.txt');
else showPage('noinit');

list($params, $template, $notes) = explode('----', $content);
$template = trim($template);
$params = trim($params);
$lines = explode("\n", $params);
foreach($lines as $line) { 
	$parts = explode('=', $line);
	$args[$parts[0]] = $parts[1];
	}
$field = $args['field'];
$root = $args['root'];
$htcodes = $args['htcodes'];
if (file_exists($htcodes)) {
	$content = getPage($htcodes);
	$pass = trim($content);
	}
else $pass = '';

// MAIN SCRIPT CONTROLLING SITE CREATION
if ($pass == '') {
	if (! isset($_POST['password'])) showPage('welcome');
	else setPassword();
	}
elseif ($pass == crypt('false', 'false')) showPage('disabled');  
elseif (! isset($_POST['site'])) showPage('setup');
else {  
	setField($template);
	clearstatcache();
	showPage('complete');
	}
exit;


#############################################
## MISC UTILITIES USED
#############################################

function setField($template) {
	global $pass, $root, $field, $args;
	if (! isset($_POST['password']) || ! isset($_POST['site'])) showPage('setup');
	if ($pass != crypt($_POST['password'], $_POST['password'])) showPage('invalid');
	if (preg_match('/^[-_a-z0-9]+$/', $_POST['site']) == 0) showPage('siteid');
	$path = "$root/$field$_POST[site]";
	if (file_exists($path)) showPage('exists');
	mkdir($path);
	chmod($path, 0777);
	savePage("$path/index.php", $template);
	chmod("$path/index.php", 0666);
	if ($args['htaccess'] == 'true') {
		$content = "Options -Indexes +FollowSymLinks\nRewriteEngine On\nRewriteCond %{REQUEST_FILENAME} !-f\nRewriteRule ^(.+)$ index.php?p=$1 [QSA,L]";
		savePage("$path/.htaccess", $content);
		}
	return;
	}

function setPassword() {
	global $htcodes;
	$password = crypt($_POST['password'], $_POST['password']);
	if ($_POST['password'] == 'false') {
		savePage($htcodes, $password);
		showPage('disabled');
		}
	if (strlen($_POST['password']) < 8) showPage('error');
	savePage($htcodes, $password);
	showPage('setup');
	}

function showPage($p) {
	global $page;
	loadSitePages();	
	$head = "<html><body bgcolor=#c0c0c0 style='margin: 100px;'><table align=center bgcolor=white border=0 width=1000 cellpadding=50px cellspacing=0px><tr><td><font size=+2>";
	$foot = "</font></td></tr></table></body></html>";	
	print_r($head . $page[$p] . $foot);
	exit;
	}

function getPage($page) {
	$handle = fopen($page, "rb");
	$content = fread($handle, filesize($page));
	fclose($handle);
	return $content;
	}

function savePage($location, $content) {
	$handle = fopen($location, "wb");
   fwrite($handle, $content);
   fclose($handle);
	return;
	}

function pp($text) { print_r($text); die(); }  // used for debugging line


#############################################
## LOAD MISC PAGES USED
#############################################

function loadSitePages() {
global $page, $field;

$page['welcome'] = "<h1>Welcome to BoltWire</h1>
Your software is installed, and ready to help you create powerful interactive sites.<br><br>
To secure your installation, please enter a system password. It must contain at least eight characters. You will need this password each time you create a new site.<br><br>
To disable this script, and create your sites manually, set the password to 'false'.<br><br>
<form action='start.php' method='post'>Create password:&nbsp;&nbsp;&nbsp;<input type=password name=password> <input type=submit value='SUBMIT'></form>";

$page['error'] = "<h1>Password Error</h1>
Your password is too short. Please make sure it includes at least 8 characters.<br><br>
<a href='start.php'>Click here</a> to try again.";

$page['invalid'] = "<h1>Invalid Password</h1>
You must enter the correct system password to create a new site.<br><br>
<a href='start.php'>Click here</a> to try again.";

$page['siteid'] = "<h1>Invalid Site ID</h1>
Your site id included invalid characters.<br><br>
<a href='start.php'>Click here</a> to try again.";

$page['noinit'] = "<h1>Init File Not Found</h1>
We could not find a required init file to create your site.<br><br>
You may need to reinstall BoltWire. :(";

$page['exists'] = "<h1>Site Exists</h1>
A site already exists with this id. Please choose another.<br><br>
<a href='start.php'>Try again</a>";

$page['disabled'] = "<h1>Disabled</h1>
The site auto creator has been disabled for this installation of BoltWire.<br><br>
For information about how to restore this feature, please read the documentation at <a href='http://www.boltwire.com/docs/concepts/start'>www.boltwire.com</a>.";

$page['setup'] = "<h1>BoltWire Setup</h1>
Use this form to create a new site. We will configure your settings for you:<br>
<form action='start.php' method='post'><br>
<table cellpadding=3px cellspacing=0>
<tr><td>Password:</td><td><input type=password name='password'></td><td><i>Enter your system password here.</i></td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td>Site Id: </td><td><input type=text name='site'></td><td><i>Choose a site id--one word, no spaces, lower case.</i></td></tr>
</table><br>
<input type=submit value='Create Site'>
</form>";

if (isset($field) && isset($_POST['site'])) {
	$site = "http://$_SERVER[HTTP_HOST]/$field$_POST[site]/index.php";
	$page['complete'] = "<h1>Congratulations</h1>
Site successfully created. Click here to begin building your new site:<br><br>
<a href='$site'>$site</a><br><br>
Note: Be sure to setup your superadmin account promptly.";
	}
}