! Code Javascript
Use this page to construct small javascript snippets you can insert in forms and links, etc. This page must stay edit protected.

clear: onFocus="this.value='';"
jump: onChange='window.location.href=this.form.jump.options[this.form.jump.selectedIndex].value'
print: onClick='window.print(); return false;'
alert: onClick='alert("{+1}"); return false;'
skip: onBlur=this.form.{+1}.focus();
back: onClick='history.back();'