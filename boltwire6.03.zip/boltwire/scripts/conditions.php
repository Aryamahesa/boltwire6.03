<?php if (!defined('BOLTWIRE')) exit();

########################################
##  BOLTWIRE CONDITIONS               ##
##  Copyright 2019 Dan Vis            ##
##  See license.txt for details       ##
########################################


function BOLTCabort($args=[]) {
	global $BOLTcommands;
	if ($args[1] != '') return $BOLTcommands[$args[1]] == '~~ABORT~~';
	return in_array('~~ABORT~~', $BOLTcommands);
	}

function BOLTCaction($args=[]) {
	if ($_GET['action'] == $args[1]) return true;
	}

function BOLTCadmin($args=[]) {
	global $BOLTid;
	$id = BOLTinit($BOLTid, $args[1], $args['id']);
	return BOLTingroup('admin', $id);
	}

function BOLTCafter($args=[]) {
	global $BOLTtime;
	$when = BOLTinit($BOLTtime, $args['when']);
	$check = $args[1];
	if (! is_number($check)) $check = strtotime($check);
	if ($when > $check) return true;
	}

function BOLTCauth($args=[]) {
	if (empty($args)) return false;
	global $BOLTid, $pageLink;
	$type = BOLTinit($args['type'], $args[1]);
	if ($type == '') return false;
	$check = BOLTinit($pageLink, $args[2], $args['check']);
	$find = BOLTinit($BOLTid, $args[3], $args['find']);
	return BOLTauth($check, $find, $type);
	}	

function BOLTCbefore($args=[]) {
	global $BOLTtime;
	$when = BOLTinit($BOLTtime, $args['when']);
	$check = $args[1];
	if (! is_number($check)) $check = strtotime($check);
	if ($when < $check) return true;
	}

function BOLTCbetween($args=[]) {
	if (!isset($args[3])) return false;
	$test = Array($args[1], $args[2], $args[3]);
	sort($test);
	if ($args[2] == $test[1]) return true;
	}

function BOLTCeditor($args=[]) {
	global $BOLTid;
	$id = BOLTinit($BOLTid, $args[1], $args['id']);
	return BOLTingroup('editor', $id);
	}

function BOLTCequal($args=[]) {
	if (! isset($args[2])) return false;
	$test0 = BOLTurl2utf(trim($args[1]));
	$test1 = BOLTurl2utf(trim($args[2]));
	if ($args['case'] == 'false') return (strtolower($test0) == strtolower($test1));
	return ($test0 == $test1);
	}

function BOLTCexists($args=[]) {
	if (empty($args)) return false;
	global $pagesPath, $pluginPath;
	$page = $args[1];
	$dir = $args['dir'];
	if (isset($dir)) {
		if ($dir == 'plugins') return file_exists("$pluginPath/$page");
		if (strpos($dir, '..')) return false;
		}
	$page = BOLTpageshortcuts($page);
	if (! BOLTexists($page, $dir)) return false;
	return true;
	}

function BOLTCfalse($args=[]) {
	return false;
	}

function BOLTCfilter($args=[]) {
	$check = BOLTinit($args[1], $args['check']);
	$filter = BOLTinit($args[2], $args['filter']);
	$result = BOLTfilter($check, $filter);
	if ($result != '') return true;
	}

function BOLTCingroup($args=[]) {
	if (empty($args)) return false;
	global $BOLTid;
	$id = BOLTinit($BOLTid, $args[2], $args['id']);
	if (substr($id, 0, 7) == 'member.') $id = substr($id, 7);
	$groups = BOLTinit($args[1], $args['group']);
	$list = explode(',', $groups);
	foreach ($list as $group) {
		if (BOLTingroup($group, $id) == true) return true;
		}
	return false;
	}

function BOLTCinline($args=[]) {
	if (empty($args)) return false;
	global $BOLTid;
	$find = BOLTinit($BOLTid, $args[2], $args['find']);
	$find = trim($find);
	$line = BOLTinit($args[1], $args['line']);
	if ($args['case'] != 'true') {
		$line = strtolower($line);
		$find = strtolower($find);
		}
	if (strpos($line, $find) !== false) return true;
	}

function BOLTCinlist($args=[]) {
	if (empty($args)) return false;
	global $BOLTid;
	$find = BOLTinit($BOLTid, $args[2], $args['find']);
	$find = trim($find);
	$list = BOLTinit($args[1], $args['list']);
	if (isset($args['page'])) {
		if (BOLTexists($args['page'])) {
			$list = str_replace("\n", ',', BOLTloadpage($args['page']));
			}
		}
	if (isset($args['source'])) {
		$list = BOLTescape(BOLTFsource(array(1=>$args['source'])), false);
		$list = str_replace("\n", ',', $list);
		}
	$list = BOLTcsv($list);
	if ($args['case'] == 'false') {
		$list = strtolower($list);
		$find = strtolower($find);
		}
	return inlist($find, $list);
	}

function BOLTCinpage($args=[]) {
	global $pageLink, $BOLTid;
	$find = BOLTinit($BOLTid, $args[2], $args['find']);
	$page = BOLTinit($pageLink, $args[1], $args['page']);
	if ($args['data'] == 'true') $data = 'data';
	$content = BOLTloadpage($page, '', $data);
	if ($args['case'] == 'false') {
		$content = strtolower($content);
		$find = strtolower($find);
		}
	if (strpos($content, $find) !== false) return true;
	$find2 = BOLTurl2utf($find);
	if (strpos($content, $find2) !== false) return true;
	}

function BOLTCinsource($args=[]) {
	$data = BOLTescape(BOLTFsource($args), false);  // change to args[source]
	$find = BOLTinit($args[2], $args['find']);
	if ($find == '') return false;
	$find = str_replace('\n', "\n", $find);
	if ($args['case'] == 'false') {
		$data = strtolower($data);
		$find = strtolower($find);
		}
	if (strpos($data, $find) !== false) return true;
    return strpos($data, BOLTutf2url($find));
	}	

function BOLTCless($args=[]) {
	if (! isset($args[2])) return false;
	$test0 = trim($args[1]);
	$test1 = trim($args[2]);
	if (is_numeric($test0) && is_numeric($test1)) return $test0 < $test1;
	else if (strcasecmp($test0, $test1) < 0) return true;
	return false;
	}

function BOLTClogin($args=[]) {
	global $BOLTid;
	if ($BOLTid != '')return true;
	return false;
	}

function BOLTCmobile($args=[]) {
	global $BOLTmobile, $BOLTskin;
	if ($BOLTskin == 'mobile') return true;
	return $BOLTmobile;
	}

function BOLTCmore($args=[]) {
	if (! isset($args[2])) return false;
	$test0 = trim($args[1]);
	$test1 = trim($args[2]);
	if (is_number($test0) && is_number($test1)) return $test0 > $test1;
	else if (strcasecmp($test0, $test1) > 0) return true;
	return false;
	}

function BOLTCnew($args=[]) {
	if (empty($args)) return false;
	global $BOLTnewCond;
	$c = $args['name'];
//	if ($c == '') $type = count($BOLTnewCond); // should type be c?
	$i = $args[1];
	if (isset($BOLTnewCond[$c][$i])) return false;
	else $BOLTnewCond[$c][$i] = 'true';
	return true;
	}

function BOLTCnumber($args=[]) {
	if (empty($args)) return false;
	return is_number($args[1]);
	}

function BOLTCprint($args=[]) {
	global $BOLTskin;
	if ($BOLTskin == 'print') return true;
	}

function BOLTCset($args=[]) {
	if ($args['source'] != '') {
		$check = BOLTvars($args['source']);
		if ($check != '') return true;
		if (BOLTMrequest($args['source']) != '') return true;
		return false;
		}
	unset($args['switch']);
	if (! is_array($args) || implode('', $args) == '') return false;
	return true;
	}

function BOLTCskin($args=[]) {
	global $BOLTskin;
	if ($BOLTskin == $args[1]) return true;
	}

function BOLTCstamp($args=[]) {
	global $pageLink;
	$page = BOLTinit($pageLink, $args[1], $args['page']);
	$pat = "/^" . str_replace(".", "\.", $page) . "\.([0-9]+)$/";
	$list = BOLTlistpages($pat, 'stamps');
	if (count($list) > 0) return true;
	}

function BOLTCsubmit($args=[]) {
	if ($args[1] == '') return BOLTMrequest(array('1'=>'submit')); 
	if (BOLTMrequest(array('1'=>'submit')) == $args[1]) return true;
	return false;
	}

// NO LONGER NECESSARY -- DEPRECATE?
function BOLTCtime($args=[]) {
	global $BOLTtime;
	$check = BOLTinit($BOLTtime, $args[1]);
	if (preg_match('/^[0-9]{10}$/', $check) == 0) $check = strtotime($check);
	if (isset($args['after'])) {
		$after = $args['after'];
		if (preg_match('/^[0-9]{10}$/', $after) == 0) $after = strtotime($after);
		if ($check > $after) $ca = true;
		}
	if (isset($args['before'])) {
		$before = $args['before'];
		if (preg_match('/^[0-9]{10}$/', $before) == 0) $before = strtotime($before);
		if ($check < $before) $cb = true;
		}
	if ($ca && $cb) return true;
	if ($after == '' && $before == '') return false;
	if ($after == '') return $cb;
	if ($before == '') return $ca;
	}

function BOLTCtrue($args=[]) {
	return true;
	}