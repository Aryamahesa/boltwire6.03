<?php if (!defined('BOLTWIRE')) exit();

########################################
##  BOLTWIRE FUNCTIONS                ##
##  Copyright 2019 Dan Vis            ##
##  See license.txt for details       ##
########################################

function BOLTFbreadcrumb($args) {
	global $pageLink;
	$page = BOLTinit($pageLink, $args[1], $args['page']);
	$page = BOLTfilter(BOLTpageshortcuts($page), 'page');
	$separator = BOLTinit(' > ', $args['separator']);
	$parts = explode('.', $page);
	if ($args['missing'] != 'mark') $missing = '?';  // set missing=mark to hide ?... Seems strange...
	foreach ($parts as $p => $pp) {
		$link = ltrim("$link.$pp", '.');
		if ($args['text'] == 'true') $out[] = BOLTvars("$link:title");
		else {
			if (! BOLTexists($link)) {
				if ($args['missing'] == 'mark' || $args['missing'] == 'link') $out[] = "[[$missing$link|+]]";
				elseif($args['missing'] != 'none') $out[] = BOLTurl2utf(ucfirst($pp));
				}
			elseif ($args['short'] == 'true') $out[] = "[[$missing$link|" . BOLTurl2utf(ucfirst($pp)) . "]]";
			else $out[] = "[[$missing$link|+]]";
			}
		}
	$last = count($parts) - 1;
	switch ($args['name']) {
		case 'none': unset($out[$last]); break;
		case 'link': break;
		default:
			if ($args['short'] == 'true') $out[$last] = BOLTurl2utf(ucfirst($pp)); 
			else $out[$last] = BOLTvars("$page:title"); 
			break;
		}
	if (isset($args['offset'])) $out = array_slice($out, $args['offset']);
	if (strtolower($args['rtl']) == 'true' || strtolower(BOLTconfig('textDirection')) == 'rtl') {
	 	$out = array_reverse($out);
		$separator = str_replace('>', '<', $separator);
		}
	if (isset($args['limit']) && count($out) > $args['limit'] + 1) {
		if (! isset($args['final'])) $last = ' ... ' . $separator . $out[$last];
		elseif ($args['final'] == 'false' || $args['final'] == '') $last = $out[$last];
		else $last = $args['final'] . $separator . $out[$last];
		$out = array_slice($out, 0, $args['limit']);
		$out[] = $last;
		}
	$out = implode($separator, $out);
	return $out;
	}

function BOLTFcache($args) {
	global $BOLTcache, $BOLTzone, $BOLTtime;
	$mode = BOLTinit('html', $args[1], $args['mode']);
//	if (! inlist($mode, 'html,zone')) return;
	if ($mode == 'zone') $mode = "zone-$BOLTzone";
	$expires = BOLTinit(86400, $args[2], $args['expires']);
	$expires = $BOLTtime + $expires;
	$BOLTcache[$mode] = $expires;
	}

function BOLTFcounter($args) {
	global $BOLTfuncMem;
	$id = BOLTinit(0, $args['id']);
	if ($args[1] == 'show' || $args['show'] == 'true') return BOLTinit(0, $BOLTfuncMem['count'][$id]);	
	$start = BOLTinit(0, $BOLTfuncMem['count'][$id], $args['start']);
	$inc = BOLTinit(1, $args[1]);
	$inc = str_replace('$', '', $inc);
	$inc = str_replace('+', '', $inc);
	if (is_numeric($inc)) $BOLTfuncMem['count'][$id] = $start + $inc; 
	elseif (substr($inc, 0, 1) == '-') {
		$inc = substr($inc, 1);
		if (is_number($inc)) $BOLTfuncMem['count'][$id] = $start - $inc;
		else return BOLTmessage('counter_invalid', $args);
		}
	else return BOLTmessage('counter_invalid', $args);
	return $BOLTfuncMem['count'][$id];
	}

function BOLTFembed($args) {
	global $BOLTreplaceHTML;
	$code = $args[1];
	$out = BOLTloadpage("code.embed.$code");
	if ($out == '') return BOLTmessage('embed_missing', $args);	
	foreach ($args as $f => $v) $out = str_replace("{+$f}", $v, $out);  // {+field} args in form function
	$out = preg_replace_callback('/\\{\\+(\\w+)\\}/', function($m) { return BOLTvars($m[1]); }, $out);  // {+var} => {var} 
	if ($args[2] == 'head' || $args['header'] == 'true') {
		$BOLTreplaceHTML['find'][] = '</head>';
		$BOLTreplaceHTML['replace'][] = "$out\n</head>";
		}
	elseif ($args[2] == 'body' || $args['body'] == 'true') {
		$BOLTreplaceHTML['find'][] = '<body';
		$BOLTreplaceHTML['replace'][] = "<body $out ";
		}
	else return BOLTescape($out);
	}

function BOLTFforward($args) {
	global $BOLTsession, $pageLink;
	$to = BOLTinit($args[1], $args['url']);
	if ($to == '') return BOLTmessage('forward_missing', $args);
	$count = $BOLTsession['PASSFORM']['forwards'] + 1;
	if ($count > 4) return BOLTmessage('forward_loop', $args);
	else $BOLTsession['PASSFORM']['forwards'] = $count;
	BOLTmessage("func_forward::$pageLink::$args[1]", $args);
	BOLTredirect($to);
	}

function BOLTFgeturl($args, $zone='') {
	global $scriptURL, $cleanURL, $fieldURL, $pageLink;
	if (is_array($args)) $page = BOLTinit($pageLink, $args[1], $args['page']);
	else $page = $args;
	if ($cleanURL == '') return $scriptURL . $page;
	$parts = explode('.', $page);
	return $fieldURL . '/' . implode('/', $parts);
	}

function BOLTFhighlight($args) {
	$text = strtoupper(BOLTinit($args[1], $args['text']));
	$page = BOLTinit($args[2], $args['page']);
	if ($args['header'] !== 'false') $header = BOLTinit("[[$page|+]]", $args['header']);
	$content = BOLTinit($page, $args['content']);
	$content = BOLTloadpage($page);
	$lines = explode("\n", $content);
	foreach($lines as $line) {
		$line = BOLTstrip($line);
		if (preg_match("/\b($text)\b/i", $line) === 0) continue;
		if (strpos($line, '&lt;') !== false) continue;
		$out[] = '* ' . preg_replace("/\b($text)\b/i", "||$1||", $line);
		if (is_number($args['trim']) && count($out) >= $args['trim']) { $out[] = '* Additional matches found...'; break; }
		}
	if (count($out) != 0) return "<ul>$header\n" . implode("\n", $out) . '</ul>';
	}

function BOLTFinclude($args) {
	global $boltwire, $pageLink, $pageShow, $BOLTid, $systemPath, $BOLTzone, $BOLTincludes, $BOLTtime;
	if ($args['boltwire'] == 'license') return BOLTread("$boltwire/license.txt");
	$page = BOLTinit($args[1], $args['page']);
	if (inlist("$BOLTzone=$page=$args[loop]=$args[zone]", $BOLTincludes)) return BOLTmessage("include_loop::$page", $args); // prevents loops
	$BOLTincludes = "$BOLTincludes,$BOLTzone=$page=$args[loop]=$args[zone]";
	if (strpos($page, ':') !== false) {
		$data = substr($page, strpos($page, ':'));
		$page = substr($page, 0, strpos($page, ':'));
		}
	if (strpos($page, '#') !== false) {
		$anchor = substr($page, strpos($page, '#'));
		$page = substr($page, 0, strpos($page, '#'));
		}
	$page = BOLTpageshortcuts($page);
	if (BOLTfilter($page, 'page') == '') return BOLTmessage('include_missing', $args);
	if ($args['zone'] != '') $page = BOLTgetlink($args['zone'], '', $page);
	if (BOLTauth($page, $BOLTid, 'view') === false) return BOLTmessage("include_auth::$page", $args);
	if ($args['cache'] == 'true') {
		$cachePage = $page;
		if (BOLTconfig('cacheAllowed', 'false') == 'true' || is_number($args['expires'])) {
			$out = BOLTcache("cache.include.$cachePage");
			if ($out != '') return BOLTescape($out);
			}
		}
	if ($args['dir'] == 'system') $dir = $systemPath;
	if ($args['dir'] == 'stamps') $dir = 'stamps';
	if ($data != '') {
		$out = BOLTvars("$page$anchor$data");
		}
	else {
		$out = BOLTloadpage("$page$anchor", $dir);
		if (isset($args['lines'])) $out = BOLTgetlines($out, $args['lines']);
		}
	if ($args['order'] == 'reverse') {
		$lines = explode("\n", $out);
		$lines = array_reverse($lines);
		$out = implode("\n", $lines);
		}
	foreach ($args as $f => $v) $out = str_replace("{+$f}", $v, $out);  // vars available in form / function as args
	if (BOLTfilter($args['baselinks'], 'page') != '') {
        if ($args['baselinks'] == 'true') {
            $args['baselinks'] = $page;
            }
		$temp = $pageLink;
        $pageLink = $args['baselinks'];
        $out = BOLTescape(BOLTdomarkup($out, $args['baselinks'], '', $args['rules'], $args['vspace']), true, true);
        $pageLink = $temp;
        }
    else {
        $out = BOLTescape(BOLTdomarkup($out, '', '', $args['rules'], $args['vspace']), true, true);
        }		
	BOLTmessage("func_include::$page", $args);
	if ($out == '') return $args['default'];
	if ($args['cache'] == 'true' && is_number($args['expires'])) {
		$expires = $BOLTtime + $args['expires'];
		BOLTcacheSave("cache.include.$cachePage", $expires, BOLTescape($out, false));
		}
	return $out;
	}

function BOLTFindex($args) {
	if ($args['rule'] != '') $out = BOLTindex($args['rule'], $args['batch']);  // works through a rule if no list
	else {
		$count = BOLTinit(BOLTconfig('indexBatch', 25), $args[1], $args['cron']);
		if (is_number($count)) {
			$cron = BOLTinit('site.index.cron', BOLTconfig('indexCron'));
			$content = trim(BOLTloadpage($cron));
			if ($content == '') return BOLTmessage('index_current', $args);
			$pages = explode("\n", $content);
			$pages = array_unique($pages);
			if (count($pages) > $count) {
				$list = array_slice($pages, 0, $count);
				$content = implode("\n", array_slice($pages, $count));
				}
			else {
				$list = $pages;
				$content = ' ';
				}
			BOLTsavepage($cron, $content);
			}
		else {
			if ($count == '') return BOLTmessage('index_empty', $args);
			$list = explode(',', $count);
			}
		$out = BOLTindexAuto($list);  // indexes pages
		}
	BOLTmessage('index_complete', $args);
	return $out; 
	}

function BOLTFinfo($args, $auth=true) { //had unused strange "$data=false" as last parameter...
	global $pageLink, $BOLTpagecount, $BOLTid, $BOLTinfoVarPat;
	if (isset($args['exclude']) && inlist($pageLink, $args['exclude'])) return; // used to ignore header/footer pages
	if (isset($args['page'])) $page = BOLTpageshortcuts($args['page']);  // page to read from
	else $page = $pageLink;
	if ($auth && BOLTauth($page, $BOLTid, 'view') == false) return;
	$ext = BOLTinit($args[1], $args['ext']);
	if ($ext != '') {  // is #1 a call to an info processor?
		if (inlist($ext, 'random,exists,list,delete,count,sum,average,find,prev,next,first,last,counter,scheduler') || function_exists("BOLTinfo$ext")) {
			$func = $ext;
			$field = BOLTinit($args[1], $args[2], $args['field']);
			}
		else $field = BOLTinit($args[1], $args['field']);
		}
	else $field = BOLTinit($pageLink, $args['field']);
	$field = trim(BOLTurl2utf($field));
	if ($field == '#') $field = BOLTthread($page, true);
	else $field = str_replace(' ', '_', $field);
	$value = BOLTinit(NULL, $args[2], rtrim($args['value'], ' |'));
	if (isset($args['part'])) $part = $args['part'] - 1;
	if ($func == '') {  // don't use info processor
		if ($field == '') return;  // error, no info requested
		$current = BOLTinfoPeek($page, $field, $auth);
		if (isset($part)) {
			$parts = explode(' | ', $current);
			$out = $parts[$part];
			}
		else $out = $current;
		if ($value === NULL) {  // just field given, return value (was || $data)
			if ($args['lines'] != 'false') $out = str_replace('\n', "\n", $out);
			return BOLTinit($args['default'], $out);  // returns value for [(info field)]
			}
		// if field and value set, overwrite value
		if ($auth && BOLTauth($page, $BOLTid, 'info') === false && BOLTauth($page, $BOLTid, 'write') === false) return BOLTmessage("func_info_auth::$page", $args); // 
		if ($args['csv'] != 'false') {
			if (substr($value, 0, 1) == "+" || substr($value, 0, 1) == "-") {
				$value = BOLTcsv($value, $out); 
				}
			}
		if (isset($part)) {
			$parts = explode(' | ', $current);
			if ($part > count($parts)) {  // create place holders if needed
				for ($i=0; $i<=$part; $i++) $parts[$i] = $parts[$i];
				}
			$parts[$part] = $value;  // replace desired part
			$value = implode(' | ', $parts);
			}
		BOLTinfoPoke($page, $field, $value, $args['sort'], $auth);
		return;
		}
	else {  // these are the info processors
		$content = BOLTloadcontent($page, true);  // first load up info array
		if ($content != '') {
			$lines = explode("\n", $content);
			foreach ($lines as $i => $line) {
				$pos = strpos($line, ': ');
				$f = substr($line, 0, $pos);
				$ff = BOLTfilter($f, 'page');
				if ($ff != '') $info[$f] = substr($line, $pos + 2);
				$where[$f] = $i;
				}
			}
		if (empty($info)) $info = Array();
		$func2 = "BOLTinfo" . $func;
		if (function_exists($func2) && ! inlist($func, 'peek,poke,delete')) return $func2($info, $args, $page);
		switch($func) {
			case 'random' :
				if (is_number($args['count']) && $args['count'] != 1) $args[1] = implode(',', array_rand($info, $args['count']));
				else $args[1] = array_rand($info);
				if (! isset($args['fmt']) && ! isset($args['template'])) $args['template'] = '{'.$page.'::{+p}}';
				unset($args['msg']); unset($args['page']);
				if ($args['fmt'] == 'source' || $args['template'] == 'source') return BOLTescape($info[$args[1]]);			
				return BOLTFlist($args);
			case 'exists' :
				if (isset($info[$field])) return 'true';
				else return 'false';
			case 'list' :
				if ($args['value'] != 'true') $info = array_keys($info);
				if ($args['unique'] != 'false') $info = array_unique($info);
				$join = BOLTinit(',', $args['join']);
				return implode($join, $info);
			case 'delete' :
//				if ($data) return; // for data var processing
				if ($auth && BOLTauth($page, $BOLTid, 'info') === false && BOLTauth($page, $BOLTid, 'write') === false) return BOLTmessage("func_info_auth::$page", $args); // 
				unset($lines[$where[$field]]);
				if (empty($lines)) $content = ' ';
				else $content = implode("\n", $lines);
				BOLTsavecontent($page, $content);	
				return;
			case 'count' :
				return count($info);
			case 'sum' :
				$s = 0;
				foreach ($info as $i => $ii) {
					$ii = str_replace(',', '', $ii);
					$ii = str_replace('$', '', $ii);
					if (isset($part)) {
						$parts = explode(' | ', $ii);
						if (is_number($parts[$part])) $s = $s + $parts[$part];
						}
					elseif (is_number($ii)) $s = $s + $ii;
					}
				return $s;
			case 'average' : 
				$t = count($info);
				if ($t == 0) return 0;
				$s = 0;
				foreach ($info as $i => $ii) {
					$ii = str_replace(',', '', $ii);
					$ii = str_replace('$', '', $ii);
					if (isset($part)) {
						$parts = explode(' | ', $ii);
						if (is_number($parts[$part])) $s = $s + $parts[$part];
						}
					elseif (is_number($ii)) $s = $s + $ii;
					}
				$round = BOLTinit(2, $args['round']);
				return round($s/$t, $round);
			case 'find' :
				if (isset($part)) {
					foreach($info as $i=>$ii) {
						$parts = explode(' | ', $ii);
						if ($parts[$part] == $value) return $i;
						}
					}
				else return array_search($value, $info);
			case 'prev' : 
				$keys = array_keys($info);
				$index = array_search($field, $keys) - 1;
				return $keys[$index];
			case 'next' :
				$keys = array_keys($info);
				$index = array_search($field, $keys) + 1;
				return $keys[$index];
			case 'first' :
				$keys = array_keys($info);
				return BOLTinit($args['default'], $keys[0]);
			case 'last' : 
				$keys = array_keys($info);
				return BOLTinit($args['default'], $keys[count($keys)-1]);
			case 'counter' :
//				if ($data) return;
				if ($auth && BOLTauth($page, $BOLTid, 'info') === false && BOLTauth($page, $BOLTid, 'write') === false) return BOLTmessage("func_info_auth::$page", $args); // 
				if (is_number($args['part'])) {
					$old = $info[$field];
					$parts = explode(' | ', $old);
					$parts[$args['part']-1] = $parts[$args['part']-1] + 1;
					$new = implode(' | ', $parts);
					}
				else $new = $info[$field] + 1;
				$lines[$where[$field]] = "$field: $new";
				$content = implode("\n", $lines);
				BOLTsavecontent($page, $content);	
				return $info[$field] + 1;
			case 'scheduler' : 
				global $BOLTtime;
				foreach ($info as $f => $v) {
					$check = strtotime($f);
					if (! is_stamp($check)) continue;
					if ($check > $BOLTtime) continue;
					if (is_number($args['parts'])) {
						$parts = explode(' | ', $v);
						return $parts[$args['parts'] - 1];
						}
					return $v;
					}
			}
		}
	}

function BOLTFlastmodified($args) {
	global $pageLink, $pluginPath;
	$page = BOLTinit($pageLink, $args[1], $args['page']);
	$page = BOLTutf2url($page);
	$fmt = BOLTinit($args[2], $args['fmt']);
	$dir = BOLTinit('pages', $args['dir']);
	if ($dir == 'plugins') {
		if (file_exists("config/$page")) $time = filemtime("config/$page");
		else $time = filemtime("$pluginPath/$page");
		}
	else {
		if (strpos($dir, '..') !== false) return BOLTmessage('lastmodified', $args);
		$fpage = BOLTfolders($page);	
		if (file_exists("pages/$fpage")) $time = filemtime("pages/$fpage");
		}
	if ($time == '') return;
	if ($args['local'] == 'true') $time = $time + BOLTconfig('localTime', 0) * 3600;
	if ($fmt == '') return $time;
	return strftime($fmt, $time);
	}

function BOLTFlist($args) {
	global $pageLink;
	$delimiter = BOLTinit(',', $args['delimiter']);
	if (! isset($args['template']) && ! isset($args['fmt'])) $args['fmt'] = BOLTinit('list', $args[2]);
	if (isset($args['page'])) {
		if (!isset($args['delimiter'])) $delimiter = "\n";
		$list = BOLTfilter($args['page'], 'csv');
		$list = trim(BOLTloadcontent($list, false));
		}
	elseif (isset($args['info'])) {
		$list = BOLTFinfo(BOLTargs("list page=$args[info]"));
		}
	elseif (isset($args['for'])) {
		list($from, $to) = explode('-', $args['for'], 2);
		settype($to, 'integer');
		settype($from, 'integer');
		if ($from != $to) {
			if ($from < $to) {
				for ($i=$from; $i<$to+1; $i++) $list = $list . ",$i";
				}
			else {
				for ($i=$from; $i>$to-1; $i--) $list = $list . ",$i";
				}
			$list = trim($list, ',');
			}
		else $list = $to;
		}
	elseif (isset($args['query'])) {
		$args2 = $args;
		$args2['fmt'] = '{+p}'; $args2['join'] = ',';
		$list = BOLTFsearch($args2);
		}
	else $list = BOLTescape(BOLTinit($args[1], $args['trail']), false);
	$list = trim($list, $delimiter);
	if (empty($list)) return BOLTdisplay(Array(), $args);
	elseif (strpos($list, $delimiter) !== false) $outArray = explode($delimiter, $list);
	else $outArray[] = $list;
	if ($args['sort'] === '') $args['sort'] = 'false';
	$outArray = BOLTsearchResults($outArray, $args);
	if ($outArray == '') {
		$BOLTvar['count_matches'] = 0;	
		$out = BOLTdisplay(Array(), $args);
		if ($out == '') return BOLTdisplay(Array(), $args);
		return $out;
		}
	if (is_array($outarray)) $BOLTvar['count_matches'] = count($outarray);
	else $BOLTvar['count_matches'] = 0;	
	return BOLTdisplay($outArray, $args);
	}

function BOLTFlog($args) {
	global $BOLTid, $pageLink;
	$page = BOLTinit("log.$pageLink", $args[2], $args['page']); 
	$page = BOLTpageshortcuts($page);
	if (BOLTauth($page, $BOLTid, 'write') == false) return BOLTmessage("func_log_auth::$page", $args);
	$content = BOLTinit($args[1], $args['content']);
	$flags = $args['flags'];
	if ($content == '' && $flags == '') return;
	$content = preg_replace_callback('/\\{\\+(\\w+)\\}/', function($m) use ($args) { return BOLTfieldreplace($m[1], $args); }, $content);	
	if ($args['lines'] !== 'false') $content = str_replace('\n', "\n", $content);  
	if (isset($args['delimiter'])) $delimiter = str_replace('\n', "\n", $args['delimiter']); 
	else $delimiter = "\n";
	BOLTlog($content, $page, $delimiter, $flags);
	BOLTmessage("func_log::$page", $args);
	}

function BOLTFlogin($args) {
	global $pageLink, $BOLTid;
	if ($BOLTid != '') return;
	if ($pageLink == BOLTconfig('logoutPage', 'main')) return;
	$id = BOLTinit($_COOKIE['autoid'], $_GET['id'], $args['id']);
	$pass = BOLTinit($_COOKIE['autopass'], $_GET['pass'], $args['password']);	
	if ($id == '' || $pass == '') return;
	global $pageLink, $BOLTid, $cryptkey, $BOLTfield;  // set cryptkey in index.php, never change
	if ($BOLTid != '') return BOLTmessage('login_problem', $args);
	$id = strtolower(BOLTutf2url($id));
	$page = "member.$id";
	if ($id == '' || ! BOLTexists($page)) return BOLTmessage('login_auto_fail', $args);
	$pass1 = BOLTcrypt($pass);
	$pass2 = BOLTvars("$page:password", false);
	if ($pass2 == '') return BOLTmessage('login_auto_fail', $args);
	if ($pass1 !== $pass2) return BOLTmessage('login_fail', $args);
	$args['pass'] = $pass;
	BOLTlogin($id, $args);
	$next = BOLTinit($pageLink, $args['nextpage']);
	if ($next != 'false') BOLTredirect($next);
	}

function BOLTFlogout($args) {
	global $BOLTid, $pageLink;
	if ($BOLTid == '') return BOLTmessage('logout', $args);
	BOLTlogout($args);
	$next = BOLTinit(BOLTconfig('logoutPage', 'main'), $args['nextpage']);
	BOLTredirect($next);
	}

function BOLTFmail($args, $auth=true) {
	global $pageLink, $BOLTid, $BOLTzone;
	if (! isset($args['mode'])) $args['mode'] = BOLTconfig('mailMode');
	if ($auth && BOLTauth($pageLink, $BOLTid, 'mail') == false) return BOLTmessage('func_mail_auth', $args);
	$to = BOLTinit(BOLTconfig('sitemail'), $_POST['to'], $args['to']);
	if (BOLTexists("member.$to")) {
		$name = BOLTvars("member.$to:title", false);
		$to = BOLTvars("member.$to:email", false);
		}
	$from = BOLTinit(BOLTconfig('sitemail'), $_POST['from'], $args['from']);
	if (BOLTexists("member.$from")) $from = BOLTvars("member.$from:email");
	$sitename = BOLTinit('BoltWire', BOLTvars('code.settings::sitename', false));
	$subject = BOLTinit(BOLTconfig('mailsubject', "Mail from $sitename"), $_POST['subject'], $args['subject']);
	$body = BOLTinit($_POST['body'], $args['body']);
	if (BOLTexists($body)) $body = BOLTloadpage($body, '', '', true);
	if ($to == '') $missing = ' TO';
	if ($from == '') $missing .= ' FROM';
	if ($body == '') $missing .= ' BODY';
	if ($missing != '') return BOLTmessage("func_mail_param'::$missing", $args);
	$body = preg_replace_callback('/\\{\\+(\\w+)\\}/', function($m) use ($args) { return BOLTfieldreplace($m[1], $args); }, $body);
	$body = preg_replace_callback('/\\{(\\w+)\\}/', function($m) { return BOLTvars($m[1]); }, $body);
	$body = str_replace(Array('\n', '&#39;', '&#34;'), Array("\n", "'", '"'), $body);
	if ($args['content'] == 'text') $body = str_replace("\n", "\r\n", $body);
	else {
		$html = 'true';
		$rules = 'vars,if,links';
		if ($args['content'] == 'html') $rules .= ',bullets,style,block';
		$body = BOLTdomarkup($body, '', 'MAIL', $rules);
		$body = BOLTescape($body, false);
		}
	if ($args['mode'] != 'active') {
		$out = "**Mail is in demo mode:**\nSubject: $subject\nTo: $to\nFrom: $from\n\nMessage\n" . BOLTescape($body);
		BOLTmessage('mail_success::demo', $args);
		return $out;
		}
	else {
		$body = BOLTescape($body, false);
		$body = str_replace(Array('&amp;', '&lt;', '&gt;'), Array('&', '<', '>'), $body);
		if ($html && strpos($body, '/html') === false) $body = "<html><body>$body</body></html>";
		$mail = array('to'=>$to, 'from'=>$from, 'subject'=>$subject, 'body'=>$body, 'html'=>$html);
		$mail['name'] = BOLTinit($to, $name, $args['name']);
		$mail['reply'] = BOLTinit($from, $args['reply']);
		$mail['return'] = BOLTinit($from, $args['return']);
		$sent = BOLTmail($mail, $args);
		if ($sent == false) BOLTmessage('func_mail_fail', $args);
		BOLTmessage('mail_success::active', $args);
		}
	}

function BOLTFmath($args) {
	global $BOLTfuncMem;
	if ($args['id'] != '' && $BOLTfuncMem['math'][$args['id']] != '') return $BOLTfuncMem['math'][$args['id']];
	$math = str_replace('$', '', BOLTescape($args[1], false));
	$math = BOLTfilter($math, 'math');
	if (trim($math, '+-() ') == '') return BOLTmessage('math_invalid', $args); // 'Invalid math parameter';
	if ($math == '') return BOLTmessage('math_invalid', $args); // 'Invalid math parameter';
	try {
		eval("\$out=" . $math . ";");
		if (! is_numeric($out)) throw new Exception('');
		if ($out < .00000000001) $out = 0;
		$d = BOLTinit(2, $args['decimal']) + 1;
		$dot = strpos($out, '.');
		if ($dot !== false && strlen($out) - $dot > $d) $out = substr($out, 0, $dot + $d);
		$out = rtrim($out, '.');
		if ($args['id'] != '') $BOLTfuncMem['math'][$args['id']] = $out;
		if ($out == 'NAN') return BOLTmessage('math_invalid', $args); // Division by 0?
		return $out;
		}
	catch(Throwable $exception) {  // was Exception instead of Throwable in php 5. need to test for server...
		return BOLTmessage('math_invalid', $args); 
		}
	}

function BOLTFmemberships($args) {
	deprecate('memberships', '', $pageLink);	
	return BOLTFgroups($args);
	}

function BOLTFgroups($args) {
	global $BOLTid, $BOLTvar, $BOLTsession, $BOLTgroups, $BOLTadmin;
	$id = BOLTinit($BOLTid, $args['id']);  // Allows you to check memberships of other people
	$g[] = 'guest';  // Everyone has guest status, even if logged in
	if ($id != '') {
		$g[] = 'member';  // Note: does not check if member account exists
		$fpage = BOLTfolders('group');
		if (strpos($fpage, '/') === false) $folder = 'pages';
		else $folder = 'pages/' . substr($fpage, 0, -6);
	    $groups = BOLTlistpages("/^group\./", $folder, array('folders'=>'false'));  // Get group pages
	    if (is_array($groups)) {
		    foreach ($groups as $group) {
		        $groupname = substr($group, 6);
		        if (BOLTingroup("$groupname", $id, false)) $g[] = $groupname;
				}
			}
		if ($BOLTid == $BOLTadmin && $BOLTid == $id) $g[] = 'admin';  // checks for superadmins
		if (in_array('admin', $g)) $g[] = 'editor';  // all admins are editors 
		$g = array_unique($g);
		}
	if ($id == $BOLTid) {  // If checking for user, update their memberships
	    $BOLTsession['ID']['groups'] = implode(',', $g);
		$BOLTgroups = $BOLTsession['ID']['groups'];
		$BOLTvar['groups'] = $BOLTgroups;
		BOLTmessage('func_memberships', $args);
		}
	return implode(',', $g); 
    }

function BOLTFpreview($args) {
	global $pageLink;
	$preview = BOLTinit($BOLTsession['PASSFORM'][$args[1]], $_POST[$args[1]]);
	if ($preview != '') {
		if ($args['output'] == 'escape') return BOLTescape($preview);
		$preview = str_replace(Array('(script', '(preview', '(mail', '(log', '(in', '(forward'), '(no_execute', $preview);  // prevents nesting
		$preview = str_replace(Array("\r\n", "\r"), Array("\n", "\n"), $preview);  // fix line breaks
		if (substr($pageLink, 0, 5) == 'code.' || substr($pageLink, 0, 9) == 'template.') { // return fully escaped
			$preview = BOLTescape($preview, false);
			$preview = htmlspecialchars($preview);
			$preview = BOLTcharEncode($preview, 'lines', false);
			if ($args['border'] == 'false') return BOLTescape(ltrim($preview));
			return BOLTescape("<div class='preview'>" . ltrim($preview) . '</div>');
			}
		$preview = str_replace('[form', '[`form', $preview); // get rid of forms, commands
		$preview = preg_replace('/([\\n]?)\[command( (?:"*.?"|\'*.?\'|\[\]|\]\]|=\]|[^\]])*)?\]/', '', $preview);
		$preview = BOLTdomarkup("\n$preview");
		if ($args['border'] == 'false') return BOLTescape(ltrim($preview));
		return BOLTescape("<div class='preview'>" . ltrim($preview) . '</div>');
		}
	}

function BOLTFquery($args, $auth=true, $array=false) {
	global $pageLink, $BOLTid, $BOLTvar;
	if (inlist($args[1], 'prev,next')) {
		$args['count'] = BOLTinit($args['count'], 'false');
		$args['type'] = BOLTinit($args['type'], 'number');
		}
	if (! isset($args['count'])) $args['count'] = BOLTconfig('searchLimit', 50);
	if ($args['pattern'] . $args['group'] != '') $pageArray = BOLTsearchPageList($args, $zone, $auth);
	$query = BOLTinit($pageLink, $args[1], $args['page']);
	$query = BOLTutf2url($query);
	if ($query == '') return 'No search parameters found.';
	$args['query'] = $query; // Just in case needed in processing below...
	if (strpos($query, ':') !== false || strpos($query, '#') !== false) {
		$queryArray = BOLTquery($pageArray, $query);
		}
	else {
		$indexRoot = BOLTconfig('indexRoot', 'index');
		if (BOLTexists("$indexRoot.$query")) {
			$query = "$indexRoot.$query";
			$args['query'] = $query;
			}
		elseif (BOLTexists("info.$query")) {
			$query = "info.$query";
			$args['query'] = $query;
			}
		elseif (! BOLTexists($query)) {
			BOLTmessage('search_no_query', $args);
			return BOLTdisplay(Array(), $args);
			}
		$queryArray = BOLTquery($pageArray, $query);
		}
	foreach($args as $f => $v) {
		if (! is_int($f)) continue;
		if (strpos($v, '(') === false || strpos($v, ')') === false) continue;
		$data[] = $v;
		unset($args[$f]);
		}
	if (isset($args['text'])) $queryArray = BOLTqueryText($queryArray, $args['text'], $args);
	if (isset($args['link'])) $queryArray = BOLTqueryLink($queryArray, $args['link'], $args);
	if (is_array($data)) $queryArray = BOLTqueryData($queryArray, $data, $args);
	if (is_array($queryArray)) $queryArray = array_keys($queryArray);
	else $queryArray = Array();
	if (isset($pageArray)) $pageArray = array_intersect($pageArray, $queryArray);
	else $pageArray = $queryArray;
	$pageArray = BOLTsearchResults($pageArray, $args);
	if ($array == true) return $pageArray;
	if ($pageArray == '') {
		BOLTmessage('search_no_results', $args);
		return BOLTdisplay(Array(), $args);
		}
	return BOLTdisplay($pageArray, $args);
	}

function BOLTFrandom($args) {
	global $BOLTfuncMem;
	if ($args['id'] != '' && $BOLTfuncMem['rand'][$args['id']] != '') return $BOLTfuncMem['rand'][$args['id']];
	if ((BOLTfilter($args[1], 'numbers')) === false || (BOLTfilter($args[2], 'numbers') === false)) return; 
	$out = rand($args[1], $args[2]);
	if ($args['id'] != '') $BOLTfuncMem['rand'][$args['id']] = $out;
	return $out;
	}

function BOLTFscript($args) {
	global $pageLink, $BOLTsession;
	$script = trim(BOLTloadpage('code.script.' . $args[1]));
	if ($script == '') return;
	foreach ($args as $f => $v) $script = str_replace("{+$f}", $v, $script);  // vars available in script from func args
	$script = BOLTdomarkupTable($script, $pageLink, 'vars,func,if');
	preg_match_all('/\[command ([-_a-z0-9]+) (.*)\]/ie', $script, $matches);
	foreach ($matches[1] as $i => $cmd) {
		$scriptCommands[$cmd] = $matches[2][$i];
		}
	BOLTexecute($scriptCommands, true);
	BOLTmessage("func_script::$args[1]", $args);
	return $BOLTcommands['return'];
	}

function BOLTFsearch($args, $auth=true, $array=false) {
	if ($args['query'] != '') {
		deprecate('query', '', $pageLink);
		$args['page'] = $args['query'];
		unset($args['query']);
		return BOLTFquery($args, $auth, $array);		
		}
	global $pageLink, $BOLTid, $BOLTvar;
	if (inlist($args[1], 'prev,next')) {
		$args['count'] = BOLTinit($args['count'], 'false');
		$args['type'] = BOLTinit($args['type'], 'number');
		}
	if (! isset($args['count'])) $args['count'] = BOLTconfig('searchLimit', 50);
	$pageArray = BOLTsearchPageList($args, $zone, $auth);
	$pageArray = BOLTsearchResults($pageArray, $args);
	if ($array == true) return $pageArray;
	if ($pageArray == '') {
		BOLTmessage('search_no_results', $args);
		return BOLTdisplay(Array(), $args);
		}
	return BOLTdisplay($pageArray, $args);
	}

function BOLTFsource($args) {
	global $pageLink, $BOLTid, $BOLTcommands, $BOLTsession;
	if (! is_array($args)) $args = BOLTargs($args);
	if (isset($args['post']) && isset($_POST[$args['post']])) return BOLTescape(htmlspecialchars($_POST[$args['post']]));
	if (isset($args['cookie']) && isset($_COOKIE[$args['cookie']])) return BOLTescape(htmlspecialchars($_COOKIE[$args['cookie']]));
	if (isset($args['get']) && isset($_GET[$args['get']])) return BOLTescape(htmlspecialchars($_GET[$args['get']]));
	if (isset($BOLTcommands[$args['command']])) return $BOLTcommands[$args['command']];
	$page = BOLTinit($args[1], $args['page']);
	if ($page == '') return $args['default'];
	if (strpos($page, ':') !== false) {
		$data = substr($page, strpos($page, ':'));
		$page = substr($page, 0, strpos($page, ':'));
		}
	if (strpos($page, '#') !== false) {
		$anchor = substr($page, strpos($page, '#'));
		$page = substr($page, 0, strpos($page, '#'));
		}
	$page = BOLTpageshortcuts($page);
	if (BOLTfilter($page, 'page') == '') return;
	if (BOLTauth($page, $BOLTid, 'view') === false) BOLTmessage("func_source_auth::$page", $args);
	if ($data != '') {
		if ($args['dir'] == 'stamps') $out = BOLTvars("$page$anchor*$data");
		else $out = BOLTvars("$page$anchor$data");
		}
	else {
		if ($args['dir'] == 'stamps') $out = BOLTloadpage("$page$anchor", $args['dir']);
		else $out = BOLTloadpage("$page$anchor");
		if (isset($args['lines']) && $args['lines'] != 'true') $out = BOLTgetlines($out, $args['lines']);
		}
	$out = BOLTescape($out, false);
	if (trim($out) == '') return $args['default'];
	$out = BOLTcharEncode($out, $args['fmt']);
	if ($args['lines'] == 'true') {
		deprecate('source-vspace', '', $pageLink);  // delete second condition in line 734 when end this...	
		$out = BOLTvspace(BOLTescape($out, false));
		}
	if ($args['vspace'] == 'true') $out = BOLTvspace(BOLTescape($out, false));
	if ($args['escape'] !== 'false') $out = BOLTescape($out);
	BOLTmessage("func_source::$page", $args);
	return $out;
	}

function BOLTFtags($args) {
	global $BOLTinfoCache;
	$indexRoot = BOLTconfig('indexRoot', 'index');
	$page = BOLTinit("$indexRoot.tags", $args[1], $args['page']);
	BOLTinfoVar($page);
	$tagArray = $BOLTinfoCache[$page];
	$tagPages = array_keys($tagArray);
	foreach ($tagPages as $i => $p) {
		if ($args['when'] != '') {
			$when = BOLTdisplayReplace($args['when'], $i, $tagPages, Array('info'=>$page));
			if (BOLTiftrue($when, 'true') != 'true') { unset($tagArray[$p]); continue; }
			}
		$tags .= ' ' . $tagArray[$p][0]; 
		}
	if (trim($tags) == '') return BOLTinit('No tags found...', $args['none']);
	$tags = explode(' ', trim($tags));
	foreach ($tags as $t) {
		$tag[$t] = $tag[$t] + 1;
		}
	if (is_number($args['count'])) {
		krsort($tag);
		$tag = array_slice($tag, 0, $args['count']);
		}
	if ($args['sort'] != 'false') ksort($tag);
	if ($args['fmt'] == 'cloud') {
		$c = $tag;
		sort($c);
		$low = $c[0];
		$high = $c[count($c)-1];
		$diff = ($high - $low);
		$max = BOLTinit(17, $args['max']);
		$min = BOLTinit(10, $args['min']);
		ksort($tag);
		foreach($tag as $i => $ii) {
			$x = ((($ii - $low) / $diff) * $max) + $min; // 12 is smallest size, 12 + 15 is largest size. px
			$out .= " <span style=\"font-size: " . $x . "px;\">[[action.tags&tag=$i|$i]]</span> ";
			}
		return $out;
		}
	if ($args['fmt'] == '' && $args['template'] == '') $args['fmt'] = '[[action.tags&tag={+field}|{+field}]]';
	return BOLTdisplay ($tag, $args);
	}

function BOLTFthread($args) {
	if ($args['page'] != '') return BOLTthread($args['page'], true);
	return BOLTthread(BOLTinit($args[1], $args['dir']));
	}

function BOLTFtime($args) {
	global $BOLTtime;
	$when = BOLTinit($BOLTtime, $args[1], $args['when']);
	$fmt = BOLTinit($args[1], $args[2], BOLTfilter($args['fmt'], 'parameter'));
	if ($fmt == 'month') { global $BOLTmonths; return $BOLTmonths[ltrim($when, 0)]; }
	if ($fmt == 'week') { global $BOLTweekdays; return $BOLTweekdays[ltrim($when, 0)]; }
	if (strlen($when) == 10 && is_number($when)) $t = $when;
	else {
		$temp = strtotime($when);
		if (strlen($temp) == 10 && is_number($temp)) $t = $temp;
		}
	if ($t == '') $t = $BOLTtime;  // finally have a timestamp
	
	if ($fmt == 'timestamp' || $fmt == '%s') return $t;
	if (strpos($fmt, '%') !== false) $f = $fmt;
	if ($f == '') $f = BOLTconfig('timeFmt', '%c');
	if ($f == 'due') return round(($t - $BOLTtime)/86400);
	if ($f == 'since') return round(($BOLTtime - $t)/86400);
	if (strpos($f, '%e') !== false) $f = str_replace('%e', ltrim(strftime('%d', $t),0), $f);
	if (strpos($f, '%E') !== false) $f = str_replace('%E', ltrim(strftime('%m', $t),0), $f);
	return strftime($f, $t);
	}

function BOLTFtoc ($args) {
	global $pageLink;
	$page = BOLTinit($pageLink, $args[1], $args['page']);
	$parts = explode('.', $page);
	$leader = BOLTinit('      ', $args['leader']);
	$count = count($parts);
	if (is_number($args['offset']) && $count >= $args['offset']) $count = $count - $args['offset'];
	return str_repeat($leader, $count);
	}

function BOLTFtranslate($args) {
	$text = $args[1];
	$lang = BOLTinit($args['language'], $args[2]);
	return BOLTtranslate($text, $lang, $args['reverse'], $args['case']);
	}

function BOLTFzone($args) {
## A FUNCTION TO TAP INTO THE HIEARCHICAL PAGE SYSTEM. FOR EXAMPLE GETLINK SIDE WILL FIND THE CLOSEST SIDE PAGE TO THE CURRENT PAGE
	global $pageLink, $BOLTzone;
	$zone = BOLTinit($BOLTzone, $args[1], $args['zone']);
//	$zone = BOLTfilter($zone, 'page');
	$page = BOLTinit($pageLink, $args[2], $args['page']);
	$link = BOLTgetlink($zone, '', $page);
	return $link;
	}

function BOLTFgetlink($args) {
	global $pageLink;
	deprecate('getlink', '', $pageLink);	
	return BOLTFzone($args);
	}
