<?php if (!defined('BOLTWIRE')) exit();

########################################
##  BOLTWIRE SYSTEM VARIABLES         ##
##  Copyright 2019 Dan Vis            ##
##  See license.txt for details       ##
########################################


## SETUP SYSTEM PATHS RELATIVE TO INDEX.PHP
//$boltwire can be reset in index.php before calling engine if moving code location
//If moving shared folder, modify $sharedPath AND $sharedURL.
$scriptPath = "$boltwire/scripts";
if (! isset($systemPath)) $systemPath = "$boltwire/system"; // the system pages
if (! isset($sharedPath)) $sharedPath = "$boltwire/shared"; // resources shared across fields
if (! isset($imgPath)) $imgPath = "$sharedPath/img";
if (! isset($pluginPath)) $pluginPath = "$sharedPath/plugins";
if (! isset($skinPath)) $skinPath = "$sharedPath/skins";

## SETUP ABSOLUTE FIELD URLS & DIRS
//Modify these cautiously, if needed, in index.php or config.php
if (! isset($sharedURL)) $sharedURL = "http://$_SERVER[HTTP_HOST]/" . substr($boltwire, 3) . '/shared';
$langURL = "$sharedURL/lang";
if (! isset($fieldURL)) $fieldURL = dirname("http://$_SERVER[HTTP_HOST]$_SERVER[SCRIPT_NAME]");
$BOLTfield = 'bolt' . substr($fieldURL, strrpos(substr($fieldURL, 0, -1), "/") + 1);
$index = 'index.php';
$scriptURL = "$fieldURL/$index?p=";
$timezone = BOLTconfig('timezone');
if ($timezone != '') date_default_timezone_set($timezone);

## VARS AVAILABLE IN BOLTWIRE PAGES
$BOLTvar['boltwire'] = 'http://www.boltwire.com/';
$BOLTvar['script'] = $scriptURL;
$BOLTvar['field'] = $fieldURL;
$BOLTvar['shared'] = $sharedURL;
$BOLTvar['img'] = $imgPath;
$BOLTvar['files'] = "$fieldURL/files/";
$BOLTvar['version'] = BOLTWIRE;
$BOLTvar['ip'] = $_SERVER['REMOTE_ADDR'];
$BOLTvar['domain'] = $_SERVER['SERVER_NAME'];
$BOLTvar['superadmin'] = $BOLTadmin;
if (isset($_SERVER['HTTP_REFERER'])) $BOLTvar['return'] = $_SERVER['HTTP_REFERER'];

## USED IN MARKUP RULES
$uploadImgTypes = BOLTconfig('uploadImgTypes', 'gif,jpg,jpeg,png,svg');
$uploadImgTypes = str_replace(',','|',$uploadImgTypes);
$uploadFileTypes = BOLTconfig('uploadFileTypes', 'pdf,txt');
$uploadFileTypes = str_replace(',','|',$uploadFileTypes);

## SETUP FILTERS TO CHECK INPUT
$BOLTfilter['letters'] = 'a-zA-Z';
$BOLTfilter['numbers'] = '0-9';
$BOLTfilter['page'] = '-_a-zA-Z0-9.#?=%*';  // is this too generous?
$BOLTfilter['uploads'] = '-_0-9a-zA-Z. ';
$BOLTfilter['csv'] = '-_a-zA-Z0-9+.,*:|!#% ';  // is this too generous?
$BOLTfilter['parameter'] = '-_a-zA-Z0-9.,\'"%:!/ ';
$BOLTfilter['math'] = '-*+/()0-9.';

## NEEDED AS GLOBAL VARIABLES
$BOLTskin = '';  // means can't set in index.php
$BOLTindexPages = Array();
if (! isset($BOLTmonths)) $BOLTmonths = array('', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
if (! isset($BOLTweekdays)) $BOLTweekdays = array('', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');

## USED FOR UTF PAGES -- CODE BELOW GENERATES NEEDED ARRAY
//$BOLTutfEscapeChars = Array('%','<','>','/','\\','*',':',',','~','@','+','^','!','#','&','$',';','=','?',"\n",'{','}','"','\'');
//foreach ($BOLTutfEscapeChars as $char) {  
//	$code = urlencode($char);
//	$BOLTutfEscape[$code] = $char;
//	$BOLTutfEscape[strtolower($code)] = $char;
//	}
$BOLTutfEscape = Array('%25'=>'%','%3C'=>'<','%3c'=>'<','%3E'=>'>','%3e'=>'>','%2F'=>'/','%2f'=>'/','%5C'=>'\\','%5c'=>'\\','%2A'=>'*','%2a'=>'*','%3A'=>':','%3a'=>':','%2C'=>',','%2c'=>',','%7E'=>'~','%7e'=>'~','%40'=>'@','%2B'=>'+','%2b'=>'+','%5E'=>'^','%5e'=>'^','%21'=>'!','%23'=>'#','%26'=>'&','%24'=>'$','%3B'=>';','%3b'=>';','%3D'=>'=','%3d'=>'=','%3F'=>'?','%3f'=>'?','%0A'=>"\n",'%0a'=>"\n",'%7B'=>'{','%7b'=>'{','%7D'=>'}','%7d'=>'}','%22'=>'"','%27'=>"'");

## SETUP ALLOWED ATTRIBUTES
if (! isset($BOLTinputTypes)) $BOLTinputTypes = 'color,date,email,number,range,time,url';
$BOLTattrs['messages'] = 'id,class,style';
$BOLTattrs['form'] = 'name,id,class,style,action,enctype,method,accept-charset,autocomplete,expires,target,scrollto';
$BOLTattrs['text'] = 'name,id,value,class,style,size,maxlength,disabled,autofocus,autocomplete,readonly,required,tabindex,min,max,step,pattern';
$BOLTattrs['password'] = 'name,id,value,class,style,size,maxlength,disabled,autofocus,autocomplete,readonly,required,tabindex';
$BOLTattrs['checkbox'] = 'name,id,value,class,style,checked,disabled,autofocus,required,tabindex';
$BOLTattrs['radio'] = 'name,id,value,class,style,disabled,checked,autofocus,required,tabindex';
$BOLTattrs['select'] = 'name,id,value,class,style,disabled,required,size,tabindex,default';
$BOLTattrs['hidden'] = 'name,id,value';
$BOLTattrs['input'] = 'name,id,value,class,style,type,disabled,required,size,min,max,step,tabindex,autofocus';
$BOLTattrs['image'] = 'name,id,value,class,style,disabled,autofocus,height,width,src,alt,tabindex';
$BOLTattrs['option'] = 'id,value,class,style,selected,disabled';
$BOLTattrs['optgroup'] = 'id,label,class,style,disabled';
$BOLTattrs['box'] = 'name,id,value,class,style,disabled,autofocus,readonly,required,cols,rows,wrap,tabindex,maxlength';
$BOLTattrs['file'] = 'name,id,value,class,style,disabled,autofocus,required,tabindex,type';
$BOLTattrs['button'] = 'name,id,value,class,style,disabled,tabindex';
$BOLTattrs['submit'] = 'name,id,value,class,style,disabled,tabindex';
$BOLTattrs['reset'] = 'name,id,value,class,style,disabled,tabindex';
$BOLTattrs['t'] = 'align,background,bgcolor,border,bordercolor,cellpadding,cellspacing,width,height,style,class,id';
$BOLTattrs['r'] = 'align,background,bgcolor,valign,cellpadding,cellspacing,border,style,class,id';
$BOLTattrs['c'] = 'align,background,bgcolor,valign,border,cellpadding,cellspacing,colspan,rowspan,nowrap,valign,width,style,class,id';
$BOLTattrs['h'] = $BOLTattrs['c'];
$BOLTattrs['a'] = 'id,class,href,name,style,rev,rel,target,title,accesskey,tabindex,class,id,xmllang';
$BOLTattrs['span'] = 'id,class,style,align,border,bottom,class,clear,color,float,height,left,letter-spacing,margin,padding,position,right,top,width,z-index';
$BOLTattrs['p'] = 'id,class,style,align,border,bottom,class,clear,color,float,height,left,letter-spacing,margin,padding,position,right,top,width,z-index';
$BOLTattrs['div'] = 'id,class,style,align,border,bottom,class,clear,color,float,height,left,letter-spacing,margin,padding,position,right,top,width,z-index';
$BOLTattrs['ul'] = 'id,class,style';
$BOLTattrs['ol'] = 'id,class,style';
$BOLTattrs['li'] = 'id,class,style';
$BOLTattrs['img'] = 'align,border,style,class,height,width,hspace,vspace,title,alt';
$BOLTattrs['blockquote'] = 'dir,data-lang,id,class,style';
$BOLTattrs['html'] = ',i,b,u,s,h1,h2,h3,h4,h5,h6,ul,ol,li,dl,dt,dd,sub,sup,big,small,strike,del,strong,em,comment,br,nobr,wbr,fieldset,legend,pre,mark';
