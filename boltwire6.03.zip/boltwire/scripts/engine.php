<?php

########################################
##  BOLTWIRE MAIN ENGINE              ##
##  Copyright 2019 Dan Vis            ##
##  See license.txt for details       ##
########################################


## THIS IS THE SCRIPT THAT CALLS ALL THE OTHER SCRIPTS AND CREATES OUTPUT
define('BOLTWIRE','6.03'); // version number
if (substr(PHP_VERSION, 0, 3) < 5.3) exit('PHP 5.3+ required. Please upgrade.');
if (isset($BOLTstopWatch))	BOLTstopWatch('Initialization begun');  // Stopwatch is used to benchmark performance  ##PRO

## FIRST, LOAD THE SYSTEM SCRIPTS
if (! isset($boltwire)) $boltwire = '../boltwire';  // change in index.php if non-standard installation
if (! isset($BOLTscripts)) $BOLTscripts = Array('variables', 'library', 'markups', 'functions', 'conditions', 'commands'); // can customize $BOLTscripts in index.php

foreach ($BOLTscripts as $script) {
	if (file_exists("$boltwire/scripts/$script.php")) include_once("$boltwire/scripts/$script.php");
	else exit("Script //$script// not found...");
	}

## BLACKLISTING/WHITELISTING HANDLED HERE  // Define blacklist and whitelist pages in index.php for blocked/allowed ips   ##PRO
if (isset($BOLTblackList) || isset($BOLTwhiteList)) {
	BOLTinit('Access Denied', $IPblockedHTML);
	if ($BOLTwhiteList != '' && strpos(BOLTloadpage($BOLTwhiteList), $BOLTvar['$ip']) === false) { print_r($IPblockedHTML); die(); }
	elseif ($BOLTblackList != '' && strpos(BOLTloadpage($BOLTblackList), $BOLTvar['$ip']) !== false) { print_r($IPblockedHTML); die(); }
	}

BOLTprocess('startup'); // run array of custom functions before initializing system

## NEXT TAKE CARE OF A FEW INTERNAL DETAILS
if (isset($errorReporting)) {
	if ($errorReporting == true) error_reporting(E_ALL ^ E_NOTICE); // Turn on in index.php
	else error_reporting($errorReporting);
	}
else error_reporting(0);

if (! file_exists('forms')) {  // sets up key directories for first time run...
	BOLTfixdir('pages');
	BOLTfixdir('config');
	BOLTfixdir('files', false);
	BOLTfixdir('stamps');
	BOLTfixdir('forms');
	if (! file_exists('favicon.ico')) copy("$boltwire/shared/img/favicon.ico", "favicon.ico");  ##PRO - DUPLICATE???
	}

// Eliminate slashes if php has magic quotes turned on
if (get_magic_quotes_gpc() == 1) {
	foreach($_GET as $field => $value) $_GET[$field] = stripslashes($value);
	foreach($_POST as $field => $value) {
		if (is_array($value)) $_POST[$field] = array_map(stripslashes, $value);
		else $_POST[$field] = stripslashes($value);
		}
	}

## LOAD CONFIG VALUES FROM SITE.CONFIG PAGE AND DETERMINE PLUGINS TO BE ENABLED
if ($sitePages == '') $sitePages = 'pages';
if (file_exists("$sitePages/site.config") !== false) $config = file_get_contents("$sitePages/site.config");
if ($config == '') $config = file_get_contents("$boltwire/system/site.config");
preg_match_all('/^(enable([-\w]+)\:?|(([-\w]*)\: )?)(.*)?$/m', $config, $m);
foreach ($m[5] as $i => $v) {
	if ($m[4][$i] != '') $BOLTconfig[strtolower($m[4][$i])] = trim($v); // config values
	if ($m[2][$i] != '') $BOLTplugins[strtolower($m[2][$i])] = trim($v); // plugins
	}

## SETUP TIME, LANGUAGE & UTF VARIABLES
$BOLTtime = time() + BOLTconfig('localTime', 0) * 3600;
$BOLTvar['now'] = $BOLTtime;
$BOLTvar['language'] = BOLTconfig('language');

if (BOLTconfig('skinMobile', 'true') == 'true') {  // should be true by default
	$mp1 = "/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i";
//	$mp2 = '/(iphone|ipod|android|webos|iemobile|kindle|blackberry)/i';
	$mobilePat = BOLTconfig('mobilepat', $mp1);
	if (preg_match($mobilePat, $_SERVER['HTTP_USER_AGENT']) > 0) $BOLTmobile = 'true';
	}

## INITIALIZE SESSION
global $BOLTsession;
session_start();
$BOLTsession = $_SESSION[$BOLTfield];

## SETUP MEMBER/GROUP AUTHENTICATION FROM SESSION
if (! isset($BOLTsession['ID'])) { 
	if(BOLTconfig('autologin', 'false') == 'true') BOLTFlogin(array('nextpage'=>'false', 'msg'=>'false'));
	$BOLTid = '';
	$BOLTmember = BOLTconfig('guestname', 'Guest');
	$BOLTgroups = 'guest';
	}
if (isset($BOLTsession['ID'])) { // If logged in.
	$BOLTid = $BOLTsession['ID']['id'];
	$BOLTvar['id'] = $BOLTid;
	$BOLTmember = $BOLTsession['ID']['member'];
	$BOLTvar['member'] = $BOLTmember;
	$BOLTgroups = $BOLTsession['ID']['groups'];
	$BOLTvar['groups'] = $BOLTgroups;
	}
//if (isset($BOLTsession['PASSFORM'])) {
//	foreach ($BOLTsession['PASSFORM'] as $pf => $pv) {
//		if (! isset($_POST[$pf])) $_POST[$pf] = $pv;
//		}
//	}

## CLEANUP PAGELINK (FROM UTF) AND CREATE PAGEARRAY VAR
if ($_GET['p'] == '') {
	if ($BOLTmobile) $pageLink = BOLTconfig('homeMobile', 'welcome');
	else $pageLink = BOLTconfig('homePage', 'welcome');
	}
else $pageLink = $_GET['p'];
$pageLink = str_replace('/', '.', $pageLink);
$pageLink = strtolower(trim($pageLink, '.'));
$pageLink = BOLTutf2url($pageLink);

if (preg_match('/^[-_a-zA-Z0-9\.%]+$/', $pageLink) == 0) exit("Invalid page name.");
$pa = explode(".", $pageLink);
if (BOLTconfig('cleanurls') == 'true') $cleanURL = BOLTinit("$fieldURL/", $cleanURL);
$BOLTvar['url'] = BOLTFgeturl($pageLink);

## LOAD LOCAL CONFIG.PHP AND ENABLED PLUGINS
if (file_exists("config/config.php")) include_once("config/config.php"); 
if (file_exists("$pluginPath/config.php")) include_once("$pluginPath/config.php"); 
if (is_array($BOLTplugins)) {
	foreach($BOLTplugins as $plugin => $check) {
		if (! BOLTpageCheck($check)) continue;
		if (file_exists("config/$plugin.php")) {
			include_once("config/$plugin.php");
			$BOLTvar['plugins'] .= ",$plugin";
			}
		elseif (file_exists("$pluginPath/$plugin.php")) {
			include_once("$pluginPath/$plugin.php");
			$BOLTvar['plugins'] .= ",$plugin";
			}
		}
	$BOLTvar['plugins'] = ltrim($BOLTvar['plugins'], ",");
	}

## MANAGES IMPORT REQUESTS AND LOGINS VIA A GET[LOGIN] FIELD WITH AN ID:PASS VALUE
if (BOLTconfig('exportCode') != '') {
	if ($_GET['importcode'] == BOLTconfig('exportCode')) {
		print_r(BOLTescape(BOLTdomarkup(BOLTloadpage($pageLink)), false)); 
		}
	die();
	}
	
BOLTpageShow();  // sets action vars if action page required.

BOLTprocess('pre');
if (isset($BOLTstopWatch)) {
	BOLTstopWatch('Initialization complete');
	BOLTstopWatch('Page construction begun');
	}
	
## RUN FORMS PROCESSOR IF NEEDED
if (isset($_POST['boltkey'])) BOLTexecute(BOLTsecure());  // Validates form and executes commands

## THIS SECTION DETERMINES SKIN
if (function_exists('myBOLTchooseSkin')) $skin = myBOLTchooseSkin();  // Hook for custom function
else {
	if ($BOLTskin == '') $BOLTskin = BOLTinit('default', $BOLTdefaultSkin, BOLTconfig('skin'));
	if ($_GET['action'] == 'print' && BOLTconfig('printSkin', 'print') !== 'false') $BOLTskin = BOLTinit(BOLTconfig('printSkin', 'print'), $BOLTdefaultPrintSkin);
	if ($BOLTmobile == 'true' && BOLTconfig('mobileSkin', 'mobile') !== 'false') $BOLTskin = BOLTinit(BOLTconfig('mobileSkin', 'mobile'), $BOLTdefaultMobileSkin);
	$skin = "code.skin.$BOLTskin.html";
	}
//$html = BOLTskinLoad();  //7.xx
$html = BOLTloadskin('html');  // 6.03
if ($html == '') {
	if (BOLTingroup('admin', $BOLTid)) BOLTmessage("skin_missing::$BOLTskin");
	$BOLTskin = 'default';
	$skin = 'code.skin.default.html';
	$html = BOLTloadpage($skin);
	}
$BOLTvar['skin'] = "$skinPath/$BOLTskin/";  // Useful for skin graphics, css, and similar files
$BOLTvar['skinname'] = $BOLTskin;  //change these to skinpath and skin?

## THIS SECTION CREATES PAGE OUTPUT
if (function_exists('myBOLTmakePage')) $out = myBOLTmakePage($html);  // Hook for custom function
else {
	BOLTstopWatch('Skin creation begun');
	if (BOLTconfig('cacheAllowed', 'false') == 'true') $out = BOLTcache("cache.html.$pageLink");
	if ($out == '') {
		$out = BOLTmakeHTML($html);
		if (is_number($BOLTcache['html'])) BOLTcacheSave("cache.html.$pageLink", $BOLTcache['html'], $out);
		}
	$out = preg_replace_callback('/\{\+([-_a-z0-9:]+)\+\}/i', function($m) use($out) { return BOLTescape(BOLTvars($m[1]), false); }, $out);  // Inserts {+vars+} after cache!
	if (is_array($BOLTserverHeaders)) { foreach($BOLTserverHeaders as $h) header($h); } // Add custom headers
	BOLTstopWatch('Skin creation complete');
	}

## CLEAR OLD SESSION INFO AND SAVE NEW
unset($BOLTsession['MSG']);  // from last page for this page
unset($BOLTsession['PASSFORM']);
session_start();
$_SESSION = Array();
$_SESSION[$BOLTfield] = $BOLTsession;
session_write_close();

if (isset($BOLTstopWatch)) {
	BOLTstopWatch('Page construction complete');
	if (inlist('admin', $BOLTgroups)) $out = str_replace("<body>", "<body>" . BOLTstopWatchPrint(), $out);
	}

## OUTPUT PAGE AND RELEASE BROWSER TO ALLOW BACKGROUND PROCESSES
BOLTindexSetup();
BOLTprocess('post');  // run array of closing functions
if (BOLTconfig('bufferOutput', 'false') == 'true') BOLToutputPage($out);
else print_r($out);
exit();


#####################################################################
## FOLLOWING ARE CORE SYSTEM UTILITIES USED IN BOLTWIRE
## p/pp/inlist/is_number/args/attrs/config/init/read/write
#####################################################################

## SUPER HELPFUL FUNCTIONS USED EVERYWHERE
function p($x) { global $debug; $debug = 'true'; var_dump($x); print_r("\n<br>\n");	}
function pp($x) { p($x); die(); }
function BOLTXpp($value, $field, $args) { pp($value); }
function inlist($item, $list) {	return (strpos(",$list,", ",$item,") !== false); }
function is_number($x) { return ((string)floatval($x) == $x); }
function is_stamp($x) { return ((int)$x == $x && strlen($x) == 10); }

function BOLTargs($x='') {  
## POWERFUL FUNCTION FOR PARSING A PARAMETER STRING INTO AN ARRAY, USED MANY PLACES.
	$x = BOLTstripSlashes($x);
	$x = preg_replace('/([a-z])(\')([a-z])/i', '$1&#39;$3', $x);  // this is for apostrophe's like DON'T ? 
	$count = 0;
	$pat = '(?>([-\\w]+)=)';
	preg_match_all("/($pat)?(\"[^\"]*\"|'[^']*'|\\S+)/", $x, $terms, PREG_SET_ORDER);
	foreach($terms as $t => $tt) {
		if ($terms[$t][2] == '') {
			$count = $count + 1;
			$args[$count] = BOLTtrimQuotes($terms[$t][3]);
			}
		else $args[strtolower($terms[$t][2])] = BOLTtrimQuotes($terms[$t][3]);
		}
	if (is_array($args)) return $args;
	return Array();
	}

function BOLTattrs($type) {
	global $BOLTattrs;
	return explode(",", $BOLTattrs[$type]);
	}

function BOLTconfig($field, $default='') {
## SYSTEM FUNCTION USED TO RETRIEVE CONFIG VALUES FOUND IN SITE CONFIG
	global $BOLTconfig;
	$field = strtolower($field);
	if (isset($BOLTconfig[$field])) return $BOLTconfig[$field];
	return $default;
	}
	
 function BOLTinit($d, $c='', $b='', $a='') {
 ## INITIALIZES A VARIABLE BASED ON FIRST OPTION WITH CONTENT, GOING FROM $A TO $D (DEFAULT).
 	if ($a != '') return $a;
	if ($b != '') return $b;
	if ($c != '') return $c;
	return $d;
 	}

## READ WRITE UTILITIES -- CAN ALLOW DIFFERENT PAGESTORE METHODS SUCH AS DATABASE...
function BOLTread($location) {
	if (function_exists('myBOLTread')) return myBOLTread($location);
	if (function_exists('myBOLTwatch')) myBOLTwatch($location);
	if (! file_exists($location)) return;
	if (filesize($location) == 0 || is_dir($location)) return;
	clearstatcache();
	$handle = fopen($location, "rb");
	$contents = fread($handle, filesize($location));
	fclose($handle);
	return $contents;
	}

function BOLTwrite($location, $content) {
	if (function_exists('myBOLTwrite')) return myBOLTwrite($location, $content);
	if (function_exists('myBOLTwatch')) myBOLTwatch($location);
	$handle = fopen($location, "wb");
	fwrite($handle, $content);
	fclose($handle);
	}


#####################################################################
## FOLLOWING ARE SYSTEM FUNCTIONS USED FOR BOLTWIRE LITE/PRO
## func/command/stopwatch/process/outputpage/redirect/makehtml/getzones
#####################################################################

## THESE FUNCTIONS HANDLE ALL FUNCTIONS/COMMANDS. FREE/PRO VARIATIONS
function BOLTfunc($function, $args, $command='') {
## PREAPARES A CALL TO A FUNCTION. HAS MANY OUTPUT OPTIONS INCLUDING: FALSE, SOURCE, NOLINES, CSV, & ESCAPE
	global $pageLink, $BOLTtoolmap, $BOLTstopWatch, $BOLTstopWatchMsg, $pluginPath; 
	if ($command != 'COMMAND' && $BOLTstopWatch != '') {  ##PRO FEATURE
		if ($args['stopwatch'] == 'true' || inlist('all', $BOLTstopWatch) || inlist('functions', $BOLTstopWatch) || inlist($function, $BOLTstopWatch)) {
			global $BOLTswi; // stopwatch index...
			$i = $i + 1;
			$m = microtime();
			$BOLTswi[$i] = substr($m, -10) . substr($m, 2, 4);
			}
		}
	$function = strtolower($function);
	if ($BOLTtoolmap['f'][$function] != '') $function = $BOLTtoolmap['f'][$function];
	else $function = BOLTtranslate($function, '', true);
//	if (function_exists('myBOLTwatch')) myBOLTwatch("BOLTF$function");	
	if (! function_exists("BOLTF$function")) {
		$where = BOLTvars("site.dynafunc::BOLTF$function", false);
		if ($where == '') return;
		if (file_exists("config/$where")) include_once("config/$where"); 
		elseif (file_exists("$pluginPath/$where")) include_once("$pluginPath/$where"); 
		if (! function_exists("BOLTF$function")) return;
		}
	$BOLTfunction = "BOLTF$function";
	if (BOLTauth($pageLink, $function, 'functions')) $value = $BOLTfunction($args);
	else return;
	if (isset($args['output'])) {
		if (preg_match('/^\~\~([0-9]+)\~\~$/', $value) == 1) { $value = BOLTescape($value, false); $escape = true; }
		$value = BOLToutput($value, $args);
		if ($escape) $value = BOLTescape($value); 
		}
	if ($args['text'] != '') {
		$value2 = BOLTMtexttools(array('', $args['text'], $value));
		if ($value2 != '') return $value2;
		}
	if ($command != 'COMMAND' && $BOLTstopWatch != '') {  ##PRO FEATURE
		if ($args['stopwatch'] == 'true' || inlist('all', $BOLTstopWatch) || inlist('functions', $BOLTstopWatch) || inlist($function, $BOLTstopWatch)) {
			$m = microtime();
			$t2 = substr($m, -10) . substr($m, 2, 4);
			$t = ($t2 - $BOLTswi[$i]) / 10000;
			$mem = ceil(memory_get_usage()/1000) . ' KB';
			$BOLTstopWatchMsg[] = Array("function: $function", '', "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$t", $mem);
			}
		}
	if ($args['escape'] === 'false') return BOLTescape($value, false);
	elseif ($args['escape'] === 'true') return BOLTescape($value);
	if ($args['output'] !== 'false') return $value;
	}

function BOLTcommand($do, $args, $field) {
## PREPARES A COMMAND TO BE CALLED, LIKE BOLTFUNC
	global $BOLTstopWatch, $BOLTstopWatchMsg, $pluginPath;  ##PRO FEATURE 
	if ($BOLTstopWatch != '') {  ##PRO FEATURE
		if ($args['stopwatch'] == 'true' || inlist('all', $BOLTstopWatch) || inlist('commands', $BOLTstopWatch) || inlist($do, $BOLTstopWatch)) {
			global $BOLTswi; // stopwatch index...
			$i = $i + 1;
			$m = microtime();
			$BOLTswi[$i] = substr($m, -10) . substr($m, 2, 4);
			}
		} 
	$value = BOLTinit($args[1], $args['value']);
	if (preg_match('/\~\~([0-9]+)\~\~/', $value) == 1) $value = BOLTescape($value, false);
	if (! function_exists($do)) {
		$where = BOLTvars("site.dynafunc::$do", false);
		if ($where == '') return;
		if (file_exists("config/$where")) include_once("config/$where"); 
		elseif (file_exists("$pluginPath/$where")) include_once("$pluginPath/$where"); 
		if (! function_exists($do)) return $value;
		}
	$value = $do($value, $field, $args);
	if (isset($args['output'])) {
		if (preg_match('/^\~\~([0-9]+)\~\~$/', $value) == 1) { $value = BOLTescape($value, false); $escape = true; }
		$value = BOLToutput($value, $args);
		if ($escape) $value = BOLTescape($value); 
		}
	if ($args['text'] != '') $value = BOLTMtexttools(array('', $args['text'], $value));
	if ($args['escape'] === 'true') $value = BOLTescape($value); 
	else $value = BOLTescape($value, false);
	if ($BOLTstopWatch != '') {  ##PRO FEATURE
		if ($args['stopwatch'] == 'true' || inlist('all', $BOLTstopWatch) || inlist('commands', $BOLTstopWatch) || inlist($do, $BOLTstopWatch)) {
			$m = microtime();
			$t2 = substr($m, -10) . substr($m, 2, 4);
			$t = ($t2 - $BOLTswi[$i]) / 10000;
			$mem = ceil(memory_get_usage()/1000) . ' KB';			
			$BOLTstopWatchMsg[] = Array("command: $do", '', "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$t", $mem);
			}
		}
	if ($args['output'] !== 'false') return $value;
	}

## THIS IS THE PRO STOPWATCH FUNCTION
function BOLTstopWatch($text) {  ##PRO FEATURE
## A SPECIAL FUNCTION TO HELP BENCHMARK PROCESSES ON BOLTWIRE SITES. TO USE, SET $BOLTstopWatch='all'; IN INDEX.PHP BEFORE CALLING ENGINE (or true, functions, commands, search, breadcrumb, etc) 
	global $BOLTstopWatch, $BOLTstopWatchMsg, $BOLTstopWatchTime;
	if (! $BOLTstopWatch) return;
	$now = (time() . substr(microtime(), 0, 5)) * 1000;
	$display = $now;
	if (strlen($display) == 14) $display = $display . '0';
	elseif (strlen($display) == 13) $display = $display . '00';
	elseif (strlen($display) == 12) $display = $display . '000';
	if ($BOLTstopWatchTime == '') {
		$BOLTstopWatchTime = $now;
		return;
		}
	if ($now != $BOLTstopWatchTime) {
		$duration = ($now - $BOLTstopWatchTime) / 10000;
		if (strlen($duration) == 5) $duration = $duration . '0';
		elseif (strlen($duration) == 4) $duration = $duration . '00';
		elseif (strlen($duration) == 3) $duration = $duration . '000';
		}
	else $duration = "0.0000";
	$BOLTstopWatchTime = $now;
	$mem = ceil(memory_get_usage()/1000) . ' KB';	
	$BOLTstopWatchMsg[] = Array($text, $display, $duration, $mem);
	}

function BOLTstopWatchPrint() {
	global $BOLTstopWatchMsg;
	foreach($BOLTstopWatchMsg as $swmsg) {
		$out[] = "<tr><td>$swmsg[0]</td><td>$swmsg[1]</td><td>$swmsg[2]</td><td>$swmsg[3]</td></tr>";		
		}
	return "<div class='stopwatch'><table border=1>" . implode("\n", $out) . "</table></div>";
	}

## USED TO RUN AN ARRAY OF STARTUP-, PRE-, POST-, AND BACKGROUND- PROCESSES
function BOLTprocess($event) { 
	global $BOLTprocess;
	$job = $BOLTprocess[$event];
	if (function_exists($job)) $job();
	}

## BUFFERED OUTPUT OF PAGE TO BROWSER
function BOLToutputPage($out, $nextpage='') {  
	ob_end_clean();
	header("Connection: close");
	ob_start();
	echo($out);
	$size = ob_get_length();
	header("Content-Length: $size");
	ob_end_flush();
	flush(); 
	ignore_user_abort();
	set_time_limit(180);
	BOLTprocess('background'); // run final function(s)
	exit;
	}

## FINAL OUTPUT OF PAGE TO BROWSER FOR FORWARDS
function BOLTredirect($nextpage) {
## USED TO REDIRECT THE PAGE TO ANOTHER LOCATION. REQUIRES RESTART OF ENTIRE PROGRAM
	global $scriptURL, $cleanURL, $BOLTsession, $BOLTfield, $pageLink;  // $BOLTformKeys
	$nextpage = BOLTinit($pageLink, BOLTstripQuotes($nextpage));
	$BOLTsession['PASSFORM']['submit'] = $_POST['submit'];
	if (strpos($nextpage, '://') === false) {
		$nextpage = BOLTpageshortcuts($nextpage);
		$nextpage = str_replace('&amp;', '&', $nextpage);
		if (isset($cleanURL)) $nextpage = $cleanURL . preg_replace_callback('/^([-_0-9a-zA-Z\.]+)/', function($m) { return str_replace('.', '/', $m[1]); }, $nextpage);
		else $nextpage = "$scriptURL$nextpage";
		}
	if (strpos($nextpage, '#') !== false) {  // corrects for anchors and gets
		$page = substr($nextpage, 0, strpos($nextpage, '#'));
		$anchor = substr($nextpage, strpos($nextpage, '#'));
		if (strpos($anchor, '&') !== false) {
			$get = substr($anchor, strpos($anchor, '&'));
			$anchor = substr($anchor, 0, strpos($anchor, '&'));
			$nextpage = "$page$get$anchor";
			}
		}
	if (strpos($nextpage, '?') === false && strpos($nextpage, '&') !== false) {
		$pos = strpos($nextpage, '&');
		$nextpage = substr($nextpage, 0, $pos) . '?' . substr($nextpage, $pos + 1);
		}
	if ($nextpage != '') {
		header("Location: $nextpage");
		header("Content-type: text/html");
		}
	session_start();
	$_SESSION = Array();
	$_SESSION[$BOLTfield] = $BOLTsession;
	session_write_close();
	$out = "<html><head><meta http-equiv=Refresh></head><body></body></html>";
	BOLTindexSetup();
	BOLTprocess('post');  
	if (BOLTconfig('bufferOutput', 'false') == 'true') BOLToutputPage($out, $nextpage);
	else print_r($out);
	exit;
	}

## CREATE BASIC PAGE
function BOLTmakeHTML($out) {
	global $pageLink, $BOLTvar, $BOLTreplaceHTML, $actionPage;
// USE FOR 7.xx
//	$out = preg_replace_callback('/\<\<(.*?)\>\>/', function($m) { return BOLTskinResource($m[1]); }, $out);
// NEXT TWO LINES DEPRECATED IN 7.xx  
   $out = preg_replace_callback('/\<\<([-_a-z0-9\.]+)\>\>/i', function($m) { return BOLTloadskin($m[1]); }, $out);  // Code zone--like <<css>> 
   $out = preg_replace_callback('/\=\=(.*?)\=\=/', function($m) use ($pageLink) { return BOLTdomarkup($m[1], $pageLink, 'SKIN'); }, $out); 
	preg_match_all('/\[\[([-_a-z0-9 \.\=\,]+)\]\]/i', $out, $matches);  // identify zones
	foreach($matches[1] as $zone) {
		if (strpos($zone, ' ') !== false) $zone = substr($zone, 0, strpos($zone, ' '));
		if ($zone != 'cache') $BOLTvar['zones'] = "$BOLTvar[zones],$zone";	
		$p = BOLTgetlink($zone);
		if ($zone == 'main' && ! BOLTexists($p)) {
			$BOLTvar["zone_$zone"] = BOLTgetlink('missing', 'action');
			$actionPage = 'missing';
			}
		else $BOLTvar["zone_$zone"] = $p;
		}
	$BOLTvar['zones'] = ltrim($BOLTvar['zones'], ',');
	foreach($matches[1] as $match) {
		$zoneargs = BOLTargs($match);
		$zone = $zoneargs[1];
		BOLTstopWatch("Zone x $zone begun");		
		$out = str_replace("[[$match]]", BOLTgetzones($zone, $zoneargs), $out);  // Do each zone
		BOLTstopWatch("Zone $zone complete");
		}
	$out = BOLTescape($out, false);  // Undo escaped content
	$out = preg_replace_callback('/\[messages( ([-_,a-zA-Z0-9=]+))?\]/i', function($m) { return BOLTmessageDisplay($m[1]); }, $out);  // Display messages
	if (BOLTconfig('robotBlock') != '') {  // can turn specific pages off for robots. Use site*,test.block
		if (BOLTpageCheck(BOLTconfig('robotBlock'))) {
			$BOLTreplaceHTML['find'][] = '</head>';
			$BOLTreplaceHTML['replace'][] = "<meta name='robots' content='noindex'>\n</head>";
			}
		}
	if (is_array($BOLTreplaceHTML)) $out = str_replace($BOLTreplaceHTML['find'], $BOLTreplaceHTML['replace'], $out);  // Any custom code replacements
	return $out;
	}

## REPLACE SKIN ZONE MARKERS [[ZONE]] WITH CONTENT: GETS LINK, LOADS PAGE, DOES MARKUP
function BOLTgetzones($zone, $args=[]) {
	global $pageLink, $actionPage, $pageShow, $BOLTzone, $BOLTcache, $p1, $BOLTvar, $BOLTtime;
	if (function_exists('myBOLTgetzones')) return myBOLTgetzones($zone);
	$BOLTzone = strtolower($zone);
	if (inlist($BOLTzone, 'header,footer') && $actionPage != '') {
		if (BOLTconfig('actionHeaders', 'false') != 'true') return;
		}
	if ($_GET['action'] == 'print' && $_GET[$BOLTzone] === 'false') return; // allows you to disable zones for printing
	if ($args['page'] != '') $pageShow = $args['page'];
	elseif ($BOLTzone == 'main') $pageShow = BOLTinit($pageLink, $actionPage);
	else $pageShow = BOLTgetlink($BOLTzone);
	if ($BOLTzone == 'main' && ! BOLTexists($pageShow)) $pageShow = $BOLTvar["zone_$zone"];
	$out = BOLTloadpage($pageShow);
	$p1 = substr($pageShow, 0, strpos($pageShow, "."));
	if ($BOLTzone == 'main' && inlist($p1, 'code,template')) return '<div class=box>' . BOLTcharEncode($out, 'lines') . '</div>';
	return BOLTdomarkup($out, '', '', $args['rules']);
	}


// THIS CAN BE USED TO CREATE BEAUTIFUL AUTO UPDATING PAGES
// $auto is name of code.auto.id that does the auto action (require a autoid function)
// Must have a script on actual page that calls loadAuto and outputs a link like:
// return BOLTescape("<a href=javascript:void(0); onclick=BOLTauto('$parameters') >LINK</a>"); 
