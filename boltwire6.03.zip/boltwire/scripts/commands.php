<?php if (!defined('BOLTWIRE')) exit();

########################################
##  BOLTWIRE FORM COMMANDS            ##
##  Copyright 2019 Dan Vis            ##
##  See license.txt for details       ##
########################################


function BOLTXauthkey($value, $field, $args=[]) {
	if (BOLTfilter($value, 'letters') == '') return;
	global $BOLTgroups;
	$BOLTgroups = $BOLTgroups . ",key_$value"; // put @key_$value on site.auth page
	}

function BOLTXcreate($value, $field, $args=[]) {
	global $BOLTid, $pageLink;
	$page = BOLTinit($pageLink, $args['page']);
	$content = BOLTinit($value, $args['value'], $args['content']);
	if (!BOLTauth($page, $BOLTid, 'write')) return BOLTabort('create_fail_auth');
	if (BOLTexists($page)) return BOLTabort("create_fail_exists::$page");
	if (BOLTexists($args['template'])) $content = BOLTloadpage($args['template']);  // use a template to construct the page
	if ($args['replace'] === 'true') $content = preg_replace_callback('/\\{\\=(\\w+)\\}/', function($m) { return BOLTfieldreplace($m[1]); }, $content);  // {=field} replacements
	if ($args['vars'] === 'true') $content = preg_replace_callback('/\\{\\+(\\w+)\\}/', function($m) { return BOLTvars($m[1]); }, $content);  // {+var} replacements
	if ($args['lines'] != '') {
		if ($args['lines'] == 'false') $content = str_replace("\n", '\n', $content); // condense
		if ($args['lines'] == 'true') $content = str_replace('\n', "\n", $content); // expand
		}
	if ($args['data'] != '') {
		if($args['data'] == 'true') $args['data'] = $pageLink;
		$data = BOLTloadpage($args['data'], '', 'data');
		$data = substr($data, strpos($data, "\n~data~"));
		}
	BOLTsavepage($page, $content, $data, true);
	BOLTmessage("create_success::$page", $args);
	return $value;
    }

function BOLTXcsv($value, $field, $args=[]) {
	$data = $args[1];
	$current = BOLTinit($args[2], $args['current']);
	$new = BOLTcsv($data, $current);
	if ($args['reset'] != '') BOLTXreset('', '', Array($args['reset']=>$new));
	return $new;
	}

function BOLTXdelete($value, $field, $args=[]) {
	global $pageLink, $BOLTid, $systemPath, $BOLTindexPages;
	$page = BOLTinit($value, $args['page']);
	if ($page == '') return;
	$page = BOLTpageshortcuts($page);
	$fpage = BOLTfolders($page);
	if (BOLTauth($page, $BOLTid, 'write') == false) return BOLTabort("delete_fail_auth::$page");
	if (BOLTexists($page) == false) return BOLTabort("delete_fail_exist::$page");
	if (file_exists("pages/$fpage")) unlink("pages/$fpage");
	elseif (file_exists("$systemPath/$page")) BOLTsavepage($page, ' ');  // sort of delete system pages
	$BOLTindexPages[] = $page;
	BOLTmessage("delete_success_$c::$page", $args);
	clearstatcache();
	}

function BOLTXedit($value, $field, $args=[]) {
	global $BOLTid, $pageLink;
	$page = BOLTinit($pageLink, $args['page']);
	$content = BOLTinit($value, $args['content']);
	if (!BOLTauth($page, $BOLTid, 'write')) return BOLTabort("edit_fail_auth::$page");
	if ($content == '') $content = ' ';
	if ($args['lines'] != '') {
		if ($args['lines'] == 'false') $content = str_replace("\n", '\n', $content); // condense
		if ($args['lines'] == 'true') $content = str_replace('\n', "\n", $content); // expand
		}
	BOLTsavepage($page, $content, '', $args['loadtime']);
	BOLTmessage('edit_success', $args);
	}

function BOLTXif($value, $field, $args=[]) {
	global $BOLTcommands, $BOLTnextpage;
	$if = substr($value, 0, strpos($value, " ? "));
	$then = substr($value, strpos($value, " ? ") + 3);
	if (strpos($then, ' : ') === false) $acts['true'] = explode(' , ', $then);
	else {
		$acts['true'] = explode(' , ', substr($then, 0, strpos($then, ' : ')));  //true
		$acts['false'] = explode(' , ', substr($then, strpos($then, ' : ') + 3)); //false
		}
	if (BOLTiftrue($if, 'x') == 'x') $result = 'true'; else $result = 'false';

	if (! is_array($acts[$result])) return $result;
	foreach ($acts[$result] as $act) {
		list($f, $v) = explode('=', $act,2);
		if (isset($_POST[$f])) $_POST[$f] = $v;
		else $BOLTcommands[$f] = $v;
		if ($f == 'nextpage') $BOLTnextpage = $v;
		}
	return $result;
	}

function BOLTXindex($value, $field, $args=[]) {
	if ($value != '') $out = BOLTindexAuto(explode(',', $value));  // indexes pages
	else $out = BOLTindex($args['rule']);  // works through a list, or general indexing if no list indicated
	BOLTmessage("The following pages have been indexed: $out", $args);
	return $out;
	}

function BOLTXinfo($value, $field, $args=[]) {
	$args['value'] = str_replace(Array("\r\n", "\n", "\r"), '\n', trim($args['value'], "\n"));
	return BOLTfunc('info', $args, 'COMMAND');
	}

function BOLTXlist($value, $field, $args=[]) {
	return BOLTfunc('list', $args, 'COMMAND');
	}

function BOLTXlog($value, $field, $args=[]) {
	$args['content'] = BOLTinit($value, $args['value'], $args['content']);
	if ($args['lines'] === 'false') $args['content'] = str_replace(array("\r\n", "\r", "\n"), '\n', $args['content']);
	return BOLTfunc('log', $args, 'COMMAND');
	}

function BOLTXlogin($value, $field, $args=[]) {
	$id = BOLTinit($_POST['id'], $args['id']);
	$pass = BOLTinit($_POST['password'], $args['password']);
	if ($args['keys'] != '') $id = BOLTinit($id, BOLTvars($args['keys'] . "::$id", false));
	if ($id == '' || $pass == '') return BOLTabort('login_fail', $args);
	global $BOLTid;
	if ($BOLTid != '') return BOLTabort('login_problem', $args);
	$id = strtolower(BOLTutf2url($id));
	$page = "member.$id";
	if ($id == '' || ! BOLTexists($page)) return BOLTabort('login_fail', $args);
	$pass1 = BOLTcrypt($pass);
	$pass2 = BOLTvars("$page:password", false);
	if ($pass2 == '') return BOLTabort('login_fail', $args);
	if ($pass1 != $pass2) return BOLTabort('login_fail', $args);
	$args['pass'] = $pass;
	BOLTlogin($id, $args);
	return 'true';
	}

function BOLTXlogout($value, $field, $args=[]) {
	BOLTlogout($args);
	}

function BOLTXmail($value, $field, $args=[]) {
	return BOLTfunc('mail', $args, 'COMMAND');
	}

function BOLTXmath($value, $field, $args=[]) {
	return BOLTfunc('math', $args, 'COMMAND');
	}

function BOLTXmemberships($value, $field, $args=[]) {
	deprecate('memberships', '', $pageLink);
	return BOLTXgroups($value, $field, $args=[]);
	}

function BOLTXgroups($value, $field, $args=[]) {
	global $BOLTid;
	$id = BOLTinit($BOLTid, $args['id']);
	if ($args['join'] != '') {
		$group = 'group.' . $args['join'];
		if (BOLTexists($group) && BOLTauth($group, $BOLTid, 'write')) BOLTlog($id, $group, "\n", 'unique');
		else BOLTmessage('membership_auth_join::'.$args['join'], $args);
		}
	if ($args['drop'] != '') {
		$group = 'group.' . $args['drop'];
		if (BOLTexists($group) && BOLTauth($group, $BOLTid, 'write')) BOLTlog($id, $group, "\n", 'remove');
		else BOLTmessage('membership_auth_drop::'.$args['drop'], $args);
		}
	return BOLTfunc('memberships', $args, 'COMMAND');
	}

function BOLTXmsg($value, $field, $args=[]) {
	$id = BOLTinit($field, $args['id']);
	BOLTmessage($id, $args, $value);
	return;
	}

function BOLTXnextpage($value, $field, $args=[]) {
	global $BOLTnextpage;
	if ($value == '') return;
	$BOLTnextpage = BOLTstripQuotes($value);
	return $BOLTnextpage;
	}

function BOLTXpassdata($value, $field, $args=[]) {
	global $BOLTsession, $BOLTcommands, $BOLTfield, $BOLTpassdata, $BOLTcookiePath;
	$value = BOLTfilter($value, 'csv');
	if ($value == '') return;
	if ($args['mode'] == 'cookie') $path = BOLTinit('/', $BOLTcookiePath);
	$f = explode(",", $value);
	foreach ($f as $ff) {
		$check = BOLTinit($_POST[$ff], $BOLTcommands[$ff]);
		if (is_array($check)) $check = implode(',', $check);
		if ($check != '') {
			switch($args['mode']) {
				case 'post': $BOLTsession['PASSFORM'][$ff] = $check; break;
				case 'cookie':
					$exp = $args['expires'];
					if (strlen($exp) < 10) $exp = time() + $exp;
					setcookie($ff, $check, $exp, $path);
					break;
				default: $BOLTpassdata .= "&$ff=" . urlencode($check);  // mode = get
				}
			}
		}
	return $BOLTpassdata;
	}

function BOLTXregister($value, $field, $args=[]) {
	$id = BOLTinit($_POST['id'], $args['id']);
	if ($id == '') return BOLTabort('register_no_id');
	$id = BOLTpageshortcuts(BOLTutf2url($id));
	$page = "member.$id";
	if (! BOLTfilter($page, 'page') || inlist(substr($page, 0, 1), '-,_')) return BOLTabort('register_invalid_name');
	if (BOLTexists($page)) return BOLTabort('register_member_exists');
	if (! BOLTauth($page, $id, 'write')) return BOLTabort('register_fail_auth');
	$pass = BOLTinit($_POST['password'], $args['password']);
	if ($pass == '') return BOLTabort('register_no_pass');
	$pass = BOLTcrypt($pass);
	$data = Array('password'=>$pass);
	if ($value != '') {
		$fields = explode(',', $value);
		foreach ($fields as $field) $data[$field] = $_POST[$field];
		}
	BOLTsavedata($data, $page, false);
	if (! BOLTexists($page)) return BOLTabort('register_fail');
	if ($args['login'] == 'true') BOLTlogin($id, $args);
	return BOLTmessage('register_success', $args);
	}

function BOLTXrename($value, $field, $args=[]) {
	global $BOLTindexPages, $BOLTid, $systemPath;
	$from = BOLTpageshortcuts($args['from']);
	if (BOLTexists($from) == false) return BOLTabort("rename_fail_nofile::$from");
	$to = BOLTpageshortcuts($args['to']);
	if (BOLTexists($to) != false) return BOLTabort("rename_fail_exists::$from::$to");
	if (!BOLTauth($to, $BOLTid, 'write')) return BOLTabort("rename_fail_auth::$to");
	$to2 = BOLTfolders($to);
	$from2 = BOLTfolders($from);
	if ((file_exists("$systemPath/$from")) && (! file_exists("pages/$from2"))) $success = copy("$systemPath/$from", "pages/$to2");
	else $success = rename("pages/$from2", "pages/$to2");
	if ($success) {
		BOLTmessage("rename_success::$from", $args);
		if ($args['renamestamps'] == 'true') BOLTrenametree($from, $to, 'stamps', $args);
		$BOLTindexPages[] = $to;
		$BOLTindexPages[] = $from;
		}
	else BOLTmessage("rename_fail::$from", $args);
	}

function BOLTXreset($value, $field, $args=[]) {
	global $BOLTcommands, $BOLTsession;
	foreach ($args as $f => $v) {
		if (isset($_POST[$f])) {
			$_POST[$f] = $v;
			$BOLTsession['PASSFORM'][$f] = $v;
			}
		elseif (isset($BOLTcommands[$f])) $BOLTcommands[$f] = $v;
		}
	return $value;
	}

function BOLTXsavedata($value, $field, $args=[]) {
	$value = BOLTfilter($value, 'csv');
	if ($value == '') return;
	global $pageLink, $BOLTid;
	$page = BOLTinit($pageLink, $args['page']);
	$page = BOLTpageshortcuts($page);
	if (BOLTconfig('dataAuth', 'true') !== 'false' && BOLTauth($page, $BOLTid, 'write') !== true) return BOLTabort("savedata_auth::$page");
	$fields = explode(',', $value);
	foreach ($fields as $field) {
		if ($field == '') continue;
		$field = trim($field);
		$value = BOLTstripQuotes(BOLTfieldreplace($field, $args));
		if ($args['mode'] == 'info') BOLTinfoPoke($page, $field, $value);
		else $data[$field] = $value;
		}
	if ($args['mode'] != 'info') BOLTsavedata($data, $page);
	return BOLTmessage('data_success', $args);
	}

function BOLTXsearch($value, $field, $args=[]) {
	$out = BOLTescape(BOLTfunc('search', $args, 'COMMAND'), false);
	return $out;
	}

function BOLTXquery($value, $field, $args=[]) {
	$out = BOLTescape(BOLTfunc('query', $args, 'COMMAND'), false);
	return $out;
	}

function BOLTXsource($value, $field, $args=[]) {
	$out = BOLTescape(BOLTfunc('source', $args, 'COMMAND'), false);
	return $out;
	}

function BOLTXstamp($value, $field, $args=[]) {
	global $BOLTid, $pageLink, $systemPath, $BOLTtime;
	if ($value == '') $page = $pageLink;
	else $page = BOLTfilter(BOLTpageshortcuts($value), 'page');
	if(! BOLTexists($page)) return BOLTmessage("stamp_no_file::$page", $args);
	$content = BOLTloadpage($page, '', 'data');
	$stamp = "$page.$BOLTtime";
	BOLTwrite("stamps/$stamp", $content);
	if(file_exists("stamps/$stamp")) BOLTmessage("stamp_success::$value", $args);
	else BOLTmessage("stamp_fail::$value", $args);
	$expire = BOLTconfig('stampsExpire', 90);  // clear out old stamps...
	$max = BOLTconfig('stampsMax', 7);
	$min = BOLTconfig('stampsMin', 1);
	if ($expire != '' || $max != '') {
		$time = $BOLTtime - ($expire * 86400);
		$pages = BOLTlistpages(NULL, 'stamps');
		if (is_array($pages)) {
			$pages = array_reverse($pages);
			foreach ($pages as $p) {
				$base = substr($p, 0, -11);
				$count[$base] = $count[$base] + 1;
				if ($count[$base] > $min && substr($p, -10) < $time) unlink("stamps/$p");
				if ($count[$base] > $max) unlink("stamps/$p");
				}
			}
		}
	}

function BOLTXtime($value, $field, $args=[]) {
	if ($args['fmt'] == '') $args['fmt'] = 'timestamp';
	return BOLTfunc('time', $args, 'COMMAND');
	}

function BOLTXtranslate($value, $field, $args=[]) {
	$lang = BOLTinit($args['language'], $args[2]);
	return BOLTtranslate($value, $lang, $args['reverse'], $args['case']);
	}

function BOLTXunstamp($value, $field, $args=[]) {
	if ($value == '') return;
	global $BOLTid;
	$stamp = BOLTpageshortcuts($value);
	$page = substr($stamp, 0, -11);
	if (BOLTauth($page, $BOLTid, 'write') == false) return BOLTabort("unstamp_fail_auth::$page");
	$content = BOLTloadpage($stamp, 'stamps', 'data');
	if ($content == '') return BOLTabort("unstamp_fail_content::$page");
	if (strpos($content, '~data~')) {
		$data = substr($content, strpos($content, '~data~'));
		$content = substr($content, 0, strpos($content, '~data~'));
		}
	BOLTsavepage($page, $content, $data);
	BOLTmessage("unstamp_success::$in", $args);
	}

function BOLTXupload($value, $field, $args=[]) {
    global $pageLink, $BOLTid;
    if (BOLTauth($pageLink, $BOLTid, 'uploads') == false) return BOLTabort('upload_fail_auth');
    $types = BOLTconfig('uploadImgTypes', 'gif,jpg,jpeg,png,svg');
    $types .= ','.BOLTconfig('uploadFileTypes', 'txt,pdf');
    $a_types = BOLTinit($types, $args['types']);
    $size = BOLTconfig('uploadSize', 100000);
    $a_size = BOLTinit($size, $args['size']);
    $case = BOLTconfig('uploadCase', false);
    $a_case = BOLTinit($case, $args['case']);
    $dir = BOLTinit('files', $args['dir']);
    $field = BOLTinit($field, $args['file']);
    $current_filename = $_FILES[$field]['name'];
    if (trim($current_filename) === '') return BOLTabort("upload_no_file::$field");
    if (strpos($current_filename, '.') === false) return BOLTabort("upload_no_ext");

    $type = strtolower(substr($current_filename, strrpos($current_filename, '.') + 1));
    if (! inlist($type, $types) || ! inlist ($type, $a_types)) return BOLTabort("upload_fail_type::$type");
    $new_filename = BOLTinit($current_filename, $args['name']);
    if ($a_case !== 'true') $new_filename = strtolower($new_filename);
    $dotIndex = strrpos($new_filename, '.');
    if($dotIndex === FALSE) {
        $newtype = $type;
        $new_filename = $new_filename.'.'.$type;
        }
    else $newtype = strtolower(substr($new_filename, $dotIndex + 1));
	if ($newtype != $type) {
		if (! inlist($type, 'jpg,jpeg')) return BOLTabort("upload_error::$new_filename");  // other file types can't be changed
	    if (! inlist($newtype, 'jpg,jpeg')) return BOLTabort("upload_error::$new_filename"); // jpg and jpeg can only be changed to each other
		}
    if (BOLTconfig('uploadsStrict', 'true') == 'true') {
        if (BOLTfilter($current_filename, 'uploads') == '' || BOLTfilter($new_filename, 'uploads') == '') return BOLTabort("upload_error::$new_filename");
        }
    if ($dir != 'files') {
        $check = BOLTfilter($dir, '-_a-z0-9');
        if ($check == '') return BOLTabort("upload_fail_dir::$dir");
        $dir = "files/$check";
        }
    BOLTfixdir($dir, false);
    if ($_FILES[$field]['error'] != UPLOAD_ERR_OK) return BOLTabort("upload_error::$new_filename");
    if ($_FILES[$field]['size'] > $size || $_FILES[$field]['size'] > $a_size ) return BOLTabort("upload_fail_size::$new_filename");
    $success = move_uploaded_file($_FILES[$field]['tmp_name'], "$dir/$new_filename");
    if ($success) {
        chmod("$dir/$new_filename", 0644);
        BOLTmessage("upload_success::$new_filename", $args);
        }
    else BOLTmessage("upload_fail::$new_filename", $args);
    clearstatcache();
    $_POST[$field] = $new_filename;
	return $new_filename;
    }

function BOLTXwarn($value, $field, $args=[]) {
	if ($value == '') return;
	$id = BOLTinit($field, $args['id']);
	return BOLTabort($id, $args, $value);
	}
