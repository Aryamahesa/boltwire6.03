<?php if (!defined('BOLTWIRE')) exit();

########################################
##  BOLTWIRE MARKUP TABLE             ##
##  Copyright 2019 Dan Vis            ##
##  See license.txt for details       ##
########################################


// MARKUP TABLE
MarkUp('pre', 'escape', '/\`(.){1}/s', 'BOLTMescape');  // `escape char
MarkUp('pre', 'nomarkup', '/\/\=(.*?)\=\//s', 'BOLTnomarkup');  // /=no markup=/
MarkUp('pre', 'comments', '/(?<=[^\/]|^)\/\*[^\*](.*?)[^\*]\*\/(?=[^\/]|$)/s', 'BOLTnull');  // / *comments* /
MarkUp('pre', 'boxes', '/(<|&lt;)(box|html|code|markup|debug)( .*?)?>(.*?)(<|&lt;)\/\2>/si', 'BOLTMbox');  // <box,html,code,markup rules='', lines=false>

MarkUp('vars', 'request', '/\{\?([.-_a-zA-Z0-9]+)\}/', 'BOLTMrequest');  // {?var}
MarkUp('vars', 'var', '/\{([^~{}()+=*:$ ]+)\}/', 'BOLTMvars');  // {var}
MarkUp('vars', 'var2', '/\{([^~{}()+=*$ ]+)\}/', 'BOLTMvars');  // {page:var}
MarkUp('vars', 'var3', '/\{([^~{}()+=$ ]+)\}/', 'BOLTMvars');  // {page:var}
MarkUp('vars', 'member',  '/\{\~([^{}+=*$ ]+)\}/', 'BOLTMmemberVar');  // {~var}

MarkUp('func', 'vars', '/\{\((.*?)\)\}/', 'BOLTMfunc');  // {(func params)}
MarkUp('func', 'math', '/\{ ([\-\+\*\/\.0-9\(\)]+) \}/', 'BOLTMmath');  // { 1+1 }
MarkUp('func', 'func', '/\[\((.*?)\)\]/', 'BOLTMfunc');  // [(func params)]

MarkUp('if', 'if', '/\[(if|else)(.*?)\]/s', 'BOLTMif');  // [if]
MarkUp('if', 'true', '/\[true([0-9]{1}) (.*?)\](.*?)\[true\1\]/s', 'BOLTMifnest');

MarkUp('form', 'func', '/(&lt;|<)\((.*?)\)(&gt;|>)/', 'BOLTMfunc');  // <(func params)>
MarkUp('form', 'inputs', '/(\n?)\[(form|command|text|check|radio|password|hidden|select|option|optgroup|box|file|button|submit|reset|image)(( {1,2}([-_a-z0-9]+=)?([-_a-z0-9]+\[\]|\"[^\"]*\"|\'[^\']*\'|[^\] ]+))*)? ?\]/i', 'BOLTMinputs');  // form and all inputs

MarkUp('symbols', 'symbol', '/\((\w{1,2})\)/', 'BOLTMsymbol');
MarkUp('symbols', 'entities', '/&amp;([a-z0-9]+|#\\d+|#[x][a-f0-9]+);/i', 'replace', '&$2;');
MarkUp('symbols', 'spaces', '/([ ]{3,}|[\t]+|[\n]{3,})/', 'BOLTMspacing');  // spaces, tabs, and linebreaks
MarkUp('symbols', 'indent1', '/\-\>/', 'replace', '<blockquote>'); // -> <- indent (blockquote)
MarkUp('symbols', 'indent2', '/(&lt;|<)\-/', 'replace', '</blockquote>'); // -> <- indent (blockquote)
MarkUp('symbols', 'hr', '/^\-\-\-\-$/m', 'replace', "\n<hr />\n"); // ---- horizontal line
MarkUp('symbols', 'translate', '/\+\+(.+?)\+\+/m', 'BOLTMtranslate'); // ++translated text++

MarkUp('links', 'uploads', '/\[\^(.*?)\^\]/', 'BOLTMuploads'); // [^ ^] upload
MarkUp('links', 'shortlinks', '/(img|file|link|button|url|re)\:([-_a-zA-Z0-9\.\&\?\=]+)/', 'BOLTMshortlinks');  // img:file.gif
MarkUp('links', 'links', '/\[\[(.*?)\]\]/', 'BOLTMlinks');  // [[ ]]
MarkUp('links', 'urls', '/\:\/\/([a-z0-9]+)/i', 'BOLTMurls');  //used to so links not italicized

MarkUp('bullets', 'bullets', '/(^|\n)((([*#=]+ )(.*?)(\n|$))+)/', 'BOLTMbullets'); // list block

// shouldn't need box, p, a. Probably not  ul ol or li...  Just have div and span
MarkUp('style', 'style', '/&lt;(\/)?(div|p|span|a|ul|ol|li|blockquote)( .*?)?\>/i', 'BOLTMstyles');
MarkUp('style', 'fonts', '/((\*|\/|\_|\||@|#|\=)(\2+))(.+?)(\1|$)/m', 'BOLTMfontstyles');  // Misc shortcuts *Bo/It_Un|Hi@Sp#Bx=St...
MarkUp('style', 'color', '/(&lt;|<)(color|highlight)\=[\'"]?([a-zA-Z0-9\#]{3,25})[\'"]?>(.*?)(&lt;|<)\/\2>/si', 'BOLTMspandivsColor'); // <color=red> or <highlight=green>
MarkUp('style', 'size', '/(&lt;|<)size\=[\'"]?([a-zA-Z0-9\%]{1,9})[\'"]?>(.*?)(&lt;|<)\/size>/si', 'BOLTMspandivsSize'); // <size=125% >
MarkUp('style', 'align', '/(&lt;|<)(left|right|center|justify)>(.*?)(&lt;|<)\/\2>/si', 'BOLTMspandivsAlign');  // left, right, center
MarkUp('style', 'text', '/(&lt;|<)text ([^>]+)?>(.+?)(&lt;|<)\/text>/s', 'BOLTMtexttools'); // <text substring=1,2> etc
MarkUp('style', 'html', '/&lt;([\/]?)([a-z0-9]+)( ?\/)?>/i', 'BOLTMhtml');  // allowed html
MarkUp('style', 'tags', '/([^\#\[\'\"\=\:]\#([a-z]{1}[a-z0-9]*))\b/i', 'BOLTMtags');

MarkUp('block', 'headers', '/^(!{1,3})(.*)/m', 'BOLTMheaders');
MarkUp('block', 'table', '/\[([trch])([1-9]?)( .*?)?\]/i', 'BOLTMtables');  // [t] [r] [c]
MarkUp('block', 'nolines', '/(&lt;|<)nolines(&gt;|>)(.*)\1\/nolines\2/Us', 'BOLTnolines');  // <nolines>

//MarkUp('debug', 'debug', '/~~DEBUG~~/i', 'die()');
## END MARKUPTABLE

// These are helper functions to use the new markup table...
function BOLTMescape($m) { return BOLTescape($m[1]); }
function BOLTnomarkup($m) { return BOLTcharEncode(BOLTstripSlashes($m[1])); }
function BOLTMvars($m) { return BOLTvars($m[1]); }
function BOLTnull($m) { return; }
function BOLTMmath($m) { return BOLTMfunc(array('', "math $m[1]")); }
function BOLTMspandivsColor($m) { return BOLTMspandivs(array('', $m[2], $m[3], $m[4])); }
function BOLTMspandivsSize($m) { return BOLTMspandivs(array('', 'size', $m[2], $m[3])); }
function BOLTMspandivsAlign($m) { return BOLTMspandivs(array('', 'align', $m[2], $m[3])); }
function BOLTMurls($m) { return BOLTescape("://$m[1]"); }
function BOLTnolines($m) {	return BOLTescape(BOLTstripSlashes($m[3])); }
function BOLTMtranslate($m) { return BOLTtranslate($m[1]); }

function BOLTMbox($m) {
	$attr = $m[3];
	$text = $m[4];
	$type = $m[2];
	global $pageLink, $BOLTattrs;
	$attr = BOLTstripSlashes($attr);
	$args = BOLTargs($attr);
	$type = BOLTinit('box', $type, $args['1'], $args['type']);	//types: box html code markup debug comment
	if ($type == 'hidden') return;
	if (strpos($text, "\n") === false) $sd = 'span';  // span or div
	else { $sd = 'div'; $spaced = true; }
	$text = BOLTstripSlashes($text);  // clean up text
	if ($args['trim'] !== 'false') $text = BOLTtrimLines($text);
	if ($args['class'] == '') $args['class'] = 'box';
	$attr = '';  // setup allowed attrs
	foreach($args as $f => $v) {
		if (inlist($f, $BOLTattrs[$sd])) $attr .= " $f='$v' ";
		}
	$attr = BOLTescape($attr);
	if (inlist($type, 'code,markup,debug')) {  // sets up code box
		$code = BOLTescape(trim($text), false);
		$code = str_replace(Array(' &#63; ', ' &#58; ', ' &#44; '), Array(' ? ', ' : ', ' , '), $code);
		$code = BOLTcharEncode($code, 'lines');
		$code = BOLTescape("<$sd $attr>$code</$sd>", '', $spaced);
		if ($sd == 'div') $code = "\n$code\n";
		if ($type == 'code') return $code;
		}
	$out = BOLTdomarkup(trim($text), '', 'BOX', $args['rules']);  // sets up normal box
	if (inlist($type, 'html,debug')) {  // sets up html box
		$html = BOLTescape($out, false);
		$html = htmlspecialchars($html, ENT_NOQUOTES);
		$html = str_replace("\n", '<br />', $html);
		$html = BOLTescape("<$sd $attr>$html</$sd>", '', $spaced);
		if ($sd == 'div') $html = "\n$html\n";
		if ($type == 'html') return $html;
		}
	$box = BOLTescape("<$sd $attr>$out</$sd>", true, $spaced);
	if ($sd == 'div') $box = "\n$box\n";
	if ($type == 'markup') {  // returns markup and normal box
		if ($sd == 'span') return "$code $box";
		return "$code<br/>$box";
		}
	if ($type == 'debug') {  // returns markup, html, and normal box
		if ($sd == 'span') return "$code $html $box";
		return "$code<br/>$html<br/>$box";
		}
	return $box;  // return normal box
	}

function BOLTMbullets($m) {
	$list = $m[2];
	$list = BOLTstripSlashes($list);
	if (substr($list, -1) != "\n") $list = $list . "\n";
	$list = str_replace("\n==\n", "\n== ", $list); // ??
	$list = str_replace("\n= ", "<div style='height: 15px'></div>", $list);
	$lines = explode("\n", $list);
	foreach($lines as $line) {
		$bullet[] = substr($line, 0, strpos($line, " "));
		$text[] = substr($line, strpos($line, " ") + 1);
		}
	$index = strlen($bullet[0]);
	if (substr($bullet[0], 0, 1) == '*') $type[$index] = 'ul';
	else $type[$index] = 'ol';
	while ($i < $index) {
		$ii = $i + 1;
		$out = $out . "<$type[$index]>";
		$i = $i + 1;
		}
	$out .= "<li>" . $text[0];
	for ($i=1; $i < count($lines) - 1; $i++ ) {
		$x = strlen($bullet[$i]);
		if ($x == $index) {
			$out .= "</li><li>$text[$i]";
			}
		if ($x > $index) {
			while ($index < strlen($bullet[$i])) {
				$index = $index + 1;
				if ($x == $index) {
					if (substr($bullet[$i], 0, 1) == '*') $type[$index] = 'ul';
					else $type[$index] = 'ol';
					$out .= "<$type[$index]><li>$text[$i]";
					}
				else {
					$type[$index] = $type[$index - 1];
					$out .= "<$type[$index]>";
					}
				}
			}
		if ($x < $index) {
			while ($index > strlen($bullet[$i])) {
				$out .= "</li></$type[$index]>";
				$index = $index - 1;
				}
			$out .= "</li><li>$text[$i]";
			}
		}
	while ($index > 0) {
		if ($type[$index] == '') $type[$index] = $type[$index + 1];
		$out .= "</li></$type[$index]>";
		$index = $index - 1;
		}
	$out = str_replace('</div></li></ul>', "</li></ul></div>", $out);
	return "\n$out\n";
	}

function BOLTMfontstyles($m) {
	$type = $m[1];
	$text = $m[4];
	$text = BOLTstripSlashes($text);
	while (preg_match('/((\*|\/|&gt;|&lt;|\_|\||\^|@|#)(\2))(.+?)(\1|$)/', $text) == 1) $text = preg_replace_callback('/((\*|\/|&gt;|&lt;|\_|\||\^|@|#)(\2+))(.+?)(\1|$)/', function($m) { return BOLTMfontstyles($m); }, $text);
	$type = str_replace(Array('&gt;', '&lt;'), Array('>', '<'), $type);
	$len = strlen($type) - 1;
	switch (substr($type, 0, 1)) {
		case '*' : return "<strong>$text</strong>";
		case '/' : return "<em>$text</em>";
		case '_' : return "<u>$text</u>";
		case '|' : return "<mark>$text</mark>";
//		case '^' : return "<sup>$text</sup>";
		case '@' : return "<font style='font-family: monospace'>$text</font>";
		case '=' : return "<strike>$text</strike>";
		case '#' : return BOLTMbox('type=box', $text);
		}
	}

function BOLTMforms($attr, $initial='') {
	global $BOLTtime, $BOLTformData, $BOLTkey, $BOLTformKeys, $pageLink, $scriptURL, $cleanURL, $pageShow;
	if ($attr == '' && $BOLTkey != '') {  // close form, stop saving session info for this form
		BOLTformIn($BOLTkey);
		$BOLTkey = '';
		return BOLTescape('</form>');
		}
	$k = '';
	$formArgs = BOLTattrs('form');
	$args = BOLTargs($attr);
	foreach ($args as $f => $v) {
		if (! in_array($f, $formArgs)) unset($args[$f]);
		}
	if (strpos(BOLTloadpage($pageShow), "[file")) $args['enctype'] = 'multipart/form-data';  //file uploads
	if (! isset($args['action'])) {
		if (isset($cleanURL)) $args['action'] = $cleanURL . str_replace('.', '/', $pageLink);
		else $args['action'] = "$scriptURL$pageLink";
		if ($_GET['action'] != '') $args['action'] .= "&action=$_GET[action]";
		}
	if ($args['action'] == 'false') unset($args['action']);
	if ($args['method'] == '') $args['method'] = 'post';
	if ($args['scrollto'] ==  'true') {
		$args['onsubmit'] = 'saveScroll()';
		global $BOLTreplaceHTML;
		$BOLTreplaceHTML['find'][] = '</head>';
		$BOLTreplaceHTML['replace'][] = "<script type='text/javascript'>\n<!--\nfunction saveScroll() {\ndocument.getElementById('scrollto').value = window.scrollY;\n}\n-->\n</script>\n</head>";
		}
	foreach ($args as $f => $v) {
		$params .= "$f='$v' ";
		}
	$unique = false;
	$expy = BOLTinit(BOLTconfig('formExpy', 3600), $args['expires']);
	$expires = $BOLTtime + $expy;
	while ($unique == false) {
		$BOLTkey = rand(1000000,9999999);
		if ($BOLTformData[$BOLTkey]['EXPIRES'] == '') $unique = true;
		}
	$BOLTformKeys[] = $BOLTkey;
	$BOLTformData[$BOLTkey]['EXPIRES'] = $expires;
	return $initial . BOLTescape("<form accept-charset='utf-8' $params><input type='hidden' name='boltkey' value='$BOLTkey' />");
	}

function BOLTMfunc($m) {
	$params = $m[1];
	if ($params == '<' || $params == '&lt;') $params = $m[2];
	$params = str_replace('&amp;&amp;', '&&', BOLTstripSlashes($params));
	$function = $params;
	if (strpos($params, " ") !== false) {
		$function = substr($params, 0, strpos($params, " "));
		$params = substr($params, strlen($function));
		$params = str_replace(Array('&apos;', '&quot;'), Array("'", '"'), $params);
		$args = BOLTargs($params);
		}
	else $args = Array();
	if ($args['if'] != '' ) {
		if (BOLTiftrue($args['if'], 'true') != 'true') return;
		}
	if ($args['msg'] == '') $args['msg'] = BOLTconfig('funcMessages', 'false');
	return BOLTfunc($function, $args);
	}

function BOLTMheaders($m) {
	$number = $m[1];
	$text = $m[2];
	$text = trim(BOLTstripSlashes($text));
	$text = BOLTtranslate($text);
	$n = strlen($number);
	return "<h$n>$text</h$n>";
	}

function BOLTMhtml($m) {
	$slash = $m[1];
	$command = $m[2];
	$end = $m[3];
	$BOLThtml = BOLTattrs('html');
	$command = strtolower($command);
	if (in_array($command, $BOLThtml)) return "<$slash$command>";
	if ($command == 'pre') {
		if ($slash == '') return '&lt;nolines&gt;<pre>';
		else return '</pre>&lt;/nolines&gt;';
		}
	return "&lt;$slash$command$end&gt;";
	}

function BOLTMif($m) {
	$type = $m[1];
	$condition = $m[2];
	global $BOLTiflevel, $BOLTifcondition;
	$condition = BOLTstripSlashes($condition);
	if ($type == 'else') return "[true$BOLTiflevel][true$BOLTiflevel ! ($BOLTifcondition[$BOLTiflevel])]";
	if ($type == 'if') {
		if ($condition == '') {
			$out = "[true$BOLTiflevel]";
			$BOLTiflevel = $BOLTiflevel - 1;
			return $out;
			}
		$BOLTiflevel = $BOLTiflevel + 1;
		$BOLTifcondition[$BOLTiflevel] = $condition;
		return "[true$BOLTiflevel $condition]";
		}
	}

function BOLTMifnest($m) {
	$condition = $m[2];
	$content = $m[3];
	if (strpos($condition, 'case=') !== false) deprecate('switch');
	if (strpos($condition, 'switch=') !== 'false') {
		global $BOLTifswitch;
		$args = BOLTargs($condition);
		$switch = $args['switch'];
		}
	while (strpos($content, '[true') !== false) {
		$content = preg_replace_callback('/\[true([0-9]{1}) (.*?)\](.*?)\[true\1\]/ms', function($m) { return BOLTMifnest($m); }, $content);
		}
	$out = BOLTiftrue($condition, $content);
	if ($switch != '') {
		if ($BOLTifswitch[$switch] == true) return;
		if ($out != '') {
			$BOLTifswitch[$switch] = true;
			return $out;
			}
		}
	return $out;
	}

function BOLTMindents($start, $end, $text) {
	$text = BOLTstripSlashes(BOLTtrimLines($text));
	return "$start<blockquote>$text</blockquote>$end";
	}

function BOLTMinputs($m) {
	$type = $m[2];
	$attr = $m[3];
	$initial = $m[1];
	global $pagesPath, $pageLink, $scriptUrl, $BOLTkey, $BOLTformData, $scriptURL, $cleanURL, $fieldURL, $selectDefault, $labelcounter, $BOLTinputTypes;
	$type = strtolower($type);
	$attr = trim(BOLTstripSlashes($attr));
	if ($attr == '') {
		if ($type == 'select') return '</select>';
        if ($type == 'optgroup') return '</optgroup>';
		if ($type == 'box') return '</textarea>';
		}
	if ($type == 'form') return BOLTMforms($attr, $initial);  // setup form
	$args = BOLTargs($attr);
	$default = $args['default'];
	if ($type == 'option') {
		if ($args['value'] == '') $args['value'] = $args[1];
		}
	else {
		if ($type == 'optgroup') {
			if ($args['label'] == '') {
				$args['label'] = $args[1];
				unset($args[1]);
				}
			}
		$name = $args[1];
		unset($args[1]);
		$attr = substr($attr, strlen($name) + 1);
		if ($name == '') $name = $type;
		if ($name == 'jump') $args['js'] = 'jump';
		}
	if ($type == 'command') {  // store commands as session values
		if (preg_match('/\~\~([0-9]+)\~\~/', $attr) == 1) $attr = BOLTescape($attr, false);
//		$attr = BOLTstripQuotes($attr);
		$i = $name;
		while (isset($BOLTformData[$BOLTkey]['COMMAND'][$i])) {
			$c = $c + 1;
			$i = $name . "_$c";
			}
		$BOLTformData[$BOLTkey]['COMMAND'][$i] = $attr;
		return;
		}
	if ($type == 'box' || $type == 'text') {
		if (strpos($attr, '"') !== false || strpos($attr, "'") !== false) {
			if ((strpos($attr, '"') !== false) && ((strpos($attr, '"') < strpos($attr, "'")) || (strpos($attr, "'") === false))) {
				$r1 = strpos($attr, '"');
				$r2 = strrpos($attr, '"') + 1;
				$str1 = substr($attr, 0, $r1);
				$str2 = str_replace('"', '&#34;', substr($attr, $r1 + 1, $r2 - $r1 - 2));
				$str3 = substr($attr, $r2);
				$attr = "$str1\"$str2\"$str3";
				}
			else {
				$r1 = strpos($attr, "'");
				$r2 = strrpos($attr, "'") + 1;
				$str1 = substr($attr, 0, $r1);
				$str2 = str_replace("'", '&#39;', substr($attr, $r1 + 1, $r2 - $r1 - 2));
				$str3 = substr($attr, $r2);
				$attr = "$str1'$str2'$str3";
				}
			}
		}
	if ($type == 'check') $type = 'checkbox';
	if ($type == 'file') $args['type'] = 'upload';
	if ($args['value'] == '' && $type != 'option') $args['value'] = $args[2];
	$attr = '';
	$BOLTformData[$BOLTkey]['INPUT'][$name] = $args;  // stores attr for post processing

// optimize args for various options
	if ($type == 'select') {
		$selectDefault = $args['default'];
		}
	if ($type == 'option') {
		if ($selectDefault == $args['value'] || $args['selected'] == 'true') $attr = "selected ";
		$label = BOLTinit($args[2], $args['label']);
		}
	if (inlist($type, 'submit,reset,button')) {
		if ($args['value'] == '') $args['value'] = $name;
		if ($args['value'] == '') $args['value'] = strtoupper($type);
		$args['value'] = BOLTtranslate($args['value']);
		if ($args['name'] == '') $args['name'] = $type;
        }
	elseif ($args['name'] == '') $args['name'] = $name;
	if ($args['name'] == 'false') unset($args['name']);
	if ($args['value'] == '') $args['value'] = $args['none'];
	if ($type == 'radio' || $type == 'checkbox') {
		if ($args['checked'] != '') {
			$args['checked'] = BOLTescape($args['checked'], false);
			if (substr($name, -2) == "[]") {
				if (strpos(',' . $args['checked'] . ',', $args['value']) !== false || $args['checked'] == 'true') $args['checked'] = 'true';
				else unset($args['checked']);
				}
			elseif ($args['checked'] == $args['value'] || $args['checked'] == 'true') $args['checked'] = 'true';
			else unset($args['checked']);
			}
		else unset($args['checked']);
		}
	if ($type == 'box') {
        if (isset($args['gui'])) {
			if (BOLTexists("code.embed.gui.$args[gui]")) $guipage = "gui.$args[gui]";
			else $guipage = "gui";
			if (BOLTexists("code.embed.$guipage")) {
				$path = substr(BOLTimgFind('bold.gif', 'gui/'), 0, - 9);
				$gui = BOLTFembed(array('1'=>$guipage, 'guiid'=>$args['name'], 'path'=>$path)) . BOLTFembed(array('1'=>'guiscript')) . '<br>';
				$args['id'] = 'BOLTgui'.$args['name'];
				}
			}
		}
	if ($type == 'image') {
		if (strpos($args['src'], '://') === false) $args['src'] = "$fieldURL/files/" . $args['src'];
		}

	if ($args['source'] != '') $args['value'] = BOLTFsource(BOLTargs("$args[source] escape=false"));
	if ($default != '' && $args['value'] == '') $args['value'] = $default;
	if (isset($args['js'])) {
		$jsOut = BOLTmakeJs($args['js']);
		$attr = " $jsOut $attr";
		}

// prepare input attributes
	foreach($args as $f => $v) {
		if (is_array($v)) continue;
		if (! in_array($f, BOLTattrs($type))) continue;
		if ($f == 'name' && substr($v, -2) == '[]') $attr .= " $f=$v";
		elseif (strpos($v, "'") !== false) $attr .= " $f=\"$v\" ";
		else $attr .= " $f='$v' ";
		}
	if (inlist($args['type'], $BOLTinputTypes)) $type = $args['type'];

// prepare final html output and return to page
	switch($type) {
		case 'select' :
			return $initial . BOLTescape("<select $attr>");
		case 'option' :
			if (isset($label)) return BOLTescape("<option $attr>$label</option>");
			else return BOLTescape("<option $attr />");
		case 'optgroup' :
            return $initial . BOLTescape("<optgroup $attr>");
		case 'box' :
			return $initial . BOLTescape("$gui<textarea $attr>") . BOLTescape($value);
		case 'checkbox' :
			return $initial . BOLTescape("<input type='$type' $attr />");
		case 'radio' :
			return $initial . BOLTescape("<input type='$type' $attr />");
		case 'input' :
			return $initial . BOLTescape("<input $attr />");
		default :
			return $initial . BOLTescape("<input type='$type' $attr />");
		}
	return;
	}

function BOLTMlinks($m) {
	$x = $m[1];
	global $scriptURL, $fieldURL, $cleanURL, $pageLink, $BOLTmissingMark, $BOLTlinkJs;
	$x = BOLTstripSlashes($x);
	if (substr($x, 0, 1) == '?') $x = substr($x, 1);
	elseif(BOLTconfig('missingMark', 'true') == 'true') {
		$missing = BOLTinit("<span class='marks'>?</span>", $BOLTmissingMark);
		}
	if (substr($x, 0, 1) == '#') {  // anchors
		list($link,$label) = explode('|',$x,2);
		$link = substr($link, 1);
		if ($label == '+') {
			if ($link == BOLTutf2url($link)) $label = ucfirst($link);
			else $label = $link;
			}
		$link = BOLTutf2url($link);
		return BOLTescape("<a name='$link'>$label</a>");
		}
	list($link,$label,$attrs) = explode('|',$x,3);
	$link = BOLTescape($link, false);
	$link = trim($link);
	$label = trim($label);
	if (substr($link, 0, 1) == '~') {
    if (function_exists('myBOLTmemberLinks')) return myBOLTmemberLinks($link, $label, $x);
		$link = 'member.' . trim(substr($link, 1), '.');
		if ($label == '') $label = BOLTvars("$link:title");
		}
	if (substr($link, 0, 1) == '/') $link = $fieldURL . $link;
	if (strtolower(substr($link, 0, 3)) == "www") $link = "http://$link";
	if ($label == '') {
		if (BOLTconfig('linkTitles') == 'true') $label = '+';
		else $label = BOLTpageshortcuts($link);
		}
	$attrs = trim($attrs);
	$args = BOLTargs($attrs);
	if ($args['js'] != '') $attr = BOLTmakeJs($args['js']);
	if (is_array($args)) {
		foreach($args as $f => $v) {
			if (! in_array($f, BOLTattrs('a'))) continue;
// This line blocks some styling we want. What specifically do we want to filter out for security?
//			if (preg_match('/[\'#0-9a-zA-Z]+/', $v)) continue;
			$attr .= " $f=\"" . $v . "\" ";
			}
		}
	$attr = str_replace('xmllang', 'xml:lang', $attr);
	if (strpos($link, '://') == false) {
		if (strpos($link, '@') && strpos($link, '&') === false) $link = "mailto:$link";
		else {
			$link = BOLTpageshortcuts($link);
			if (! preg_match('/^[-_a-zA-Z0-9~\.%]+(\#|\&|$)/', $link)) return BOLTtranslate(BOLTinfoVar('site.messages', 'invalid_link', 'Invalid link.'));
			if (isset($missing)) {
				if (! BOLTexists($link)) {
					if (BOLTconfig('linkRot') == 'true' && BOLTexists($pageLink)) {  // deleted && $missing != ''
						preg_match('/^([-_a-z0-9\.\%]+)/i', $link, $matches);
						$ignore = BOLTconfig('linkRotIgnore');
						if ($ignore == '' || BOLTpageCheck($ignore, $matches[0]) === false)	BOLTlog("[[$pageLink]]: $matches[0]", 'site.linkrot#links', "\n", 'unique,sort');
						}
					$missingPage = $missing;
					}
				}
			if ($label == '+') {
				if (strpos($link, '&') !== false) $label = BOLTvars(substr($link, 0, strpos($link, '&')) . ':title');
				elseif (strpos($link, '#') !== false) $label = ucfirst(substr($link, strpos($link, '#') + 1));
				else $label = BOLTvars("$link:title");
				}
			if (isset($cleanURL)) {
				if (strpos($link, '&') !== false) {
					$anchor = substr($link, strpos($link, '&'));
					$link = substr($link, 0, strpos($link, '&'));
					}
				$link = $cleanURL . str_replace('.', '/', $link) . $anchor;
				}
			else $link = $scriptURL . $link;
			}
		if ($attr == '') $defaultAttr =  BOLTconfig('linkIntAttr', '');
		if (BOLTconfig('ssl') == 'true') $link = str_replace('http:', 'https:', $link);
		}
	else {
		if ($attr == '') $defaultAttr =  BOLTconfig('linkExtAttr', " rel='nofollow'");
		if ($label == '+' || $label == $link) $label = BOLTescape($link);
		}
	if ($label == '=') $label = $link;
	$label = BOLTurl2utf($label);
	$link = str_replace('&', '&amp;', $link);
	$link = str_replace('=', '&#61;', $link);
	if (function_exists('myBOLTMlinks')) return myBOLTMlinks($link, $defaultAttr, $attr, $label, $missingPage);
	return BOLTescape('<a href="'.$link.'" '.$defaultAttr.$attr.'>') . BOLTtranslate($label) . BOLTescape("$missingPage</a>");
	}

function BOLTMmemberVar($m) {
	$field = $m[1];
	if (function_exists('myBOLTMmemberVar')) return myBOLTMmemberVar($field);
	global $BOLTid;
	if (strpos($field, ":") === false) return BOLTvars("member.$BOLTid:$field");  // {~field}
	else return BOLTvars("member.$field");  // {~id:field}
	}

function BOLTMrequest($m) {
	$field = $m[1];
	global $BOLTsession;
	$out = BOLTinit($_GET[$field], $_COOKIE[$field], $_POST[$field], $BOLTsession['PASSFORM'][$field]);
	if (is_array($out)) $out = implode(",", $out);
	return htmlspecialchars(BOLTsafetext($out));
	}

function BOLTMshortlinks($m) {
	global $scriptURL, $cleanURL, $uploadImgTypes, $uploadFileTypes;
	$type = $m[1];
	if (substr($m[2], -5) == '&nbsp') {
		$m[2] = substr($m[2], 0, -5);
		$extra = '&nbsp';
		}
	elseif (substr($m[2], -3) == '&lt') {
		$m[2] = substr($m[2], 0, -3);
		$extra = '&lt';
		}
	$link = $m[2];
	if ($type == 'img' || $type == 'file') {
		$filetype = substr($link, strrpos($link, '.') + 1);
		if ($type == 'img' && strpos("|$uploadImgTypes|", "|$filetype|") !== false) return BOLTMuploads($m) . $extra;
	   if ($type == 'file' && strpos("|$uploadFileTypes|", "|$filetype|") !== false) return BOLTMuploads($m) . $extra;
	   return "$type:$link$extra";
		}
	$redirect = BOLTinfoPeek('info.redirects', $link, false);
	if ($redirect != '') $link = $redirect;
	if ($type == 're') {
		deprecate('re-shortlink', 'Change re shortlink to link shortcut');  // when clear, delete from markuprule also!
		$type = 'link';
		}
	if (BOLTexists(str_replace('/', '.', $link))) {
		if ($cleanURL != '') $url = $cleanURL . str_replace('.', '/', $link);
		else $url = "$scriptURL$link";
		}
	elseif (file_exists($link)) $url = "$cleanURL$link";
	elseif (strpos($link, '://') !== false) $url = $link;
	else return "$m[1]:$m[2]" . $extra;
	if ($type == 'url') return $url . $extra;
	if ($type == 'button') $button = ' class="button"';
	$link = preg_replace('/([\?\=\&]{1})(.*)/', '', $link);
	$title = BOLTvars("$link:title", false);
	return BOLTescape("<a$button href=$url>$title</a>") . $extra;
	}

function BOLTMspacing($m) {
	$space = $m[1];
	$key = substr($space, 0, 1);
	if ($key == ' ') return str_replace(' ', '&nbsp;', $space);
	if ($key == "\t") return str_replace("\t", '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;', $space);
	$space = substr($space, 2);
	return "\n\n" . str_replace("\n", "<br />\n", $space) . "\n";
	}

function BOLTMspandivs($m) {
	$type = $m[1];
	$param = $m[2];
	$text = $m[3];
	$text = BOLTstripslashes($text);
	if (strpos($text, "\n") === false) $html = 'span';  // span or div
	else $html = 'div';
	if ($type == 'color') return "<$html style='color: $param;'>$text</$html>";
	if ($type == 'highlight') return "<$html style='background-color: $param; padding: 0px 5px 2px 5px;'>$text</$html>";
	if ($type == 'size') return "<$html style='font-size: $param;'>$text</$html>";
	if ($type == 'align') return "<div style='text-align: $param;'>$text</div>";
	}

function BOLTMstyles($m) {
	$type = $m[2];
	$attr = $m[3];
	$end = $m[1];
	if ($end == '/') return "</$type>";
	if ($attr != '') {
		$attr = BOLTstripSlashes($attr);
		if ($type == 'p' || $type == 'div') {
			$r1 = array(' center', ' left', ' right');
			$r2 = array(' text-align=center', ' text-align=left', ' text-align=right float=right');
//			$attr = str_replace($r1, $r2, strtolower($attr));
			}
		$args = BOLTargs($attr);
		$attr = '';
		if ($type == 'a') {
			global $scriptURL;
			if (! isset($args['href'])) $args['href'] = $args[1];
			$args['href'] = BOLTescape($args['href'], false);
			if (strpos($args['href'], "://") === false) $args['href'] = $scriptURL . BOLTpageshortcuts($args['href']);
			}
		foreach((array)$args as $f => $v) {
			if (is_array($v)) continue;
			$v = BOLTtrimQuotes($v);
			if (in_array($f, BOLTattrs($type))) $attr .= " $f='$v' ";
			}
		$attr = BOLTescape(str_replace('   ', ' ', " $attr"));
		}
	return "<$type$attr>";
	}

function BOLTMsymbol($m) {
	$symbol = $m[1];
	global $BOLTsymbolIndex;
	if (! isset($BOLTsymbolIndex)) $BOLTsymbolIndex = Array('c'=>'&copy;','r'=>'&reg;','tm'=>'&trade;');
	if (isset($BOLTsymbolIndex[$symbol])) return $BOLTsymbolIndex[$symbol];
	return "($symbol)";
	}

function BOLTMtables($m) {
	$type = $m[1];
	$attr = $m[3];
	$level = BOLTinit('0', $m[2]);
	global $tablememory, $stripememory, $BOLTtableInputs, $BOLTtableOutputs;
	if ($attr != '') {
		$attr = BOLTescape($attr, false);
		if ($type == 't' && strpos($attr, 'class=stripe') !== false) $stripememory[$level] = 1;
		if (! isset($BOLTtableInputs)) $BOLTtableInputs = array(' center', ' left', ' right', ' top', ' middle', ' bottom', ' color=', ' padding=', ' spacing=', ' rows=', ' cols=', ' image=');
		if (! isset($BOLTtableOutputs)) $BOLTtableOutputs  = array(' align=center', ' align=left', ' align=right', ' valign=top', ' valign=middle', ' valign=bottom', ' bgcolor=', ' cellpadding=', ' cellspacing=', ' rowspan=', ' colspan=', ' background=');
		$attr = str_replace($BOLTtableInputs, $BOLTtableOutputs, $attr);
		$args = BOLTargs($attr);
		if (isset($args['height'])) $args['style'] .= " height: $args[height];";
		$attr = '';
		foreach($args as $f => $v) {
			if (is_array($v)) continue;
			if (! in_array($f, BOLTattrs($type))) continue;
			$attr .= " $f='$v' ";
			}
		$attr = BOLTescape($attr);
		}
	switch($type) {
		case 't' :
			if ($tablememory["$level-t"] != 'on') {
				$tablememory["$level-t"] = 'on';
				return "<table $attr>";
				}
			else {
				$tablememory["$level-t"] = 'off';
				$tablememory["$level-r"] = 'off';
				$stripememory[$level] = 0;
				if ($tablememory["$level-c"] == 'on') {
					$tablememory["$level-c"] = 'off';
					return "</td></tr></table>";
					}
				if ($tablememory["$level-h"] == 'on') {
					$tablememory["$level-h"] = 'off';
					return "</th></tr></table>";
					}
				}
		case 'r' :
			if ($stripememory[$level] > 0) {
				$stripememory[$level] = $stripememory[$level] + 1;
				if (is_int($stripememory[$level] / 2)) $stripe = " class='striperow' ";
				}
			if ($tablememory["$level-r"] != 'on') {
				$tablememory["$level-r"] = 'on';
				return "<tr $attr$stripe>";
				}
			else {
				if ($tablememory["$level-c"] == 'on') {
					$tablememory["$level-c"] = 'off';
					return "</td></tr>\n<tr $attr$stripe>";
					}
				if ($tablememory["$level-h"] == 'on') {
					$tablememory["$level-h"] = 'off';
					return "</th></tr>\n<tr $attr$stripe>";
					}
				}
		case 'c' :
			if ($tablememory["$level-c"] != 'on') {
				if ($tablememory["$level-h"] == 'on') {
					$tablememory["$level-h"] = 'off';
					$tablememory["$level-c"] = 'on';
					return "</th><td $attr>";
					}
				$tablememory["$level-c"] = 'on';
				return "<td $attr>";
				}
			else return "</td><td $attr>";
		case 'h' :
			if ($tablememory["$level-h"] != 'on') {
				if ($tablememory["$level-c"] == 'on') {
					$tablememory["$level-c"] = 'off';
					$tablememory["$level-h"] = 'on';
					return "</td><th $attr>";
					}
				$tablememory["$level-h"] = 'on';
				return "<th $attr>";
				}
			else return "</th><th $attr>";
		}
	}

function BOLTMtags($m) {
	$tag = $m[1];
	global $scriptURL;
	$tagPage = BOLTconfig('tagPage', 'action.tags');
	$start = substr($tag, 0, 1);
	$tag = substr($tag, 2);
	return $start . BOLTescape("<a href='$scriptURL$tagPage&tag=$tag' class=tags>$tag</a>");
	}

function BOLTMtexttools($m) {
	$args = $m[2];
	$text = $m[3];
	if ($text != '') $text = BOLTstripslashes($text);
	if (isset($args['text']) && $args['text'] === false) return $text;
	if (! is_array($args)) $args = BOLTargs($args);
	if (preg_match('/^\~\~([0-9*]+)\~\~$/', $text) == 1) { $text = BOLTescape($text, false); $escape = true; }
	if ($args['trim'] != '' || in_array('trim', $args)) {
		$mask = $args['trim'];
		if (strpos($mask, '\n') !== false) $mask = str_replace($mask, '\n', "\n");
		if ($mask == '') $mask = " \t\n\r";
		$text = str_replace('&nbsp;', ' ', $text);
		$text = str_replace('<br />', "\n", $text);
		if (in_array('left', $args)) $text = ltrim($text, $mask);
		elseif (in_array('right', $args)) $text = rtrim($text, $mask);
		else $text = trim($text, $mask);
		}
	if ($args['substring'] != '') {
		$x = explode(',', $args['substring']);
		if ($x[1] == '') $text = substr($text, $x[0]);
		else $text = substr($text, $x[0], $x[1]);
		}
	if ($args['case'] != '') {
		switch($args['case']) {
			case 'caps': $text = strtoupper($text); break;
			case 'lower': $text = strtolower($text); break;
			case 'first': $text = ucfirst($text); break;
			case 'words': $text = ucwords($text);
			}
		}
	if (in_array('csv', $args)) $text = BOLTcsv(str_replace("\n", ',', $text), $args['current']);
	if (in_array('length', $args)) return strlen($text);
	if ($args['position'] != '') {
		$text = strpos($text, $args['position']);
		if ($text === false) return 0;
		return $text + 1;
		}
	if ($escape) return BOLTescape($text);
	return $text;
	}

function BOLTMuploads($m) {
	global $scriptURL, $fieldURL, $pageLink, $BOLTid, $BOLTmissingMark, $BOLTreloadMark, $imgPath, $BOLTskin;
	if ($m[1] == 'img' || $m[1] == 'file') $upload = $m[2];
	else $upload = $m[1];
	$args = BOLTargs($upload);
	$file = BOLTinit($args[1], $args['link']);
	if (strpos($file, '/') !== false && strpos($file, '//') === false) {
		$imgdir = substr($file, 0, strrpos($file, '/') + 1);
		$file = substr($file, strlen($imgdir));
		}
	if (inlist(substr($file, strrpos($file, '.') + 1), BOLTconfig('uploadImgTypes', 'gif,jpg,jpeg,png,svg'))) $type = 'img';
	else $type = 'a';
	foreach($args as $f => $v) {
		if (! in_array($f, BOLTattrs($type))) continue;
		$attr .= "$f='$v' ";
		}
	if (strpos($file, '://') !== false) {
		if ($type == 'img')	return BOLTescape("<img src='$file' $attr />");
		return "[[$file]]";
		}
	if (! isset($BOLTmissingMark)) $BOLTmissingMark = "<span class='marks'>?</span>";
	if (BOLTconfig('missingMark', 'true') == 'true') $missing = $BOLTmissingMark;
	if (substr($file, 0, 1) == "?") {
		$file = substr($file, 1);
		unset($missing);
		}
	if (BOLTconfig('uploadCase', 'true') == 'true') $file = strtolower($file);
	if (BOLTconfig('uploadStrict', 'true') == 'true') {
		if (BOLTfilter($file, 'uploads') == '') return BOLTtranslate(BOLTinfoVar('site.messages', 'invalid_file', 'Invalid file name.'));
		}
	$dir = '';
	if (isset($args['label'])) $label = $args['label'];
	else $label = $file;
	if (isset($args['dir'])) {
		$dir = $args['dir'];
		if (BOLTfilter($dir, '/^[-_a-zA-Z0-9\/]+$/') == '') return BOLTtranslate(BOLTinfoVar('site.messages', 'invalid_dir', 'Unauthorized upload directory.'));
		$location = "files/$dir/$file";
		$dirLink = "&dir=$dir";
		}
	else $location = "files/$imgdir$file";

// This section tries to find the file using paths, then converts to URL. If fails, returns upload link...
	if (file_exists($location)) $location = "$fieldURL/$location";
	else {
		$location = strtolower($location);
		if (file_exists($location)) $location = "$fieldURL/$location";
		else {
			$location = BOLTimgFind($file, $dir);
			if ($location == false) return BOLTescape("<a href='$scriptURL$pageLink$fileLink&action=upload&file=$file$dirLink'>") . "$label$missing</a>";
			}
		}
	if (! BOLTauth($file, $BOLTid, 'files')) return 'File access blocked';
	if ($args['reload'] == 'true' || $_GET['reload'] == 'true') {
			if (! isset($BOLTreloadMark)) $BOLTreloadMark = "<span class='marks'>^</span>";
			if (BOLTconfig('reloadMark', 'true') == 'true') $reload = BOLTescape("<a href='$scriptURL$pageLink$fileLink&action=upload&file=$file$dirLink' rel='nofollow'>$BOLTreloadMark</a>");
			}
	if ($BOLTskin == 'mobile' && strpos($attr, 'width=') === false) {
		$max = BOLTconfig('mobileWidth', 'false');
		if (is_number($max)) {
			$dim = getimagesize($location);
			if ($dim[0] > $max) $attr .= ' width=95% '; //" width='$max" . "px' ";
			}
		}
	if (strpos(BOLTconfig('uploadImgTypes', 'gif,jpg,jpeg,png,svg'), substr(strrchr($file, "."), 1)) !== false) {
		if (!isset($args['alt'])) $attr .= "alt='' ";
		return BOLTescape("$a<img src='$location' $attr />$reload");
		}
	else return BOLTescape("<a href='$location' $attr>") . "$label</a>$reload";
	}
