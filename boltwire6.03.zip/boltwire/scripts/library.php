<?php if (!defined('BOLTWIRE')) exit();

########################################
##  BOLTWIRE SYSTEM LIBRARY           ##
##  Copyright 2019 Dan Vis            ##
##  See license.txt for details       ##
########################################


## FOLLOWING IS THE LIBRARY OF SYSTEM FUNCTIONS USED IN BOLTWIRE IN ALPHATBETICAL ORDER

function BOLTabort($id, $args=[], $msg='') {
## ADDS MESSAGE TO OUTPUT AND ABORTS FORM PROCESSING IMMEDIATELY
	BOLTmessage($id, $args, $msg);  // sets up abort message
	if (isset($args['nextpage'])) { if ($args['nextpage'] != '') BOLTredirect($args['nextpage']); }
	return '~~ABORT~~';  // this will cause form processing to stop immediately
	}

function BOLTauth($check, $find, $type, $admin=true) {  // deleted 4th parameter $admin=true. used in plugins?
## THIS FUNCTION IS USED TO CHECK VARIOUS PERMISSIONS: VIEW, WRITE, OR ANY OTHER TYPE. NORMALLY CHECK IS PAGE AND FIND IS MEMBER BUT CAN BE OTHER VALUES. PLUGIN WRITERS CAN ADD ANY NEW TYPES. 
	global $BOLTgroups, $BOLTadmin, $BOLTid, $authlist, $pageLink, $BOLTpluginAuth;
	if (function_exists('myBOLTauth')) {
		$custom = myBOLTauth($check, $find, $type);
		if ($custom == 'allow') return true;
		if ($custom == 'block') return false;
		}
	if ($find == $BOLTid) {
		if ($BOLTadmin != '' && strpos(" ,$BOLTadmin,", ",$find,")) return true;
		}
	if ($type == '') BOLTabort('invalid_auth');
	if ($check == '') return false;
	$check = BOLTurl2utf($check);
	if (! BOLTexists("site.auth.$type")) return true;
	$contents = BOLTloadpage("site.auth.$type") . "\n" . $BOLTpluginAuth[$type];
	if ($contents == '') return false;
	$contents = str_replace('{id}', $BOLTid, $contents);
	$authlist = explode("\n", $contents);
	foreach ($authlist as $line) {
		$pos = strpos($line, ": ");
		if ($pos === false) continue;
		$f = substr($line, 0, $pos);
		$v = trim(substr($line, $pos + 2));
		$auth[$f] = $v;
		}
// Determine which auth line to use
	if ($type == 'data' || $type == 'info') {
		if (strpos($check, ':') !== false) $page = substr($check, 0, strpos($check, ':')); 
		else $page = $check;
		if (substr(BOLTutf2url($page), -strlen($BOLTid)) == $BOLTid) $find .= ',@owner'; // @owners access any page that ends in id
		}
	$checkline = '*';
	if ($auth[$check] != '') $checkline = $check;
	else {
		$checkArray = explode('.', $check);	// find closest hg page set
		while (count($checkArray) > 0) {
			$test = implode('.', $checkArray) . "*";
			if ($auth[$test] != '') {
				$checkline = $test;
				break;
				}
			array_pop($checkArray);
			}
		}
	$auth[$checkline] = str_replace(' ', '', $auth[$checkline]);
	if ($type == 'commands' || $type == 'functions') {
		if (inlist($find, $auth[$checkline])) return false;
		return true;
		}
	if ($auth[$checkline] == '') return false;
// Build auth membership list
	$find .= ',@' . str_replace(',', ',@', $BOLTgroups);
// Determine if id has permission on that line
	$f = explode(',', trim($find,','));
	foreach ($f as $ff) {
		if (inlist($ff, $auth[$checkline])) return true;
		}
	return false;
	}

function BOLTcache($page) {  ##PRO LOADPAGE, GET EXPY, IF VALID RETURN, ELSE UNLINK 
	global $BOLTtime, $pageArray;	
	if (! BOLTexists($page)) return; 
	if ($_GET['action'] != '' || $pageArray[0] == 'action' || $_POST != Array()) return;
	$expires = BOLTvars("$page:expires", false);
	if (is_number($expires) && $expires > $BOLTtime) return BOLTloadpage($page);
	$fpage = BOLTfolders($page); //else
	if (file_exists("pages/$fpage")) unlink("pages/$fpage");
	}
	
function BOLTcacheSave($page, $expires='', $content='') {  ##PRO SAVE CONTENT TO PAGE 
	global $BOLTcache;
	$parts = explode('.', $page);
	if (! is_number($expires) || $content == '') return;
	BOLTsavepage($page, $content, "\n~data~\nexpires: $expires\n~\n");
	}

function BOLTcharEncode($text, $fmt='', $escape=true) {
## SIMPLE FUNCTION TO ESCAPE A FEW STRINGS USED IN SOURCE CODE TYPE FUNCTIONS
	$text = str_replace('[`form', '[form', $text);  // messages and reports
	$text = str_replace('[messages', '&#91;messages', $text);  // messages and reports
	$text = str_replace('<', '&lt;', $text);
	if ($fmt == 'lines') $text = str_replace(Array("\n", '  ', "\t"), Array("<br />\n", '&nbsp;&nbsp;', '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'), $text);
	if ($escape) return BOLTescape($text);
	return $text;
	}

function BOLTcrypt($pass, $cryptkey='') {
	global $cryptkey;  // set cryptkey in index.php, never change
	if (function_exists('myBOLTcrypt')) return myBOLTcrypt($pass, $cryptkey);
	if ($cryptkey != '') return crypt($pass, $cryptkey);
	return $pass;
	}

function BOLTcsv($value, $current='') {
## USED FOR LIST AND GROUP MANAGEMENT. TO ADD OR REMOVE ITEMS USE +ITEM,-ITEM. IF NO $CURRENT SUPPLIED, RETURNS CLEANED VALUE.
	$new = ",$current,";
	$key = '';
	$values = explode(',', $value);
	foreach ($values as $v => $vv) {
		if (inlist(substr($vv, 0, 1), '+,-')) {
			$key = substr($vv, 0, 1);
			$vv = substr($vv, 1);
			}
		$vv = trim($vv);
		if ($key == '-') $new = str_replace(",$vv,", ',', $new);
		if ($key == '+' && strpos($new, ",$vv,") === false) $new = $new . "$vv,";
		$out[] = $vv;
		}
	if ($current == '') return implode(',', $out);
	return trim($new, ',');
	}

## IMPORTANT FUNCTION TO WARN OF PROBLEMS RELATED TO UPGRADE CHANGES
function deprecate($find, $msg='', $page='') {
## A SPECIAL FUNCTION USED TO FLAG PAGES USING FUNCTIONS ABOUT TO BE DEPRECATED
	if (BOLTconfig('deprecate', 'true') == false) return;
	global $pageLink, $pageShow, $BOLTzone;
	$page = BOLTinit($pageLink, $page);
	if ($BOLTzone != 'main') $page = BOLTgetlink($BOLTzone, '', $page);
	else $page = $pageShow;
	$time = strftime('%x');
	if ($msg == '') $msg = "$page uses $find";
	else $msg = str_replace(Array('{+page}', '{+find}'), Array($page, $find), $msg);
	BOLTlog($msg, "site.deprecate.$find", "\n", 'sort,unique');
	}

function BOLTdisplay ($outarray='', $args=Array(), $zone='') {
## THE MAIN FUNCTION USED TO DISPLAY A SET OF PAGES ACCORDING TO A TEMPLATE/FMT PARAMETER. SETS UP SYSTEM OPTIONS AND THEN SENDS TO APPROPRIATE SUBFUNCTIONS. 
	if (function_exists('myBOLTdisplay')) return myBOLTdisplay($outarray, $args, $zone);
	if (inlist($args[1], 'prev,next')) return BOLTdisplayPrevNext($args, $outarray);
	if ($args['none'] != '') {
		if (! is_array($outarray) || empty($outarray)) return $args['none'];
		}
//	if (! is_array($outarray)) return;
	if ($args['table'] != '') {
		if ($args['table'] == 'true') $args['table'] = '[t width=100%]';
		else $args['table'] = "[t $args[table]]";
		}
	$template = $args['template'];
	$fmt = $args['fmt'];
	if ($template == '' && $fmt == '') return BOLTdisplayFmt($outarray, 'default', $args, $zone);
	if ($template == 'count' || $fmt == 'count') return count($outarray);
	if ($template == 'csv' || $fmt == 'csv') return implode(',', $outarray);
	if ($template == 'list' || $fmt == 'list') return implode("\n", $outarray);
	if ($template == 'title' || $fmt == 'title') return BOLTdisplayFmt($outarray, "[[{+p}|+]]", $args, $zone);
	if ($template == 'array' || $fmt == 'array') return ($outarray);
	if ($fmt != '') return BOLTdisplayFmt($outarray, $fmt, $args, $zone);
	return BOLTdisplayTemplate($outarray, $template, $args, $zone);
	}

function BOLTdisplayFmt ($pages='', $fmt='', $args=Array(), $zone='') {
## A SUBFUNCTION USED TO PROCESS FMT PARAMETER.
	global $actionLink, $BOLTskin, $pageShow, $BOLTid;
	$join = str_replace('\n', "\n", $args['join']);
	if ($join == '') $join = "\n";
	if ($args['join'] == 'false') $join = '';
	if ($fmt != '') {
		if (preg_match('/^[-_0-9a-z]+$/', $fmt) == 1)  $temp = BOLTloadpage("$pageShow#$fmt");
		if ($temp == '') $temp = BOLTloadpage("template.$fmt");
		if ($temp == '') $temp = BOLTloadpage($fmt);		
		if ($temp != '') $fmt = $temp;
		}
	if ($fmt == '') return "Output format //$fmt// not found."; // $fmt = BOLTloadpage("template.default");
//	$fmt = BOLTsafetext($fmt);
	$fmt = BOLTescape($fmt, false);
	if ($args['lines'] !== 'false') $fmt = str_replace('\n', "\n", $fmt);
	unset($args['count']);
	if (is_array($args)) foreach ($args as $f => $v) $fmt = str_replace('{+'.$f.'}', $v, $fmt);
	$fmt = str_replace(Array('{+matches}', '{+first}', '{+last}'), Array(count($pages), $pages[0], end($pages)), $fmt);
	if (is_number($args['cols'])) {
		$t = count($pages);
		$c = ceil($t / $args['cols']);
		if ($args['table'] == '') $args['table'] = '[t width=100%]';
		$w = floor(100 / $args['cols']);
		$out = "[r top][c width={$w}%]";
		}
	foreach($pages as $i => $page) {
		if ($c != '') {
			if ($ii == $c) { $out .= "[c width={$w}%]"; $ii = 0; }
			$ii = $ii + 1;
			}
		$page = trim($page);
		if ($page == '') continue;
		$fmt_temp = BOLTdisplayReplace($fmt, $i, $pages, $args);
		if ($args['unique'] == 'true') {
			if (is_array($uniques)) {	
				if (in_array($fmt_temp, $uniques)) continue;
				}
			$uniques[] = $fmt_temp;
			}
		$out .= $fmt_temp . $join;
		}
	if (substr($out, - strlen($join)) == $join) $out = substr($out, 0, - strlen($join));
	$out = BOLTstripSlashes($out);
	if ($args['table'] != '' && count($pages) != 0) $out = $args['table'] . $out . '[t]';
	if ($args['escape'] == 'true') BOLTescape($out);
	return $out;
	}

function BOLTdisplayTemplate ($pages='', $template='', $args=[], $zone='') {
## A SUBFUNCTION USED TO PROCESS TEMPLATE PARAMETER.
	global $pageShow, $actionLink, $BOLTskin, $BOLTid;
	if ($args['join'] == 'false') $join = '';
	else {
		$join = str_replace('\n', "\n", $args['join']);
		if ($join == '') $join = "\n";
		else $join = BOLTdomarkupTable($join, '', $args['rules']);
		}
	$zone = strtoupper($zone);
	if ($template != '') {
		if (preg_match('/^[-_0-9a-z]+$/', $template) == 1) $temp = BOLTloadpage("$pageShow#$template");
		if ($temp == '') $temp = BOLTloadpage("template.$template");
		if ($temp == '') $temp = BOLTloadpage($template);
		if ($temp != '') $template = $temp;
		}
	if ($template == '') return "Output template //$temp// not found."; // $template = BOLTloadpage("template.default");
//	$template = BOLTsafetext($template);
	$template = BOLTescape($template, false);
	if ($args['lines'] !== 'false') $template = str_replace('\n', "\n", $template);
	unset($args['count']);
	if (is_array($args)) foreach ($args as $f => $v) $template = str_replace('{+'.$f.'}', $v, $template);
	$template = str_replace(Array('{+matches}', '{+first}', '{+last}'), Array(count($pages), $pages[0], end($pages)), $template);
	if ($args['query'] != '') {
		$template = preg_replace('/\{\+\#([0-9]+)\}/', '{' . $args['query'] . '::{+p}::$1}', $template);
		$template = str_replace(Array('{+field}', '{+value}', '{+value::'), Array('{+p}', '{'.$args['query'].'::{+p}}', '{'.$args['query'].'::{+p}::'), $template);
		}
	if (is_number($args['cols'])) {
		$t = count($pages);
		$c = ceil($t / $args['cols']);
		if ($args['table'] == '') $args['table'] = '[t width=100%]';
		$w = floor(100 / $args['cols']);
		}
	if ($args['table'] != '') {
		if ($args['table'] == 'true') $args['table'] = '[t width=100%]';
		$t1 = BOLTdomarkupTable($args['table'], '', 'block:table'); // open table
		}
// full template
	if (strpos($template, '[(template') !== false) {  // set up template sections
		if (substr($template, -1) == "\n") $template = substr($template, 0, -1);
		$parts = explode("\n[(template", "\n$template");
		foreach ($parts as $p) {
			if ($p == '') continue;
			$index = trim(substr($p, 0, strpos($p, ')]')));
			$display[$index] = substr($p, strpos($p, ')]') + 2);
			}
		if (count($pages) == 0 || $pages == Array(0=>'')) {
			if ($args['table'] != '') BOLTdomarkupTable('[r][c][t]', '', 'block:table'); // close table if no results
			return BOLTescape(BOLTvspace(BOLTdomarkupTable($display['none'], $pageLink, $args['rules'])));
			}
		$pagegroup = '';
		if (isset($display['first'])) {
			$temp = BOLTdisplayReplace($display['first'], 0, $pages, $args);
			$first = BOLTdomarkupTable($temp, '', $args['rules']);
			if ($first != '') $out .= $first . $join;
			}
		foreach ($pages as $i => $page) {
			if (isset($display['group'])) {
				if ($pagegroup != substr($page, 0, strrpos($page, "."))) {
					$pagegroup = substr($page, 0, strrpos($page, "."));
					$temp = BOLTdisplayReplace($display['group'], $i, $pages, $args);
					$group = BOLTdomarkupTable($temp, '', $args['rules']);
					if ($group != '') $out .= $group . $join;
					}
				}
			if (isset($display[$i + 1])) {
				$temp = BOLTdisplayReplace($display[$i + 1], $i, $pages, $args);
				$out .= BOLTdomarkupTable($temp, '', $args['rules']) . $join;
				}
			else {
				$temp = BOLTdisplayReplace($display['each'], $i, $pages, $args);
				$each = BOLTdomarkupTable($temp, '', $args['rules']);
				if ($each != '') $out .= $each . $join;
				}
			}
		if (isset($display['last'])) {
			$temp = BOLTdisplayReplace($display['last'], $i, $pages, $args);
			$last = BOLTdomarkupTable($temp, '', $args['rules']);
			if ($last != '') $out .= $last;
			}
		}
// inline template
	else {
		if (count($pages) == 0) {
			if ($args['table'] != '') BOLTdomarkupTable('[r][c][t]', '', 'block:table');  // close table if no results
			return;
			}
		if ($c != '') $out = BOLTdomarkupTable("[r top][c width={$w}%]", '', 'block:table'); // open table
		foreach($pages as $i => $page) {
			$temp = BOLTdisplayReplace($template, $i, $pages, $args);
			if($c != '') {
				if ($ii == $c) { $temp = "[c width={$w}%]$temp"; $ii = 0; }
				$ii = $ii + 1;
				}
			$new = BOLTdomarkupTable($temp, '', $args['rules']);
			if ($new != '') $out .= $new . $join;
			}
		$out = str_replace("</tr>\n<tr", "</tr><tr", $out);
		}
	if (substr($out, - strlen($join)) == $join) $out = substr($out, 0, - strlen($join));
	if ($args['table'] != '') {
		$t2 = BOLTdomarkupTable('[t]', '', 'block:table');  // close table
		$out = "$t1$out$t2";
		}
	if ($args['escape'] == 'false') return $out;
	return BOLTescape(BOLTvspace($out));
	}

function BOLTdisplayPrevNext($args, $pages) {
## RETURNS PREV / NEXT LINKS FAST AND EASY...
	global $pageLink;
	$start = BOLTinit($pageLink, $args['start']);
	$count = count($pages);
	$key = array_search($start, $pages);
	if ($key === false) return BOLTmessage("prev_next_fail::$start", $args);
	switch ($args[1]) {
		case 'next':
			if ($key < $count - 1) $out = $key + 1;
			break;
		case 'prev':
			if ($key != 0) $out = $key - 1;
			break;
		}
	if (isset($out)) {
		if ($args['fmt'] == '' || $args['fmt'] == 'list') return $pages[$out];
		return str_replace('{+p}', $pages[$out], $args['fmt']);
		}
	return $args['end'];
	}

function BOLTdisplayReplace($out, $i, $pages, $args=[]) {
## MAKES CERTAIN VARIABLES LIKE {+p} AVAILABLE IN TEMPLATES (ALSO SORTING)
	$page = $pages[$i];
	$parts = explode('.', $page);
	$out = str_replace('{+count}', $i + 1, $out);
	$out = str_replace('{+prev}', $pages[$i-1], $out);
	$out = str_replace('{+next}', $pages[$i+1], $out);
	$out = str_replace('{+p}', $page, $out);
	$out = str_replace('{+p0}', count($parts), $out);
	$out = str_replace('{+page}', end($parts), $out);
	$out = str_replace('{+field}', $i, $out);
	if (isset($args['info'])) $out = str_replace('{+value}', BOLTvars("$args[info]::$page"), $out);
	elseif (isset($args['query'])) $out = str_replace('{+value}', BOLTvars("$args[page]::$pages[$i]"), $out);
	else $out = str_replace('{+value}', $pages[$i], $out);
	if (strpos($out, '{+lastmodified}') !== false) {
		if (! isset($args['dir'])) $dir = '';
		else $dir = $args['dir'];
		$out = str_replace('{+lastmodified}', BOLTFlastmodified(Array('page' => $pages[$i], 'dir' => $dir)), $out);
		}
	foreach ($parts as $p => $pp) {
		$check = '{+p' . ($p+1) . '}';
		$out = str_replace($check, $pp, $out);
		}
	if (strpos($out, '{+') !== false) {
		if (isset($args['info'])) $args['query'] = $args['info'];
		$out = preg_replace_callback('/\{\+\#?([0-9]+)\}/', function($m) use ($args, $page) { return BOLTvars("$args[query]::$page::$m[1]"); }, $out); // {+3}
		$out = preg_replace_callback('/\{\+([^:{}+=*]+)\}/', function($m) use ($page) { return BOLTvars("$page:$m[1]"); }, $out);  // template replacements (was '{'.$page.':$1}')
		$out = preg_replace_callback('/\{\+:?([^{}+=*]+)\}/', function($m) use ($page) { return BOLTvars("$page:$m[1]"); }, $out);  // for nested template replacements
		}
	return $out;
	}

function BOLTdomarkup($content, $page='', $zone='', $rules='', $vspace='true') {
## THIS IS THE MAIN ENGINE WHICH TAKES A STRING AND RUNS THROUGH MARKUP TABLE. IT IS USED FOR EACH PAGE ZONE, AND EACH PAGE IN A TEMPLATE OUTPUT
	global $Token, $pageLink, $BOLTmsgOut, $BOLTzone;
	$tempzone = $BOLTzone;
	$BOLTzone = BOLTinit($BOLTzone, $zone);
	if ($page == '') $page = $pageLink;
	else $page = BOLTpageshortcuts($page);
	if ($content == '[results]' && $query == '' && $lastquery == '') return;
	if (preg_match('/^~~([0-9]+)~~$/', $content) === 1) return $content;
	$content = str_replace('<', '&lt;', $content);
	$out = BOLTdomarkupTable($content, $page, $rules);
	if ($vspace != 'false') $out = BOLTvspace($out);
	$BOLTzone = $tempzone;
	return BOLTurl2utf($out);
	}

function BOLTdomarkupTable($out, $page='', $rules='') {
	global $MarkUpTable, $BOLTrules, $pageLink, $BOLTzone;
	if ($page == '') $page = $pageLink;
	$tempArray = explode('.',$page);
	if (function_exists('myBOLTmarkupRules')) $rules = myBOLTmarkupRules($out, $page, $rules);
	if (is_array($BOLTrules)) $myMarkUpTable = $BOLTrules;
	else $myMarkUpTable = $MarkUpTable;
	$temppage = $pageLink;
	$pageLink = $page;
	$out = preg_replace('/\{\*\:([^{}+=*:]+)\}/', '{'.$page.'*:$1}', $out); // base pages
	foreach($myMarkUpTable as $i => $order) {
		foreach ($order as $ii => $rule) {
			if ($rules != '') {
				 if (inlist($i, $rules) === false && inlist("$i:$ii", $rules) === false) continue;
				 }
			if ($rule['replace'] == 'replace') $out = preg_replace($rule['pattern'], $rule['string'], $out);
			else $out = preg_replace_callback($rule['pattern'], function($matches) use ($rule) { return $rule['replace']($matches); }, $out);
			}
		}
	$pageLink = $temppage;
	return $out;
	}

function BOLTescape($x, $reverse=true, $spaced=false) {
## USED IN VARIOUS PLACES TO PRESERVE SOME OUTPUT AND BLOCK ANY FURTHER MARKUP PROCESSING. SET REVERSE TO FALSE TO UNESCAPE A STRING OF TEXT.
	if ($x == '') return;
	global $Token;
	if($reverse === false) {
		while (preg_match('/~~([0-9]+)\*?~~/', $x) != 0) $x = preg_replace_callback('/~~([0-9]+)\*?~~/', function($m) use ($Token) { return $Token[$m[1]]; }, $x);
		return $x;
		}
	if (is_array($Token)) $c = count($Token);
	$c = $c + 1;
	$Token[$c] = $x;
	if ($spaced) return "~~$c*~~";
	return "~~$c~~";
	}

function BOLTexecute($commands, $auto=false) {
## THIS FUNCTION EXECUTES THE COMMANDS IN A SUBMITTED AND SECURED FORM
	if ($commands == '') return;
	global $BOLTtoolmap, $pageLink, $BOLTcommands, $BOLTnextpage, $BOLTpassdata, $BOLTid;
	foreach ($commands as $field => $value) {
		if (strpos($field, "_") !== false) $command = substr($field, 0, strpos($field, "_"));  // allows command_1,command_2, etc
		else $command = $field;
		if ($auto != true) $value = $BOLTcommands[$field];  // just in case changed
		$args = BOLTargs($value);  // value = args[1], the rest are parameters
		if ($args['source'] != '') {
			$args['value'] = BOLTescape(BOLTFsource($args['source']), false);
			}
		foreach ($args as $f => $v) {
			$args[$f] = preg_replace_callback('/\{\=([=\:\\w]+)\}/', function($m) use ($v) { return BOLTstripQuotes(BOLTfieldreplace($m[1])); }, $v);
			if (substr($command, -4) == 'page') $args[1] = BOLTpageshortcuts($args[1]);
			if (substr($f, -4) == 'page') $args[$f] = BOLTpageshortcuts($args[$f]);  // is this right?
			}
		if ($BOLTtoolmap['x'][$command] != '') $command = $BOLTtoolmap['x'][$command];  // can forward one command to another
		else $command = BOLTtranslate($command, '', true);
		$do = 'BOLTX' . strtolower($command);
		if (function_exists('myBOLTwatch')) myBOLTwatch($do);	
		if ($args['if'] != '') {
			if (BOLTiftrue($args['if'], 'true') != 'true') {
				$BOLTcommands[$field] = '';
				continue;  // $args['value'] = '';
				}
			}
		if (function_exists($do)) $BOLTcommands[$field] = BOLTcommand($do, $args, $field);
		else $BOLTcommands[$field] = preg_replace_callback('/\{\=([=\:\\w]+)\}/', function($m) use ($value) { return BOLTstripQuotes(BOLTfieldreplace($m[1])); }, $value);
		if ($BOLTcommands[$field] == '~~ABORT~~') return;  // stops all processing immediately.
		}
	if ($auto == true) return;  // for running automated scripts
	$diff = array_diff_key($BOLTcommands, $commands);
	if (! empty($diff)) {
		if(BOLTexecute($diff, true) == '~~ABORT~~') return;
		}
	if ($BOLTnextpage == '') $BOLTnextpage = BOLTinit($pageLink, $BOLTcommands['nextpage']);
	BOLTredirect($BOLTnextpage . $BOLTpassdata); 
	}

function BOLTexists($page, $dir='') {
## CHECKS IF FILE EXISTS IN PAGES, SYSTEM OR LIBRARY DIRECTORIES.
	if (function_exists('myBOLTexists')) return myBOLTexists($page, $dir);
	if ($page == '') return false;
	if (strpos($page, '#')) $page = substr($page, 0, strpos($page, '#'));
	if (strpos($page, '&')) $page = substr($page, 0, strpos($page, '&'));
	$fpage = BOLTfolders($page);
	global $systemPath, $sharedPath, $BOLTpageLibraries;
	if ($BOLTpageLibraries != '') {  // allows pages outside of pages folder...
		$index = substr($page, 0, strpos($page, '.'));
		if (isset($BOLTpageLibraries[$index])) return file_exists("$BOLTpageLibraries[$index]/$page");
		}
	if ($dir != '') {
		switch($dir) {
			case 'pages': return file_exists("$dir/$fpage");
			case 'system': return file_exists("$systemPath/$page");
			case 'shared': return file_exists("$sharedPath/pages/$page");
			default:
				if (strpos($dir, '..') !== false) return false;
				return file_exists("$dir/$page");
			}
		}
	if (file_exists("pages/$fpage")) return true;
	if (file_exists("$systemPath/$page")) return true;
	if (file_exists("$sharedPath/pages/$page")) return true;
	return false;
	}

function BOLTfieldreplace($x, $args=[]) {
## USED TO DO FIELD REPLACEMENTS AND TEMPLATE INSERTIONS FROM POST FIRST, COMMANDS SECOND
	global $BOLTcommands;
	if (isset($_POST[$x])) return $_POST[$x];
	if (isset($BOLTcommands[$x])) return $BOLTcommands[$x];
	if (isset($args[$x])) return $args[$x];		
	}

function BOLTfilter($input, $type, $default='') {
## USED TO FILTER INPUTS OF VARIOUS TYPES. IF IT FAILS THE CORRESPONDING PATTERN CHECK IT RETURNS THE DEFAULT VALUE. DEFAULT FILTERS SET IN VARIABLES.PHP
	global $BOLTfilter;
	if ($type == '') return $default;
	if ($type == 'page') $input = BOLTutf2url($input);
	if (substr($type, 0, 1) != '/') {
		if (isset($BOLTfilter[$type])) $type = $BOLTfilter[$type];
		if (substr($type, 0, 1) != '/') $type = '/^[' . str_replace(Array('\\','^',']','/'), Array('\\\\','\^','\]','\/'), $type). ']+$/';
		}
	if (preg_match($type, $input) == 0) return $default;
	else return $input;		
	}
	
function BOLTfixdir($dir, $protect=true) {
## THIS FUNCTION CREATES DIRECTORIES AS NEEDED AND SETS HTACCESS PERMISSIONS
	if ($dir == '') return;
	if (! file_exists($dir)) {	
		mkdir($dir, 0777);
		clearstatcache();
		}
	if (! file_exists("$dir/.htaccess")) {
		if ($protect) $htaccess = "Order Deny,Allow\nDeny from all\n";
		else $htaccess = "Order Allow,Deny\nAllow from all\n";
		BOLTwrite("$dir/.htaccess", $htaccess);
		}
	return;
	}

function BOLTfolders($page, $htaccess=false) {
## THIS FUNCTION ALLOWS CERTAIN PAGES TO BE STORED IN SUBDIRECTORIES OF PAGES FOLDER. 
	if (function_exists('myBOLTfolders')) return myBOLTfolders($page, $htaccess);  // hook for custom functions
	global $BOLTfolders, $BOLTsiteFolders, $BOLTpageLibraries, $sitePages, $systemPath, $sharedPath;  // used for caching purpose
	if (isset($BOLTsiteFolders[$page])) return $BOLTsiteFolders[$page];
	if ($BOLTpageLibraries != '') {  // allows pages outside of pages folder...
		$index = substr($page, 0, strpos($page, '.'));
		if (isset($BOLTpageLibraries[$index])) return $BOLTpageLibraries[$index] . $page;
		}
	if (isset($BOLTfolders)) $contents = $BOLTfolders;
	else {
		if ($sitePages == '') $sitePages = 'pages';
		if (file_exists("$sitePages/site.folders")) $contents = file_get_contents("$sitePages/site.folders");
//		elseif (file_exists("$sharedPath/pages/site.folders")) $contents = file_get_contents("$sharedPath/pages/site.folders");
//		elseif (file_exists("$systemPath/site.folders")) $contents = file_get_contents("$systemPath/site.folders");
		else return $page;
		$BOLTfolders = $contents;
		}
	$lines = explode("\n", $contents);
	foreach ($lines as $line) {
		$line = trim($line);
		if (strpos($line, ": ") === false) continue;
		else {
			$find = substr($line, 0, strpos($line, ": "));
			$replace = substr($line, strpos($line, ": ") + 2);
			}
		if (substr($page, 0, strlen($find) + 1) == $find . "." || $page == $find) {  // checks each line for match
			if ($htaccess === false) BOLTfixdir("pages/$replace");
			$BOLTsiteFolders[$page] = "$replace/$page";
			return "$replace/$page";
			}
		}
	$BOLTsiteFolders[$page] = $page;
	return $page;	
	}

function BOLTformIn($key) {
	global $BOLTid, $pageLink, $BOLTformData;
	$expires = $BOLTformData[$key]['EXPIRES'];
	unset($BOLTformData[$key]['EXPIRES']);
	$form = json_encode($BOLTformData[$key]);
	$form_info = "$expires | $BOLTid | $pageLink | $form";
	BOLTformPoke($key, $form_info);
	}

function BOLTformOut($key) {
	global $pageLink; //  $BOLTtime, $BOLTid, $BOLTformData;
	$form_info = BOLTformPeek($key);
	$form_data = explode(' | ', $form_info);
	$form_data[3] = substr($form_info, strlen($form_data[0]) + strlen($form_data[1]) + strlen($form_data[2]) + 9);
	if ($pageLink != $form_data[2]) $out = false;
	else $out = json_decode($form_data[3], true);
	return $out;
	}

function BOLTformPeek($key) {
	global $BOLTtime, $BOLTid, $pageLink;
	if ($BOLTid == '') $formid = session_id();
	else $formid = $BOLTid;
	$content = trim(BOLTread("forms/form.$formid"));
	$lines = explode("\n", $content);
//cleans users form records
	foreach ($lines as $l => $line) {
		$keys = substr($line, 0, strpos($line, ': '));
		$form_info = substr($line, strlen($keys) + 2);
		$form_data = explode(' | ', $form_info);
		if ($BOLTtime > $form_data[0]) unset($lines[$l]);  // expired
		if ($BOLTid != $form_data[1]) unset($lines[$l]);  // probably logged out
		if ($key == $keys && $lines[$l] != '') {
			$out = $form_info;
			unset($lines[$l]);
			}
		}
	$content = implode("\n", $lines);
	BOLTwrite("forms/form.$formid", $content);
//cleans other old form records
	$forms = BOLTlistpages('', 'forms');
	foreach ($forms as $form) {
		if (filemtime("forms/$form") < $BOLTtime - 86400) unlink("forms/$form");
		}
	return $out;
	}

function BOLTformPoke($key, $form_info) {
	global $BOLTid;
	if ($BOLTid == '') $formid = session_id();
	else $formid = $BOLTid;
	$content = BOLTread("forms/form.$formid");
	$content = "$content\n$key: $form_info";
	BOLTwrite("forms/form.$formid", $content);
	}

function BOLTgetlines($out, $lines) {
## THIS SYSTEM FUNCTION IS USED BY INCLUDE & SOURCE TO RETRIEVE CERTAIN LINES AS IN LINES=5-10
	if (substr($out, 0, 1) == "\n") $out = substr($out, 1);
	$outlines = explode("\n", $out);
	if (substr($lines, 0, 1) == '-') $offset = substr($lines, 1);
	elseif (strpos($lines, '-') !== false) {
		$offset = substr($lines, 0, strpos($lines, '-'));
		if ($offset > 0) $offset = $offset - 1;
		$length = substr($lines, strpos($lines, '-') + 1) + 1;
		if ($length > 0) $length = $length - $offset - 1;
		}
	else {
		if ($lines > 0) $length = $lines;
		else $offset = $lines;
		}
	$outlines = array_slice($outlines, $offset, $length);
	return implode("\n", $outlines);		
	}

function BOLTgetlink($type='', $start='', $page='') { 
## A SECONDARY FUNCTION TO GET HIERARCHICAL LINKS. USED BY SKINS AND INCLUDE FUNCTION
	if (function_exists('myBOLTgetlink')) return myBOLTgetlink($type, $start, $page);
	global $pageLink;
	if ($type == 'main') return $pageLink;
	if ($page == '') $page = $pageLink; 
	if ($start != '') $page = "$start.$page";
	if (BOLTexists("$page.$type")) return "$page.$type";
	while (strpos($page, '.') !== false) {
		$page = substr($page, 0, strrpos($page, '.'));
		if (BOLTexists("$page.$type")) return "$page.$type";
		}
	return $type;
	}

function BOLTiftrue($condition, $content) {
## PART OF A THREE STEP PROCESS TO DETERMINE IF AN IF STATEMENT IS TRUE
	$content = BOLTstripSlashes($content);
	$condition = str_replace('&amp;&amp;', '&&', $condition);
	$condition = BOLTstripSlashes("($condition)");
	$condition = preg_replace_callback('/(&lt;|<)text ([^>]+)?>(.+?)(&lt;|<)\/text>/s', function($m) { return BOLTMtexttools(array('', $m[2], $m[3])); }, $condition);
	while (strpos($condition, "(") !== false) {
		$condition = preg_replace_callback('/\(([^()]*)?\)/', function($m) { return BOLTiftrue2($m[1]); }, $condition);
		}
//	if (strpos($condition, 'true') !== false) return $content; // if true, return content
	if ($condition === 'true') return $content; // if true, return content
	return; // if not, return nothing
	}

function BOLTiftrue2($condition) {
	if (strpos($condition, '&&')) {
		$x = explode('&&', $condition);
		foreach ($x as $i => $ii) $x[$i] = BOLTiftrue3($ii); 
		if (in_array('false', $x)) return 'false';
		else return 'true';
		}
	elseif (strpos($condition, '||')) {
		$x = explode('||', $condition);
		foreach ($x as $i => $ii) $x[$i] = BOLTiftrue3($ii);
		if (in_array('true', $x)) return 'true';
		else return 'false';
		}
	return BOLTiftrue3($condition);
	}

function BOLTiftrue3($condition) {
	global $BOLTtoolmap, $pluginPath;
//	$r = Array('(', ')', '! !');
	$condition = str_replace('! !', '', $condition);
	$condition = trim($condition);
	$tf = true;
	if (substr($condition, 0, 1) == "!") {
		$tf = false;
		$condition = trim(substr($condition, 1));
		}
	if (strpos($condition, ' ') !== false) {
		$params = substr($condition, strpos($condition, ' ') + 1);
		$condition = substr($condition, 0, strpos($condition, " "));
		$args = BOLTargs($params); 
		}
	else $args = Array();
	if ($BOLTtoolmap['c'][$condition] != '') $condition = $BOLTtoolmap['c'][$condition];
	else $condition = BOLTtranslate($condition, '', true);
//	if (function_exists('myBOLTwatch')) myBOLTwatch("BOLTC$condition");
	if (! function_exists("BOLTC$condition")) {
		$where = BOLTvars("site.dynafunc::BOLTC$condition", false);
		if ($where == '') {
			if ($tf == false) return 'true';
			return 'false';
			}
		if (file_exists("config/$where")) include_once("config/$where"); 
		elseif (file_exists("$pluginPath/$where")) include_once("$pluginPath/$where");
		if (! function_exists("BOLTC$condition")) {
			if ($where == '') {
				if ($tf == false) return 'true';
				return 'false';
				}
			}
		}
	$BOLTcondition = "BOLTC$condition";
	$value = $BOLTcondition($args);
	if ($value == $tf) return 'true';
	return 'false';
	}

function BOLTimgFind($file, $dir='') {
	if (function_exists('myBOLTimgFind')) return myBOLTimgFind($file, $dir);
	global $imgPath, $boltwire, $sharedURL, $rootImgPath;
	if (file_exists("$imgPath/$dir$file")) return "$sharedURL/img/$dir$file";
	if ($rootImgPath == '') {
		$root = $_SERVER['DOCUMENT_ROOT'];
		$root = substr($root, 0, strrpos($root, '/'));
		$root = $root . '/' . substr($boltwire, 3);
		}
	else $root = $rootImgPath;
	if (file_exists("$root/img/$dir$file")) return "$sharedURL/img/$dir$file";
	return false;
	}

function BOLTindex($rule='', $batch='') {
## SETS BATCH AND RULE. IF RULE NOT DEFINED DIVIDES BATCH AROUND ALL RULES. THEN SENDS INFO TO INDEXDO
	$batch = BOLTinit(BOLTconfig('indexBatch', 25), $batch);
	if($rule != '') {
		$myrule = BOLTvars("site.index::$rule");
		if ($myrule == '') return "Index rule //$rule// not found";
		$args = BOLTargs($myrule);
		return BOLTindexDo($rule, $batch, $args);
		}
	$content = BOLTloadpage('site.index');  // index rules
	preg_match_all('/^(\S+)\: (.+)?/m', $content, $matches);
	if (count($matches[0]) == 0) return 'No rules found.';
	$rules = array_combine($matches[1], $matches[2]);
	$batch = ceil(BOLTconfig('indexBatch', 25) / count($rules));  // a portion for each list
	foreach($rules as $rule => $params) {
		if ($params == '') continue;
		$args = BOLTargs($params);
		$out .= BOLTindexDo($rule, $batch, $params) . "\n";
		}
	return $out; 
	}

function BOLTindexAuto($pages) {
## THIS FUNCTION CHECKS ALL INDEX RULES AND INDEXES SPECIFIED ARRAY OF PAGES (BY DEFAULT, ALL CHANGED PAGES)
	$pages = array_unique($pages);
	if (empty($pages)) return;
	if (function_exists('myBOLTindexAuto')) return myBOLTindexAuto($pages); // a hook to process your own way
	$content = BOLTloadpage('site.index');  // index rules
	$content = BOLTdomarkupTable($content, 'site.index', 'vars');
	preg_match_all('/^(\S+)\: (.+)?/m', $content, $matches);
	if (count($matches[0]) == 0) return;  // no rules found
	$indexRoot = BOLTconfig('indexRoot', 'index');
	foreach($matches[2] as $i => $rule) {  // checks each rule
		$myPages = array();
		$indexName = $matches[1][$i];
		$index = "$indexRoot.$indexName";
		$args = BOLTargs($rule);
		$when = $args['when'];
		$mode = ucfirst($args['mode']);
		if ($mode == '') continue;
		$func = "BOLTindexDo$mode";
		if (! function_exists($func)) continue;
		foreach ($pages as $page) {
			$len = strlen($indexName);
			if (substr($page, 0, $len) != $indexName) continue;
			if (! BOLTexists($page)) {
				BOLTFinfo(BOLTargs("delete field=$page page=$index"), false);
				continue;
				}
			$myPages[] = $page;
			}
		$myPages = BOLTsearchResultsWhen($myPages, $args);
		if (empty($myPages)) continue;
		foreach ($myPages as $myPage) {
			$info = $func($myPage, $args);
			BOLTinfoPoke($index, $myPage, $info, 'true', false);
			$indexed[] = $myPage;
			}
		}
	if (is_array($indexed)) return "The following pages have been indexed: \n\n" . implode("\n", $indexed);
	}

function BOLTindexDo($rule, $batch, $args) {
## HERE IS THE MAIN FUNCTION THAT HANDLES INDEXING
	if (! BOLTexists("site.index.$rule")) return 'Index rule not found';
	$args['rule'] = $rule;
	if ($rule == '') return;
	$mode = $args['mode'];
	if ($mode == '') return 'Mode not set';
	$func = "BOLTindexDo$mode";
	if (! function_exists($func)) return "Mode //$mode// not found.";
	$mylist = BOLTloadpage("site.index.$rule");  // list to be indexed
	if (trim($mylist) == '') return "Index of rule //$rule// complete.";
	$pages = explode("\n", $mylist);
	$pagesBatch = array_slice($pages, 0, $batch);
	$myPages = BOLTsearchPageList($args, '', false);
	$myPages = implode(',', BOLTsearchResults($myPages, $args));
	foreach($pagesBatch as $p => $page) {
		if (inlist($page, $myPages)) $do[] = $page;
		unset($pages[$p]);  // remove processed pages from index list
		}
	$indexRoot = BOLTconfig('indexRoot', 'index');		
	$myindex = BOLTloadpage("$indexRoot.$rule");  // current index
	$lines = explode("\n", $myindex);
	foreach ($lines as $line) {
		if (strpos($line, ':') === false) continue;
		$page = substr($line, 0, strpos($line, ':'));
		if ($args['id'] == 'page') {
			if (strpos("$myPages,", ".$page,") === false) continue;
			}
		elseif (! inlist($page, $myPages)) continue;  // purges existing index if page no exist
		$current[$page] = substr($line, strpos($line, ':') + 2);
		}
	foreach ($do as $page) {
		$indexed[] = $page;  // pages indexed, regardless if anything found
		$new = $func($page, $args); // index individual page
		if ($args['id'] == 'page') $page = substr($page, strrpos($page, '.') + 1);
		$current[$page] = $new;
		}
	if ($args['indexsort'] == 'value') asort($current);
	elseif ($args['indexsort'] !== 'false') ksort($current, SORT_STRING);
	foreach ($current as $page => $value){
		if ($value != '') $out .= "$page: $value\n";
		}
	BOLTsavepage("$indexRoot.$rule", $out);  // the actual index
	$mylist = implode("\n", $pages);
	if ($mylist == '') $mylist = ' ';
	BOLTsavepage("site.index.$rule", $mylist);
	return implode("\n", $indexed) . "\n";
	}

function BOLTindexDoData($page, $args=Array()) {
	global $BOLTvar;
	$legend = $args['legend'];
	$indexRoot = BOLTconfig('indexRoot', 'index');
//	if ($legend == '') $legend = BOLTconfig(str_replace('.', '_', "legend_index_$rule"));
	if ($legend == '') $legend = BOLTvars("$indexRoot.$rule::legend", false);
	if ($legend == '') return BOLTmessage('index_no_legend', $args);
	$legend = explode(',', $args['legend']);
	BOLTvarCache('', $page);
	$data = $BOLTvar['#'][$page];
	foreach ($legend as $field) $out[] = BOLTinit('', $data[":$field"]);
	return implode(' | ', $out);
	}

function BOLTindexDoLinks($page, $args=[]) {
	if ($args['data'] == 'true') $data = 'data';
	$content = BOLTloadpage($page, '', $data);
	preg_match_all('/\[\[(.*?)(\&|\#|\||\])/', $content, $links);
	foreach($links[1] as $pp) $outlinks[] = BOLTpageshortcuts($pp, $p);
	if (! is_array($outlinks)) return;
	$linksArray = array_unique($outlinks);
	foreach($linksArray as $l => $ll) {
		if (BOLTfilter($ll, 'page') == false) unset($linksArray[$l]);
		}
	return implode(' ', $linksArray);
	}

function BOLTindexDoTags($page, $args=[]) {
	if ($args['data'] == 'true') $data = 'data';
	$content = BOLTloadpage($page, '', $data);
	$content = str_replace(Array('[#', '##'), '', $content);
	preg_match_all('/([^\#\[\'\"\=\:]\#([a-z]{1}[a-z0-9]*))\b/ei', $content, $matches);
	$tags = $matches[2];
	sort($tags);
	$tags	= array_unique($tags);
	return strtolower(implode(" ", $tags));
	}

function BOLTindexDoText($page, $args=[]) {
	$BOLTindexStrippedChars = Array ('!', '"', '#', '$', '%', '&', "'", '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~', "\n", "\r", "\t");
	if ($args['data'] == 'true') $data = 'data';
	$content = BOLTloadpage($page, '', $data);
	$content = preg_replace('/\{(.*?)\}/', ' ', $content);
	$content = preg_replace('/\[(.*?)\]/', ' ', $content);
	$content = preg_replace('/\<(.*?)\>/', ' ', $content);
	$content = str_replace($BOLTindexStrippedChars, ' ', $content);
	$textArray = array_unique(explode(" ", $content));
	return implode(" ", $textArray);
	}

function BOLTindexSetup() {
	global $BOLTindexPages, $BOLTtime;
	if (empty($BOLTindexPages)) return;
	$indexing = BOLTconfig('indexing', 'true');
	if ($indexing == 'true') {
		$indexed = BOLTindexAuto($BOLTindexPages);  // indexes any pages flagged as modified
		// BOLTlog("$BOLTtime: $indexed", 'test.log.indexing');  // used for debugging
		}
	elseif ($indexing == 'cron') {
		$cron = BOLTinit('site.index.cron', BOLTconfig('indexCron'));
		$cronExclude = BOLTinit('site', BOLTconfig('indexExclude'));
		$cronInclude = BOLTconfig('indexInclude');
		foreach ($BOLTindexPages as $todo) {
			$start = substr($todo, 0, strpos($todo, '.'));
			if (inlist($start, $cronExclude)) continue;
			if ($cronInclude != '' && ! inlist($start, $cronInclude)) continue;
			BOLTlog($todo, $cron, "\n", 'unique');
			}
		}
	}

function BOLTinfoPeek($page, $field, $auth=true, $parts='') {
	$content = "\n" . BOLTloadcontent($page, $auth);
	$pos = stripos($content, "\n$field: ");
	if ($pos === false) return;
	$content = substr($content, $pos + strlen("\n$field: "));
	if (strpos($content, "\n") !== false) $content = substr($content, 0, strpos($content, "\n"));
	if (is_number($parts)) {
		$split = explode(' | ', $content);
		$content = $split[$parts-1];
		}
	return $content;
	}

function BOLTinfoPoke($page, $field, $new='', $sort='', $auth=true) {
	global $BOLTid;
	if ($auth == true && BOLTauth($page, $BOLTid, 'view') == false) return;
	$content = "\n" . BOLTloadcontent($page, $auth);
	if ($new != '') $new = "\n$field: $new";
	if (strpos($content, "\n$field: ") !== false) {
		$old = substr($content, strpos($content, "\n$field: ") + 1);
		if (strpos($old, "\n") !== false) $old = substr($old, 0, strpos($old, "\n"));
		$content = substr(str_replace("\n$old", $new, $content), 1);
		if ($content == '') $content = ' ';
		}
	else $content = rtrim(substr($content, 1)) . $new;
	if (inlist($sort, 'true,reverse')) {
		$lines = explode("\n", $content);
		if ($sort == 'reverse') rsort($lines);
		else sort($lines);
		$content = implode("\n", $lines);
		}
	BOLTsavecontent($page, $content, $auth);
	}

function BOLTinfoDelete($page, $field, $auth=true) {
	global $BOLTid;
	if ($auth == true && BOLTauth($page, $BOLTid, 'view') == false) return;
	$content = BOLTloadpage($page, '', '', $auth);
	if ($content == '') return;
	else $content = "\n$content";
	if (strpos("\n$content", "\n$field: ") === false) return;
	$old = substr($content, strpos($content, "\n$field: ") + 1);
	if (strpos($old, "\n") !== false) $old = substr($old, 0, strpos($old, "\n"));
	$content = substr(str_replace("\n$old", '', $content), 1);
	if (empty($content)) $content = ' ';
	BOLTsavecontent($page, $content, $auth);
	}

function BOLTinfoVar($page, $var='', $default='', $auth=true, $pattern='') {
## THIS FUNCTION RETRIEVES INFO VAR'S FROM PAGE TEXT (OR $DEFAULT IF NOT FOUND). 
	global $BOLTinfoCache, $BOLTinfoVarPat, $BOLTid;
	if ($auth && ! BOLTauth($page, $BOLTid, 'view')) return;
	if (substr($page, -1) == '*') { $dir = 'stamps'; $page = substr($page, 0, -1); }
	$var = strtolower(BOLTutf2url($var));
	if (strpos($var, '::') !== false) {  // lets you get page::var::part
		$index = substr($var, strpos($var, '::') + 2);
		$var = substr($var, 0, strpos($var, '::'));
		}
	else $index = 0;
	if (isset($BOLTinfoCache[$page][$var][$index])) {
		if (! is_number($index)) {
			$legend = explode(' | ', $BOLTinfoCache[$page]['legend'][0]);
			$index = array_search($legend, $index);
			}
		return $BOLTinfoCache[$page][$var][$index];
		}
	if ($pattern == '') {
		if ($BOLTinfoVarPat == '') $pattern = '/^(\S+)\: (.+)?/m';
		else $pattern = $BOLTinfoVarPat;
		}
	$content = BOLTloadcontent($page, $auth);
	$content = str_replace('<', '&lt;', $content);
	preg_match_all($pattern, $content, $matches);
	foreach ($matches[1] as $i => $ii) {
		$f = strtolower(BOLTutf2url($ii));
		$v = str_replace('\n', "\n", $matches[2][$i]);
		if ($BOLTinfoCache[$page][$f][0] == '') $BOLTinfoCache[$page][$f][0] = preg_replace_callback('/\/\=(.*?)\=\//s', function($m) { return BOLTescape(BOLTstripSlashes($m[1])); }, $v);
		if (strpos($v, ' | ') !== false) {  //$index != 0
			$vv = explode(' | ', $v);
			foreach($vv as $i=>$ii) $BOLTinfoCache[$page][$f][$i + 1] = $ii;
			}
		else $BOLTinfoCache[$page][$f][1] = $v;
		}
	if (! is_number($index)) {
		$legend = explode(' | ', $BOLTinfoCache[$page]['legend'][0]);
		$index = array_search($index, $legend) + 1;
		}
	if ($BOLTinfoCache[$page][$var][$index] != '') return $BOLTinfoCache[$page][$var][$index];
	if ($page == 'site.messages') {
		$var2 = $BOLTinfoCache[$page][substr($var, 0, strrpos($var, "_"))];
		if (is_numeric(substr($var, strrpos($var, "_") + 1))) return $var2;
		}
	return $default;
	}

function BOLTingroup($group, $id='', $new=true) {
	global $BOLTid, $pagesPath, $BOLTgroups, $BOLTadmin;
	if ($id == '') $id = $BOLTid;
	if ($id == '') return false;
	$id = strtolower(BOLTutf2url($id));
	$group = strtolower($group);
	if ($id == $BOLTid && $new === true) return (inlist($group, $BOLTgroups));
	$groupPage = "group.$group";
	$groupList = strtolower(BOLTutf2url(BOLTloadpage($groupPage)));
	if ($groupList == '') return false;
	return (strpos("\n$groupList\n", "\n$id\n") !== false);
	}

function BOLTlistpages($pat=NULL, $dir='', $args=[]) {
## RETURNS A LIST OF PAGES MATCHING A GIVEN PATTERN. USE DIR FOR OTHER DIRECTORIES
	global $systemPath, $sharedPath, $BOLTlistpages;
	$BOLTlistpages = Array();
	if (isset($args['folders']) === false) $args['folders'] = 'default';
//	elseif ($args['folders'] != 'false') $args['folders'] = 'all';
	$dir = ltrim($dir, '.\/\\');
	if (substr($dir, 0, 6) == 'shared') $dir = $sharedPath . substr($dir, 6);
	if ($dir == 'system' || $dir == '') BOLTlistpages2($pat, $systemPath, $args);  // set dir=system to only show system pages
	if ($dir != 'system') {
		if ($dir == '') $mydir = 'pages';  // set dir=system to only show system pages
		else {
			$mydir = $dir;
			if (! file_exists($dir)) return;
			}
		BOLTlistpages2($pat, $mydir, $args);  
		}
	return $BOLTlistpages;
	}

function BOLTlistpages2($pat, $dir, $args=[]) {
## THIS FUNCTION ALLOWS YOU TO SEARCH PAGES WITHIN FOLDERS AND SUBFOLDERS
	global $BOLTlistpages;
	if ($handle = opendir($dir)) {
		while (false !== ($file = readdir($handle))) {
			if (substr($file, 0, 1) == ".") continue;
			switch ($args['folders']) {
				case 'true':  // only return subfolders. Is this even used?
					if (is_dir("$dir/$file")) $BOLTlistpages[] = $file;
					break;
				case 'false':  // only return kids, no grandkids
 					if (is_dir("$dir/$file")) continue;
					if ($pat != NULL && ! preg_match($pat, $file)) continue;
					$BOLTlistpages[] = $file;
					break;
				default:
 					if (is_dir("$dir/$file")) BOLTlistpages2($pat, "$dir/$file");
					else {
						if ($pat != NULL && ! preg_match($pat, $file)) continue;
						$BOLTlistpages[] = $file;
						break;
						}
				}
			}
		closedir($handle);
		}
	}

function BOLTloadcontent($page, $auth=false) {
	if (strpos($page, ':') !== false) return BOLTvars($page);
	return BOLTloadpage($page, '', '', $auth);
	}

function BOLTloadpage($page, $dir='', $data='', $auth=false) {
## LOADS PAGE AT $LOCATION (PAGES/FILE NAME), RETURNS CONTENTS. SET $DATA TO 'data' TO RETRIEVE DATA WITH PAGE TEXT
	if (function_exists('myBOLTloadpage')) return myBOLTloadpage($page, $dir, $data, $auth);
	if ($auth) {
		global $BOLTid;
		if (BOLTauth($page, $BOLTid, 'view') == false) return;
		}
	if (empty($page)) return;
	$page = strtolower($page);
	global $systemPath, $sharedPath, $BOLTpageStore, $BOLTpageLibraries;
	if (strpos($page, "#") !== false) {
		$anchor = BOLTurl2utf(substr($page, strpos($page, "#")));
		$page = substr($page, 0, strpos($page, "#"));
		}
	if ($dir == '' && $BOLTpageLibraries != '') {  // checks for pages outside of pages folder...
		$index = substr($page, 0, strpos($page, '.'));
		if (isset($BOLTpageLibraries[$index])) $dir = $BOLTpageLibraries[$index];
		}
	$page = strtolower(BOLTutf2url($page));
	$fpage = BOLTfolders($page);
	if ($dir != '') {
		$location = "$dir/$page";
		if (file_exists($location) == false) return;
		}
	elseif (file_exists("pages/$fpage")) $location = "pages/$fpage";
	elseif (file_exists("$sharedPath/pages/$page")) $location = "$sharedPath/pages/$page";
	elseif (file_exists("$systemPath/$page")) $location = "$systemPath/$page";
	else return;
	if ($dir != '' || ($BOLTpageStore[$page] == '' && filesize($location) > 0)) {
		$contents = BOLTread($location);
		$BOLTpageStore[$page] = str_replace(Array("\r\n", "\r"), "\n", $contents);
		}
	$out = $BOLTpageStore[$page];
	if ($data != 'data' && strpos($out, "\n~data~\n") !== false) {
		$out = substr($out, 0, strpos($out, "\n~data~\n"));
		$out = str_replace('&#126;', '~', $out);
		$parts = explode('.', $page);
		if (! inlist($parts[0], 'code,cache')) $out = str_replace('<', '&lt;', $out);
		}
	if (isset($anchor)) {
		if ($anchor == '#') {
			if (strpos($out, '[[#') !== false) return substr($out, 0, strpos($out, '[[#'));
			return $out;
			}
		elseif (preg_match('/\[\['.$anchor.'(\|.+)?\]\]/', $out, $matches) == 1) {
			$out = substr($out, strpos($out, $matches[0]) + strlen($matches[0]));
			if (strpos($out, "[[#") !== false) return substr($out, 0, strpos($out, "[[#"));
			return $out;
			}
		return;
		}
	return $out;
	}

//NOT NEEDED IN 7.xx
function BOLTloadskin($type) {
	global $skinPath, $BOLTskin, $boltwire;
	$file = "code.skin.$BOLTskin.$type";
	$out = BOLTloadpage($file);
	if ($out == '') {
		$out = file_get_contents("$skinPath/$BOLTskin/$file");
		if ($out == '') $out = file_get_contents("$boltwire/shared/skins/$BOLTskin/$file");
		if ($out == '') return;
		if (BOLTconfig('localSkins') == 'true') BOLTsavepage($file, $out);
		}
	return $out;
	}

function BOLTlog($content, $page, $delimiter="\n", $flags='') {
## THIS IS THE MAIN SCRIPT USED BY THE LOG COMMAND/FUNCTION MARKUPS. FLAGS INCLUDE DELETE/REMOVE, TRIM=5 (MAX), TOP (BOTTOM DEFAULT), SORT, UNIQUE, LINE=3 (REPLACE 3RD LINE)
	if ($delimiter == 'false') $delimiter = '';
	else $content = str_replace($delimiter, ' ', $content);
	if (strpos($flags, 'lowercase') !== false) $content = strtolower($content);
	$source = BOLTloadcontent($page);
	$flags = str_replace('delete', 'remove', $flags);
	if (strpos($flags, "remove") !== false && $content != '') {
		if ($source == $content) $source = '';
		$source = str_replace("$delimiter$content", '', $source);
		$source = str_replace("$content$delimiter", '', $source);
		}
	elseif (strpos($flags, "line=") === false) {
		if (strpos($flags, "top") !== false) $source = "$content$delimiter$source";
		else {
			if ($source == '') $source = $content;
			else $source = "$source$delimiter$content";
			}
		}
	if (strpos($flags, 'sort') !== false || strpos($flags, 'trim=') !== false || strpos($flags, 'unique') !== false || strpos($flags, 'line=') !== false) {
		if ($delimiter != '') {
			$editlist = explode ($delimiter, $source);
//			if ($editlist[count($editlist) - 1] == '') array_pop($editlist);
			if (strpos($flags, 'sort') !== false) natcasesort($editlist);
			if (strpos($flags, 'sort') !== false || strpos($flags, 'unique') !== false) $editlist = array_unique($editlist);
			if (strpos($flags, 'reverse') !== false) $editlist = array_reverse($editlist);
			if (strpos($flags, 'trim') !== false) {
				$trim = substr($flags, strpos($flags, 'trim=') + 5);
				if (strpos($trim, ',') !== false) $trim = trim(substr($trim, 0, strpos($trim, ',')));
				if (substr($trim, 0, 1) == '-') {  // trims top
					if (count($editlist) > substr($trim, 1)) {
						$editlist = array_slice($editlist, $trim);
						}
					}
				elseif (count($editlist) > $trim) $editlist = array_slice($editlist, 0, $trim);	// trims bottom
				}
			if (strpos($flags, 'line=') !== false) {
				$line = substr($flags, strpos($flags, 'line=') + 5);
				if (strpos($line, ',') !== false) $line = trim(substr($line, 0, strpos($line, ',')));
				if ($line != 0) $editlist[$line - 1] = $content;
				}
			$source = implode($delimiter, $editlist);
			}
		}
	if ($delimiter != '') $source = str_replace("$delimiter$delimiter", $delimiter, $source);
//	$source = str_replace('\n', "\n", $source);  // disabled because needed for stash id
	if ($source == '') $source = ' ';
	$source = str_replace(Array('&amp;', '&lt;', '&gt;'), Array('&', '<', '>'), $source);
	BOLTsavecontent($page, $source);
	return;
	}

function BOLTlogin($id, $args, $title='') {
## SETS ALL THE VARIABLES FOR A LOGGED IN MEMBER
	if (function_exists('myBOLTlogin')) return myBOLTlogin($id, $args, $title);
	global $BOLTsession, $BOLTid, $BOLTmember, $BOLTvar;
	$BOLTsession['ID']['id'] = $id;  // users passes authentication
	$BOLTid = $id;
	$BOLTvar['id'] = $id;
	$member = BOLTinit(BOLTvars("member.$id:title", false), $title);
	$BOLTsession['ID']['member'] = $member;
	$BOLTmember  = $member;
	$BOLTvar['member'] = $member;
	BOLTFgroups(BOLTargs("msg=false"));
	if (is_number($args['persist'])) {
		$fields = Array('autoid'=>$id, 'autopass'=>$args['pass']);
		BOLTpersist($fields, $args['persist']);
		}
	BOLTmessage("login_success", $args);
	}

function BOLTlogout($args) {
## DELETES LOGIN SESSION INFORMATION FROM USER
	if (function_exists('myBOLTlogout')) return myBOLTlogout($args);
	global $BOLTsession, $BOLTid, $BOLTmember, $BOLTid, $BOLTgroups, $BOLTvar, $BOLTfield;
	unset($BOLTsession['ID']);
	$BOLTid = '';
	$BOLTmember = BOLTconfig('guestname', 'Guest');
	$BOLTgroups = 'guest';
	$BOLTvar['id'] = '';
	$BOLTvar['member'] = $BOLTmember;
	$fields = Array('autoid'=>'', 'autopass'=>'');
	BOLTpersist($fields);
	BOLTmessage('logout_success', $args);
	}

function BOLTmail($mail, $args=[]) {
	if (function_exists('myBOLTmail')) return myBOLTmail($mail, $args);
	$header = "From: $mail[from]\r\nReply-To: $mail[reply]\r\nReturn-Path: $mail[return]\r\n";
	if ($mail['html']) $header .= "MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\n";  // IF HTML
	else $header .= "MIME-Version: 1.0\r\nContent-Type: text; charset=UTF-8\r\n";
	$success = mail($mail['to'], $mail['subject'], $mail['body'], $header);
	return $success;
	}

function BOLTmakeJs($js) {
	global $BOLTformJs;
	if ($js == '') return;
	$js = BOLTstripQuotes($js);
	if (strpos($js, '::') !== false) {
		$jsArgs = explode('::', $js);
		$js = $jsArgs[0];
		unset($jsArgs[0]);
		}
	$jsOut = BOLTinit(BOLTvars("code.js::$js", false), $BOLTformJs[$js]);
	if (is_array($jsArgs)) {
		foreach($jsArgs as $j => $jj) $jsOut = str_replace("{+$j}", $jj, $jsOut);
		}
	return str_replace('<', '&lt;', $jsOut);
	}

function MarkUp($order, $rule, $pattern='', $replace='', $str='') {
## THIS FUNCTION CREATES THE $MARKUPTABLE. TO CHANGE A MARKUP RULE: MarkUp('order', 'rule', '/pattern/', 'output'); TO DELETE A MARKUP RULE SET PATTERN TO ''. TO INSERT MARKUP SET RULE TO 'newrule < oldrule'.
	global $MarkUpTable;
	if (strpos($rule, '<') !== false) {
		$new = trim(substr($rule, 0, strpos($rule, '<')));
		$rule = trim(substr($rule, strpos($rule, '<') + 1));
		$array = $MarkUpTable[$order];
		foreach ($array as $f => $v) {
			if ($f != $rule) $array2[$f] = $MarkUpTable[$order][$f];
			else {
				$array2[$new]['pattern']  = $pattern;
				$array2[$new]['replace']  = $replace;
				$array2[$f] = $MarkUpTable[$order][$f];
				}
			}
		$MarkUpTable[$order] = $array2;
		}
	elseif ($pattern == '')	unset($MarkUpTable[$order][$rule]);
	else {
		$MarkUpTable[$order][$rule]['pattern'] = $pattern;
		$MarkUpTable[$order][$rule]['replace'] = $replace;
		if ($str != '') $MarkUpTable[$order][$rule]['string'] = $str;
		}
	}

function BOLTmessage($id, $args=[], $msg='') {
## THIS FUNCTION ADDS A MESSAGE TO THE MESSAGE ARRAY FOR LATER DISPLAY
	if (isset($args['msg'])) { if ($args['msg'] == 'false') return; }
	global $BOLTsession;
	if ($id == 'all') unset($BOLTsession['MSG']);
	if (strpos($id, '::') !== false) {
		$field = explode('::', $id);
		$id = $field[0];
		}
	if (strpos($id, '~') !== false) {
		$index = substr($id, strpos($id, '~') + 1) - 1;
		$id = substr($id, 0, strpos($id, '~'));
		}
	elseif (isset($args['id'])) { if ($args['id'] == $id) unset($BOLTsession['MSG'][$id]); }// clears messages of this type
	if ($msg == '') $msg = BOLTvars("site.messages::$id", false);
	$msg = BOLTtranslate(BOLTurl2utf($msg));
	$msg = str_replace('&#36;', '$', $msg);
	$msg = str_replace('$1', $field[1], $msg);
	$msg = str_replace('$2', $field[2], $msg);
	if (! isset($index)) {
		if (! is_array($BOLTsession['MSG'][$id])) $index = 0;
		else $index = count($BOLTsession['MSG'][$id]);
		}
	$BOLTsession['MSG'][$id][$index] = trim($msg);
	}

function BOLTmessageDisplay($msg_ids='') {
## PREPARES MESSAGES FOR FINAL OUTPUT, CALLED ONCE AT END OF PAGE CREATION
	global $BOLTsession;
	$args = BOLTargs(BOLTstripslashes($msg_ids));
	if ($args['class'] == '') $args['class'] = 'message';
	$msg_ids = $args[1];
	if (is_array($args)) {
		foreach($args as $f => $v) {
			if (! in_array($f, BOLTattrs('messages'))) continue;
			$attr .= " $f=\"" . $v . "\" "; 
			}
		}
	$msg = $BOLTsession['MSG'];
	if (! isset($msg)) return;
	$msg_ids = trim($msg_ids);
	if ($msg_ids != '') {  // ids to show specified
		$mm = explode(',', $msg_ids);
		foreach($mm as $m) {
			if (strpos($m, '~') !== false) {
				$i = substr($m, 0, strpos($m, '~'));
				$ii = substr($m, strpos($m, '~') + 1) - 1;
				$arr[][] = $msg[$i][$ii];
				}
			else{
				if (strpos($m, '_') !== false) {
					$n = substr($m, strpos($m, '_') + 1);
					if ($n == 1) $m = substr($m, 0, strpos($m, '_'));
					else {
						$n = $n - 1;
						$m = substr($m, 0, strpos($m, '_')) . '_' . $n;
						}
					}
				$arr[] = $msg[$m];
				}
			}
		}
	else $arr = $msg;  // show all messages
	if (count($arr) == 0 || $arr == Array('0'=> NULL)) return;
	$join = BOLTconfig('msgJoin', ' ');
	if ($join == 'lines') $join = "\n";
	foreach($arr as $a) $out .= implode(' ', $a) . $join;
	$out = trim($out);
	if ($out == '') return;
	$out = BOLTdoMarkup($out, '', 'MSG');
	return "<div $attr>$out</div>";
	}

function BOLToutput($value, $args) {
## USED TO REFINE OUTPUT CALLED BY A FUNCTION OR COMMAND BASED ON OUTPUT PARAMETER
if (function_exists('myBOLTfuncOutput')) return myBOLTfuncOutput($value, $args);
	switch($args['output']) {
		case 'source' : return BOLTMbox(array('', '', 'code', '', $value));
		case 'html' : return BOLTMbox(array('', '', 'html', '', $value));
		case 'nolines' : return str_replace("\n", ' ', $value);
		case 'escape' : return BOLTescape($value);
		default : return $value;
		}
	}

function BOLTpageCheck($check, $page='') {
## CHECKS TO SEE WHETHER $page OR CURRENT PAGE IS IN CHECK (A STRING LIKE site*,main,test.alpha*)
	if ($check == '') return true;
	global $pageLink;
	if ($page == '') $page = $pageLink;
	$c = explode(',', $check);
	foreach ($c as $cc) {
		if ($cc == $page) return true;
		if (substr($cc, -1) == '*' && substr($page, 0, strlen($cc) - 1) == substr($cc, 0, -1)) return true;
		}
	return false;
	}

function BOLTpageshortcuts($link, $basepage='') {
## VARIOUS SHORTCUTS THAT CAN BE USED IN MISC WAYS TO MODIFY LINKS (OR PAGES IN COMMANDS).
	if (function_exists('myBOLTpageshortcuts')) return myBOLTpageshortcuts($link, $basepage);
	if (strpos($link, '://') !== false) return $link;
	global $pageLink, $BOLTid, $BOLTtime;
	if ($basepage != '') {
		$myPage = $basepage;
		$myArray = explode('.', $basepage);
		}
	else {
		$myPage = $pageLink;
		$myArray = explode(".", $pageLink);
		}
	if ($link == '') return $myPage;
	$link = str_replace('&amp;', '&', $link);
	if (strpos($link, "/")) $link = str_replace("/", ".", $link);
	$get = '';
	if (strpos($link, '&') !== false) {
		$get = substr($link, strpos($link, "&"));
		$link = substr($link, 0, strpos($link, "&"));
		}
	if (strpos($link, '#') !== false) {
		if (strpos($link, '#') + 1 != strlen($link)) {
			$anchor = '#' . BOLTutf2url(substr($link, strpos($link, "#") + 1));
			$link = substr($link, 0, strpos($link, "#"));
			}
		}
	$link = str_replace(' ', '_', $link);
	if (BOLTconfig('utfpages', 'true') == 'true') $link = BOLTutf2url($link);
	$link = strtolower(trim($link));
	switch (substr($link, 0, 1)) {
		case '.':
			$dots = strlen($link) - strlen(ltrim($link, '.'));
			for ($i=0; $i<$dots; $i++) {
				if (isset($myArray[$i])) $temp .= $myArray[$i] . '.';
				}
			$link = $temp . substr($link, $dots);
			break;
		case '=': $link = $myPage . '.' . substr($link, 1); break;
		case '@': $link = 'group.' . substr($link, 1); break;
		case '!': $link = 'action.' . substr($link, 1); break;
		case '~': $link = 'member.' . substr($link, 1); break;
		}
	$rr1 = array('+','..',' ','^');
	$rr2 = array($BOLTtime,'.','_',$BOLTid);
	$link = trim(str_replace($rr1, $rr2, $link), '.');
	if (substr($link, -1) == '#') {
		$link = trim(substr($link, 0, -1), '.');
		$link = $link . '.' . BOLTthread($link);
		}
	return $link . $anchor . $get;	
	}
	
## DETERMINE WHICH PAGE IS DISPLAYED (IF AN ACTION IS CALLED)
function BOLTpageShow() {
	global $BOLTvar, $BOLTreplaceHTML, $pageLink, $actionPage, $BOLTid;
	if (isset($_GET['action'])) {
		$BOLTvar['action'] = $_GET['action'];
		if (BOLTauth($pageLink, $BOLTid, "action_$_GET[action]") !== true) $blocked = true;
		elseif (BOLTauth("action.$_GET[action]", $BOLTid, 'view') !== true) $blocked = true;
		if ($blocked) {
			$BOLTvar['action'] = 'blocked';
			if (BOLTconfig('serverHeaders', 'true') == 'true') header('HTTP/1.1 403 Forbidden');
			}
		}
	else {
		if (! BOLTexists($pageLink)) { 
			$BOLTvar['action'] = 'missing';
			if (BOLTconfig('serverHeaders', 'true') == 'true') {
				header('HTTP/1.1 404 Not Found');
				$BOLTreplaceHTML['find'][] = '</head>';
				$BOLTreplaceHTML['replace'][] = "<meta name='robots' content='noindex'>\n</head>";
				}
			}
		if (BOLTauth($pageLink, $BOLTid, 'view') !== true) {  
			$BOLTvar['action'] = 'blocked';
			if (BOLTconfig('serverHeaders', 'true') == 'true') header('HTTP/1.1 403 Forbidden');
			}
		}
	if (isset($BOLTvar['action']) && ! inlist($BOLTvar['action'], 'print,view')) $actionPage = BOLTgetlink($BOLTvar['action'], 'action');
	elseif (BOLTfolders($pageLink) != $pageLink) $BOLTvar['dir'] = 'pages/' . substr(BOLTfolders($pageLink), 0, strlen($pageLink));
	}

function BOLTpersist($fields, $expires='') {
	global $BOLTcookiePath;
	$path = BOLTinit('/', $BOLTcookiePath);  
	if ($expires == '') $exp = time() - 86400;
	elseif ($expires > time()) $exp = $expires;
	else $exp = time() + $expires;
	foreach ($fields as $f => $v) {
		setcookie($f, $v, $exp, $path);
		$_COOKIE[$f] = $v;
		}
	}

function BOLTquery($pageArray, $index='') {
## THIS FUNCTION OPENS AN INDEX AND STRIPS OUT THE APPROPRIATE LINES FOR SEARCHING
	if ($index == '') return Array();
	$contents = BOLTloadcontent($index);
	if ($contents == '') return Array();
	preg_match_all('/^([-_a-z0-9.%@]+)\: (.*)?/im', $contents, $matches);
	$info = array_combine($matches[1], $matches[2]);
	if (! empty($pageArray)) {
		foreach ($info as $page => $value) {
			if (! in_array($page, $pageArray)) unset($info[$page]); 
			}
		}
	if (empty($info)) return Array();
	return $info;
	}

function BOLTqueryData($lines, $criteria, $args) {
## SETS UP CHECKS AND RUNS LINES THROUGH EACH, DELETING PAGES THAT FAIL
	if (empty($lines)) return Array();
	foreach ($criteria as $c) {  // the raw data criteria
		$c = strtolower($c);
		$c = str_replace(Array('(&lt;)', '(&gt;)', '(&amp;)'), Array('(<)', '(>)', '(&)'), $c);
		$field = strtolower(substr($c, 0, strpos($c, '(')));  // field you check
		$field = BOLTqueryLegend($field, $args['query'], $args['legend']); // part index
		if ($field !== '') {
			$find[$field] = BOLTtrimQuotes(strtolower(substr($c, strpos($c, ')') + 1)));  // value you look for
			$key[$field] = substr($c, strpos($c, '(') + 1, 1);  // operator used 
			}
		}
	if (! is_array($find)) return Array();
	foreach ($lines as $page => $line) {  // current queryArray
		$line = strtolower($line);
		$parts = explode(' | ', $line);
		foreach ($find as $f => $v) {  // $i index for f, v & key
			if (BOLTqueryData2($v, $key[$f], $parts[$f]) == false) unset($lines[$page]);  // knocks out if doesn't match
			}
		}
	if (empty($lines)) return Array();
	return $lines;
	}

function BOLTqueryData2($v, $key, $p) {
## CHECKS ONE SPECIFIC LINE, BASED ON FIELD, VALUE & KEY. RETURNS TRUE IF FAILS, INDICATING PAGE SHOULD BE REMOVED
	switch($key) {
		case '<': return ($p < $v);
		case '>': return ($p > $v);
		case '&':
			$range = explode('|', $v); 
			return ($p >= $range[0] && $p <= $range[1]);
		case ',':
			if (strpos($v, ',') !== false && strpos($p, ',') === false) return inlist($p, $v);
			return inlist($v, $p);
		case '+': return (strpos($p, $v) !== false);
		case '-': return (strpos($p, $v) === false);
		case '?': return ($p != '');				
		case '^': return ($p == '');
		case '!': return ($p != $v);
		case '0': return (preg_match($v, $p) == 0);
		case '1': return (preg_match($v, $p) == 1);
		default:  return ($p == $v); // (=)
		}
	}

function BOLTqueryLegend($field, $query, $legend='') {
	$part = substr($field, 1);
	if (substr($field, 0, 1) == '#' && is_number($part)) return $part - 1;
//	if ($legend == '') $legend = BOLTconfig(str_replace('.', '_', "legend_$query"));
	if ($legend == '') $legend = BOLTvars("$query::legend");
	if ($legend == '') return;
	$legendArray = array_flip(explode(' | ', $legend));
	if (in_array($field, $legendArray)) return $legendArray[$field];
	return;  // invalid search field		
	}

function BOLTqueryLink($lines, $find, $args) {
## SIMPLE CHECK TO SEE WHICH PAGES IN OUTARRAY HAVE THE SPECIFIED LINK IN THEM
	if (empty($lines)) return Array();
	foreach($lines as $page => $links) {
		if (strpos(" $links ", " $find ") !== false) $out[$page] = $links;
		}
	if (empty($out)) return Array();	
	return $out;
	}

function BOLTqueryText($lines, $find, $args) {
## FIRST OF THREE FUNCTIONS USED IN QUERY TEXT IN INDEX -- THIS ONE TAKES CARE OF PARENTHESIS
	if ($lines == Array()) return;
	global $tempSearchArray, $searcharray;
	$tempSearchArray = $lines;
	if(substr($find, 0, 1) == '(') return; // why this? what about (one && two) || (three && four) 
    // solution: if no ( in string, do checknext directly, else run through nesting of parens.
	$find = "($find)";
	while (strpos($find, "(") !== false) {
		$find = preg_replace_callback('/\(([^()]*)\)/', function($m) use ($args) { return BOLTqueryText2($m[1], $args); }, $find);
		}
	$results = $searcharray[substr($find, 1)];
	if (! is_array($results)) $results = Array();
	foreach($results as $page) $out[$page] = $lines[$page];
	return $out;
	}

function BOLTqueryText2($find, $args) {
## THIS ONE TAKES CARE OF && AND ||
	global $searcharray, $searchcount;
	$find = stripslashes(trim($find));
	$find = str_replace(Array('"', "'"), '', $find);  // add a mechanism for finding strings?
	if (strpos($find, '&&') === false && strpos($find, '||') === false) $find = preg_replace('/(\b\s+\b)/', ' && ', $find);
	if (! isset($searchcount)) $searchcount = 0;
	$searchcount = $searchcount + 1;
	if (strpos($find, '&&')) {
		$x = explode('&&', $find); 
		foreach ($x as $i => $ii) {
			$ii = trim($ii);
			if (substr($ii, 0, 1) == "~") $search[$ii] = $searcharray[substr($ii, 1)];
			else $search[$ii] = BOLTqueryText3($ii, $args);
			if ($i == 0) {
				$searchtemp = $search[$ii];
				}
			else {
				if (is_array($search[$ii])) $searchtemp = array_intersect($searchtemp, $search[$ii]);
				else $searchtemp = Array();
				}
			}
		$searcharray[$searchcount] = $searchtemp;
		return "~$searchcount";
		}
	elseif (strpos($find, '||')) {
		$x = explode('||', $find); 
		foreach ($x as $i => $ii) {
			$ii = trim($ii);
			if (substr($ii, 0, 1) == "~") $search[$ii] = $searcharray[substr($ii, 1)];
			else $search[$ii] = BOLTqueryText3($ii, $args);
			if ($i == 0) $searchtemp = $search[$ii];
			else $searchtemp = array_unique(array_merge($searchtemp, $search[$ii]));
			}
		if (! is_array($searchtemp)) $searchtemp = Array();
		$searcharray[$searchcount] = $searchtemp;
		return "~$searchcount";
		}
	else {
		$searcharray[$searchcount] = BOLTqueryText3($find, $args);
		return "~$searchcount";
		}
	}

function BOLTqueryText3($find, $args) {
## THIS ONE TAKES CARE OF ! AND DOES ACTUAL CHECK
	global $tempSearchArray;
	if ($args['case'] != 'true') $find = strtolower($find);
	if ($args['words'] !== 'false') $s= " ";
	else $s = "<>";
	$tf = true;
	if (substr($find, 0, 1) == "!") {
		$tf = false;
		$find = trim(substr($find, 1));
		}
	if (substr($find, -1) == '*') $find = substr($find, 0, -1);
	foreach($tempSearchArray as $page => $p) {
		$line = explode(':', $p);
		$check = $s . $line[0] . $s;
		if ($args['case'] != 'true') $check = strtolower($check);
		if ($tf == true && preg_match("/\b($find)\b/ie", $check) != 0) $search[] = $page;
		elseif($tf == false && preg_match("/\b($find)\b/ie", $check) == 0) $search[] = $page;
		}
	return $search;
	}

function BOLTrenametree($from, $to, $dir, $args=[], $pat='') {
## USED IN RENAME COMMAND TO SIMULTANEOUSLY RENAME ALL STAMPS
	if ($pat == '') $pat = str_replace(".", "\.", "/^$from.([-_a-z0-9.]*)$/");
	$trees = BOLTlistpages($pat, $dir);
	if (empty($trees)) return;
	foreach($trees as $tree) {
		$new = str_replace($from, $to, $tree);
		$success = rename("$dir/$tree", "$dir/$new");
		if (! $success) BOLTmessage("rename_fail::$tree", $args);
 		}
 	}

function BOLTsafetext($text, $page='') {
## PROTECTS AGAINST UNSAFE DATA BEING SAVED
	$unsafe[] = '~data~';  $safe[] = '~`data~'; // prevents messing with data
	$unsafe[] = "\r\n";  $safe[] = "\n";
	$unsafe[] = "\r";  $safe[] = "\n";
	$unsafe[] = '%3c'; $safe[] = '<';
	if ($page == '' || (! BOLTingroup('admin') && ! BOLTingroup('editor')))	{  // blocks unauthorized form creation
		$unsafe[] = '[form'; $safe[] = '[`form'; 
		}
	$text = str_replace($unsafe, $safe, $text);
	return $text;
	}

function BOLTsavecontent($page, $content, $auth=true) {
	if (strpos($page, ':') !== false) {
		list($page,$field) = explode(':',$page,2);
		BOLTsavedata(Array($field=>$content), $page, $auth);
		}
	else BOLTsavepage($page, $content);
	}

function BOLTsavedata($data, $page='', $auth=true) {
## THIS FUNCTION HANDLES UPDATING OF DATA VALUES. DATA IS AN ARRAY OF FIELD=VALUE PAIRS (USE FIELD='' TO UNSET A DATA FIELD). 
	global $pageLink, $BOLTid;
	if (! is_array($data)) return;
	$page = BOLTinit($pageLink, $page);
	$page = BOLTpageshortcuts($page);
	if (BOLTexists($page)) {
		$content = BOLTloadpage($page, '', 'data', false);
		if (strpos($content, "\n~data~\n") !== false) {
			$getdata = substr($content, strpos($content, "\n~data~\n") + 8);
			$d = explode("\n~\n", $getdata);
			foreach ($d as $line) {
				if (strlen($line) < 3) continue;
				$f = substr($line, 0, strpos($line, ": "));
				$v = substr($line, strpos($line, ": ") + 2);
				$current[$f] = $v;
				}
			}
		}
	foreach ($data as $field => $value) {
		$field = trim($field);
		if ($auth && ! BOLTauth("$page:$field", $BOLTid, 'data')) continue;
		elseif ($value === '') unset($current[$field]);
		else $current[$field] = BOLTsafetext($value);
		}
	if (is_array($current)) {
		foreach ($current as $i => $ii) {
			if ($i == BOLTutf2url($i)) $i = strtolower($i);
			$setdata .= "$i: $ii\n~\n";
			}
		if (substr($setdata, 0, 1) == "\n") $setdata = substr($setdata, 1);
		}
	$setdata = "\n~data~\n" . $setdata;
	BOLTsavepage($page, '', $setdata);
	}

function BOLTsavepage($page, $newcontent='', $newdata='', $conflict='') {
## SYSTEM FUNCTION FOR SAVING PAGES, SECURES AGAINST DISALLOWED CODE
	if (function_exists('myBOLTsavepage')) return myBOLTsavepage($page, $newcontent, $newdata, $conflict);
	global $systemPath, $BOLTsession, $BOLTpageStore, $lastedit,  $pageLink, $BOLTindexPages;
	if (strpos($page, '#') !== false) {
		$anchor = '[[' . BOLTurl2utf(substr($page, strpos($page, '#'))) . ']]'; // Note: can't find [[#anchor|label]]
		$page = BOLTutf2url(substr($page, 0, strpos($page, '#')));
		}
	$page = BOLTfilter(strtolower($page), 'page');
	if ($page == '') BOLTabort('missing_page_name');
	if (BOLTexists($page)) {
		$getpage = BOLTloadpage($page, '', 'data');
		if (strpos($getpage, "\n~data~\n") !== false) {
			$data = substr($getpage, strpos($getpage, "\n~data~\n"));
			$oldcontent = substr($getpage, 0, strpos($getpage, "\n~data~\n"));
			}
		else $oldcontent = $getpage;
		}
	if ($newdata != '') $data = $newdata;  // newdata must already be formatted...
	if ($newcontent != '') {
		$newcontent = BOLTsafetext($newcontent, $page);
		if ($anchor != '') {
			if (strpos($oldcontent, $anchor) === false) $content = $oldcontent . "\n$anchor\n" . $newcontent;
			else {
				$before = substr($oldcontent, 0, strpos($oldcontent, $anchor));
				$after = substr($oldcontent, strpos($oldcontent, $anchor) + strlen($anchor));
				if (strpos($after, "[[#") !== false) $after = substr($after, strpos($after, "[[#"));
				else $after = '';
				$content = $before . $anchor . $newcontent . "\n" . $after;
				}
			}
		else $content = $newcontent;
		if ($content == ' ') $content = '';
		}
	else $content = $oldcontent;
	$fpage = BOLTfolders($page);
	if ($content != $oldcontent) {
		if (substr($content, -8) == "\n~data~\n") $content = substr($content, 0, -8); // is this necessary?
		if ($conflict != '' && file_exists("pages/$fpage")) {
			$lastmodified = filemtime("pages/$fpage") + BOLTconfig('localTime', 0) * 3600;
			if ($conflict < $lastmodified) {
				$out = "<box>\n" . 'Page $1 has been modified by another user and their changes may have been overwritten. Click [[$1&action=undo|undo]] to view changed content.' . "\n</box>\n\n";
				$out = str_replace('$1', $page, $out);
				$content = $out . $content;
				}
			}
		}
	if (substr($page, 0, 5) !== 'cache' && substr($page, 0, 4) !== 'site') $BOLTindexPages[] = $page;
	$BOLTpageStore[$page] = $content.$data;
	BOLTwrite("pages/$fpage", $content.$data);
	clearstatcache();
	}

function BOLTsearchPageList($args, $zone='', $auth=true) {
## SYSTEM FUNCTION USED TO GENERATE STARTING ARRAY OF PAGE NAMES BASED ON PARAMETERS: PAGES, PATTERN, GROUP, DIR
	if (isset($args['pages'])) return explode(',', BOLTcsv($args['pages']));
	if (isset($args['dir'])) $dir = $args['dir'];
	if (isset($args['pattern'])) $pat = $args['pattern'];
	elseif (isset($args['group'])) {
		$group = strtolower(BOLTutf2url($args['group']));
		$namespat = '-_a-zA-Z0-9%';
		if (strpos($group, ',') !== false) $patparts = explode(',', $group);
		else $patparts = Array($group);
		foreach ($patparts as $p) {
			if (strpos($p, '*') !== false || strpos($p, '+') !== false) {
				if (preg_match("/^[$namespat.*]$/", $p) === false) return Array();
				$p = str_replace('.', '\.', $p);
//				$p = str_replace(',', '|', $p);
				$p = str_replace('*', "[$namespat\.]*", $p);
				$p = str_replace('+', "[$namespat]*", $p);
				$patpart[] = "$p";
				}
			else $patpart[] = str_replace('.', '\.', $p) . "\.[$namespat]+";
			$pat = '/^(' . implode($patpart, '|') . ')$/';
			}
		}
	$outarray = BOLTlistpages($pat, $dir, $args);
	if ($auth == true && is_array($outarray)) {  // checks view permissions
		global $BOLTid;
		foreach ($outarray as $i => $ii) {
			if (BOLTauth($ii, $BOLTid, 'view') === false) unset($outarray[$i]);
			}
		}
	if (! is_array($outarray)) return Array();
	return $outarray;
	}

function BOLTsearchResults($outarray, $args=[]) {
## THIS FUNCTION REFINES YOUR SEARCH USING PARAMETERS: INCLUDE, EXCLUDE, TYPE, SORT, ORDER, WHEN, COUNT
	if (function_exists('myBOLTsearchResults')) return myBOLTsearchResults($outarray, $args);
	if (count($outarray) == 0 && $args['include'] == '') return;
	$outarray = array_unique($outarray);
	if ($args['exclude'] == '') $args['exclude'] = BOLTconfig('searchExclude');
	if ($args['exclude'] != '') {
		$exclude = BOLTutf2url($args['exclude']);
		$e = explode(",", $exclude);
		foreach ($e as $ee) {
			if (substr($ee, -1) == '*') {
				$ee = substr($ee, 0, - 1);
				foreach ($outarray as $p => $page) {
					$base = substr($page, 0, strlen($ee));
					if ($ee == $base || strtolower($ee) == $base) unset($outarray[$p]);
					}
				}
			elseif (in_array($ee, $outarray) || in_array(strtolower($ee), $outarray)) unset($outarray[array_search($ee, $outarray)]);
			}
		}
	if ($args['type'] == '') $args['type'] = BOLTconfig('searchType');
	else {
		$type = strtolower(BOLTutf2url($args['type']));
		if (substr($type, 0, 1) == '-') {
			$type = substr($type, 1);
			$keep = false;
			}
		else $keep = true;
		$typeFunc = 'myBOLTtype' . $type;
		if (function_exists($typeFunc)) $outarray = $typeFunc($outarray, $args, $keep);
		elseif ($type == 'number') {
			foreach ($outarray as $p => $page) {
				$page = substr($page, strrpos($page, '.') + 1);
				$page = str_replace('-', '', $page);
				if (is_number($page) != $keep) unset($outarray[$p]);
				}
			}
		else {
			$type = ',' . $type . ',';
			foreach ($outarray as $p => $page) {
				if (strpos($page, '.') !== false) $page = ',' . substr($page, strrpos($page, '.') + 1) . ',';
				else $page = ',' . $page . ',';
				if ($keep && strpos($type, $page) === false) unset($outarray[$p]);
				elseif (! $keep && strpos($type, $page) !== false) unset($outarray[$p]);
				}		
			}
		}
	if (count($outarray) == 0 && $args['include'] == '') return;
	if (isset($args['include'])) {
		$include = strtolower(BOLTutf2url($args['include']));
		$outarray = array_merge($outarray, explode(',', $include));
		}
	$outarray = array_unique($outarray);
	if ($args['unique'] == 'true') $outarray = array_unique($outarray);
	if ($args['shuffle'] == 'true') shuffle($outarray);
	else {
		if ($args['sort'] == '') natcasesort($outarray);
		elseif ($args['sort'] != 'false') $outarray = BOLTsearchResultsSort($outarray, $args);
		if ($args['order'] != '') {
			if ($args['order'] == 'reverse' xor $args['sort'] == 'lastmodified') $outarray = array_reverse($outarray);
			if ($args['order'] == 'random') shuffle($outarray);
			}
		}
	if ($args['when'] != '') $outarray = BOLTsearchResultsWhen($outarray, $args);
	if ($args['count'] != '') $outarray = BOLTsearchResultsCount($outarray, $args);
	return $outarray;
	}

function BOLTsearchResultsCount($outarray, $args) {
## USED TO PROCESS WHEN & COUNT AFTER HAS BEENS SORTED
	if ($args['count'] == 'false') return $outarray;
	$count = true;
	$start = 0;
	$end = $args['count'];
	if (strpos($end, '-') !== false) {
		$start = substr($end, 0, strpos($end, '-')) - 1;
		$end = intval(substr($end, strpos($end, '-') + 1)) - $start;
		}
	if (is_number($start) && is_number($end)) return array_slice($outarray, $start, $end);
	return $outarray;
	}

function BOLTsearchResultsSort($outarray, $args) {
## SYSTEM FUNCTION WHICH SORTS AN ARRAY BASED ON SORT PARAMETER. SPECIAL HANDLING OF LASTMODIFIED, AND PAGENAMES FOR SPEED. ELSE USES INDEX IF BY A DATA VARIABLE.  ALSO HANDLES THE INCLUDE, EXCLUDE, TYPE, ORDER (REVERSE,RANDOM) PARAMETER, IF, AND COUNT PARAMETERS
   $s = $args['sort'];
	$sortFunc = "myBOLTsort$s";
	if (function_exists($sortFunc))	return $sortFunc($outarray, $args);
	$sortFunc = 'myBOLTsort' . BOLTconfig('language');
	if (function_exists($sortFunc)) return $sortFunc($outarray, $args);	
	$q = $args['query'];
	if ($s == 'lastmodified') $s = '{+lastmodified}';
	foreach ($outarray as $p => $page) {
		$ss = $s;
		if ($q != '') {
			$ss = str_replace('{+field}', $page, $ss);
			if (strpos($ss, "{+value}") !== false) $ss = str_replace('{+value}', BOLTinfoVar($q, $page), $ss);
			if (strpos($ss, '{+') !== false) $ss = preg_replace_callback('/\{\+\#?([0-9]+)\}/', function($m) use ($q, $page) { return BOLTvars("$q::$page::$m[1]"); }, $ss);
			}
		$sortarray[$page] = BOLTdisplayReplace($ss, $p, $outarray, $args['dir']);
		}
	if ($s == '{+lastmodified}') arsort($sortarray);
	else natcasesort($sortarray);
	return array_keys($sortarray);
	}

function BOLTsearchResultsWhen($outarray, $args) {
## USED TO PROCESS WHEN & COUNT AFTER HAS BEENS SORTED
	$start = 0;
	$end = $args['count'];
	if ($end != '' && $end != 'false') {
		$count = true;
		if (strpos($end, '-') !== false) {
			$start = substr($end, 0, strpos($end, '-')) - 1;
			$end = intval(substr($end, strpos($end, '-') + 1)) - $start;
			}
		}
	$when = $args['when'];
	if ($when != '') {
		$when = str_replace('{++', '{+', $when);
		$q = BOLTinit($args['page'], $args['query']);
		$when = preg_replace('/\{\+([0-9]+)\}/', '{+#$1}', $when);
		$when = str_replace(Array('{+field}', '{+value}', '{+value::', '{+#'), Array('{+p}', '{'.$q.'::{+p}}', '{'.$q.'::{+p}::', '{'.$q.'::{+p}::'), $when);
		// deleted {+index} = $q from above. why would I need this?
		$when = str_replace('{+', '{', $when);
		foreach ($outarray as $p => $page) {
			$check = str_replace('{#}', $page, $when);
			$check = BOLTdomarkup($check, $page, '', 'vars,');
		
			if (BOLTiftrue($check, 'true') == 'true') {
				$new[] = $page;
				$i = $i + 1;
				}
			if ($count && $i > $start + $end - 1) break;
			}
		$outarray = $new;
		}
	if (! is_array($outarray)) return Array();
	return $outarray;
	}

function BOLTsecure() {
## THIS FUNCTION USED TO VERIFY FORM SECURITY AND SETS UP BOLTARRAY
	global $pageLink, $BOLTsession, $BOLTcommands;
	$key = $_POST['boltkey'];  // Key used to identify form
	$form = BOLTformOut($key); // retrieve form data
	if ($form === false) return; // Valid form not found
	$BOLTcommands = $form['COMMAND']; //Move from session to $BOLTcommands var
	$BOLTinputs = $form['INPUT']; // Attrs for filtering POST inputs
	if (is_array($_FILES)) {
		foreach ($_FILES as $i => $ii) $_POST[$i] = BOLTfilter($_FILES[$i]['name'], 'uploads');
		}
	foreach ($_POST as $f => $v) {
		if (is_array($v)) {
			$join = BOLTinit(',', $BOLTinputs[$f.'[]']['join']);
			if ($join != 'false') $_POST[$f] = implode($join, $v); // Multiple checkboxes
			}
		}
	foreach ($BOLTinputs as $field => $args) {  // Prepare post values 
		if (substr($field, -2) == '[]') $field = substr($field, 0, -2);
		$value = $_POST[$field];
		$value = str_replace(array("\r\n", "\r"), "\n", $value);
		if (is_array($args)) {
			$value = BOLTsecureFilter($field, $value, $args);
			if ($value == '~~ABORT~~') {
				$BOLTcommands[$field] = '~~ABORT~~';
				return;
				}
			}		
		$_POST[$field] = $value;
		}
	$BOLTsession['PASSFORM']['submit'] = $_POST['submit'];
	return $BOLTcommands;
	}

function BOLTsecureFilter($field, $value, $args) {
## SOME BASIC CHECKS AND HANDLING OF FORM INPUT VALUES
	if (function_exists('myBOLTsecureForm')) return myBOLTsecureForm($field, $value, $args);
	if ($args['replace'] == 'true') $value = preg_replace_callback('/\{\=([=\:\\w]+)\}/', function($m) { return BOLTstripQuotes(BOLTfieldreplace($m[1])); }, $value);
	if ($args['required'] == 'true') {
		if ($args['type'] == 'upload') {
			if ($_FILES[$field]['size'] == 0) {			
				BOLTmessage("input_upload", $args, $args['msg']);
				return '~~ABORT~~';
				}
			}
		elseif ($value == '') {
			BOLTmessage("input_required::$field", $args, $args['msg']);
			return '~~ABORT~~';
			}
		}
	if ($args['filter'] != '' && BOLTfilter($value, $args['filter']) == '') {
		BOLTmessage("input_filter::$field", $args, $args['msg']);
		return '~~ABORT~~';
		}
	if ($args['if'] != '') {
		$if = preg_replace_callback('/\{\=([=\:\\w]+)\}/', function($m) { return BOLTstripQuotes(BOLTfieldreplace($m[1])); }, $args['if']);
		if (BOLTiftrue($if, 'true') != 'true')  {
			BOLTmessage("input_if::$field", $args, $args['msg']);
			return '~~ABORT~~';
			}
		}
	if ($args['case'] != '') {
		switch ($args['case']) {
			case 'upper': $value = strtoupper($value); break;
			case 'lower': $value = strtolower($value); break;
			case 'initial': $value = ucfirst(strtolower($value)); break;
			case 'words': $value = ucwords(strtolower($value)); break;
			}
		}
	if ($args['lines'] != '') {
		if ($args['lines'] == 'false') $value = str_replace("\n", '\n', $value); // condense
		if ($args['lines'] == 'true') $value = str_replace('\n', "\n", $value); // expand
		}
	if ($args['strip'] == 'true') {  // pretty much all markup
		$value = BOLTstrip($value);
		}
	if ($args['trim'] != '') {
		switch ($args['trim']) {
			case 'right': $value = rtrim($value, $args['mask']); break;
			case 'left': $value = ltrim($value, $args['mask']); break;
			case 'true': $value = trim($value); break;
			default: $value = trim($value, BOLTinit($args['trim'], $args['mask']));
			}
		}
	if ($args['csv'] == 'true') {
		$value = str_replace("\n", ',', $value);
		$value = BOLTcsv($value, $args['current']);
		}
	if ($args['crypt'] == 'true' && $value != '') $value = BOLTcrypt($value);
	if ($args['timestamp'] == 'true') $value = strtotime($value);		
	return $value;
	}

function BOLTskinLoad() {
	global $skinPath, $BOLTskin, $boltwire;
	$file = "code.skin.$BOLTskin.html";	
	$out = BOLTloadpage($file);
	if ($out == '') {
		$out = file_get_contents("$skinPath/$BOLTskin/$file");
		if ($out == '') $out = file_get_contents("$boltwire/shared/skins/$BOLTskin/$file");
		if ($out == '') return;
		if (BOLTconfig('localSkins') == 'true') BOLTsavepage($file, $out);
		}
	return $out;
	}

function BOLTskinResource($resource) {
	global $skinPath, $BOLTskin, $boltwire;
	$args = BOLTargs($resource);
	$type = $args[1];
	$content = $args[2];
	if ($args['if'] != '') {
		$args['if'] = preg_replace_callback('/\{\+([-_a-z0-9:]+)\}/i', function($m) { return BOLTescape(BOLTvars($m[1]), false); }, $args['if']);  //
		if (BOLTiftrue($args['if'], 'true') != 'true') return;
		}	
	switch ($type) {
		case 'code': 
		   $parts = explode('.', $content);
		   if ($parts[0] != 'code') return;
		   return BOLTloadpage($content);
		case 'function':
			$func[1] = substr($resource, 9);
			return BOLTMfunc($func);
		case 'text':
			if ($args['markup'] == 'true') return BOLTdomarkup($content, '', '', $args['rules']); 
			return $content;
		case 'markup':
			$out = BOLTloadpage($content);	
			return BOLTdomarkup($out, '', '', $args['rules']);
		case 'cache':
			$out = BOLTcache("code.cache.$content");
			if ($out == '') {
				$out = BOLTloadpage($content);	
				$out = BOLTdomarkup($out, '', '', $args['rules']);
				if (is_number($args['expires'])) $expires = $BOLTtime + $args['expires'];
				BOLTcacheSave("code.cache.$content", $expires, BOLTescape($out, false));
				}
			return $out;
		}
	}

function BOLTskinSettings($var, $skin=true) {
## RETRIEVES DATA FROM CODE.SETTINGS PAGE TO FILL {VARS} MARKUPS IN YOUR SKIN, OR REGULAR PAGES.
	if (function_exists('myBOLTskinSettings')) return myBOLTskinSettings($var, $skin);
	global $BOLTzone, $BOLTcssPrefix, $BOLTskinSettingsCache, $myBOLTskinVar;
	if (isset($BOLTskinSettingsCache[$var])) return $BOLTskinSettingsCache[$var];
	$zone = BOLTinit('SKIN', $BOLTzone);
	$out = BOLTinfoVar('code.settings', "$BOLTcssPrefix_$var", '', false);
	if ($out == '') $out = BOLTinfoVar('code.settings', $var, '', false);
	if ($out != '') $out = BOLTdomarkup($out, '', $zone); // should reflect local zones too?
	if ($out == '') {
		if (inlist($var, 'skin,script,shared,field,files,domain')) $out = BOLTvars($var);
		elseif (isset($myBOLTskinVar[$var])) $out = $myBOLTskinVar[$var];
		}
	$BOLTskinSettingsCache[$var] = $out;
	return $out;
	}

function BOLTstrip($value) {
## USED TO STRIP MARKUP AND SOME CHARS FROM TEXT. USED IN SECUREFILTER AND VARCACHE (FOR TITLES)
	$value = preg_replace('/\{(.*?)\}/', '', $value);
	$value = preg_replace('/\[(.*?)\]/', '', $value);
	$value = preg_replace('/\<(.*?)\>/', '', $value);
	$value = preg_replace('/^!+/', '', $value);
	$value = str_replace(Array('#', '*', '/', '<', '>', '@', '[', '\\', ']', '^', '_', '{', '|', '}', '~', '++', '----', '->', '<-'), '', $value);
	$value = str_replace(Array("\n", "\t"), ' ', $value);
	$value = trim($value);
	return $value;
	}

function BOLTstripQuotes($x) {
## A UTILITY FUNCTION TO STRIP SINGLE AND DOUBLE QUOTES FROM A TEXT IF AT BEGINNING AND END OF THE STRING ONLY
	if (strpos($x, ' ? ') !== false) return $x;  // this is used for if commands
	if (substr($x, 0, 1) == "'" && substr($x, -1) == "'") $mark = "'";
	if (substr($x, 0, 1) == '"' && substr($x, -1) == '"') $mark = '"';
	if ($mark == '') return $x;
	if (strpos(substr($x, 1, -1), $mark) === false) return substr($x, 1, -1);
	return $x;
	}

function BOLTstripSlashes($x) {
## A UTILITY FUNCTION TO STRIP OUT SLASHES ADDED BY PREG_REPLACE
	$r1 = Array('\"', "\\'"); //, '\{');
	$r2 = Array('"', "'"); //, '{');  
	return str_replace($r1, $r2, $x);
	}

function BOLTthread($g, $info=false) {
## THIS FUNCTION RETURNS THE NEXT AVAILABLE THREAD NUMBER FOR A PAGE OR INFO VAR
	$BOLTthreadStart = BOLTconfig('threadStart', 1000);
	$e = $BOLTthreadStart - 1;
	if ($info) {
		$content = BOLTloadcontent($g, false);  // first load up info array
		if ($content != '') {
			$lines = explode("\n", $content);
			foreach ($lines as $i => $line) $pages[] = substr($line, 0, strpos($line, ': '));
			}
		}
	else {
		$dir = BOLTfolders($g);
		$dir = 'pages/' . substr($dir, 0, strrpos($dir, '/'));
		$pages = BOLTlistpages("/^$g\\.\\d/", $dir);
		}
	if (is_array($pages)) {
		foreach($pages as $page) {
			if (strpos($page, '.') !== false) $page = substr($page, strrpos($page, '.') + 1);
			if (preg_match('/^[0-9]+$/', $page) == 0) continue;
			$e = max($e, $page);
			}
		}
	$e = $e + 1;
	return $e;
	}

function BOLTtranslate($text, $language='', $reverse=false, $case='') {
## THE TRANSLATION ENGINE IN BOLTWIRE FOR SWITCHING KEY PHRASES TO YOUR CHOICE OF LANGUAGE OR BACK
	if (function_exists('myBOLTtranslate')) return myBOLTtranslate($text, $language, $reverse, $case);
	global $BOLTlanguage, $BOLTlanguageCase, $BOLTlanguageArray;
	$language = BOLTinit(BOLTconfig('language'), $BOLTlanguage, $language);
	if ($language == '') return $text;
	$case = BOLTinit('true', $BOLTlanguageCase, $case);
	$text = BOLTescape($text, false);
	if (empty($BOLTlanguageArray[$language])) {
		if (BOLTexists("site.language.$language")) $content = BOLTloadpage("site.language.$language");
		if ($content == '') return $text;
		if ($case == 'true') $content = mb_convert_case($content, MB_CASE_LOWER, 'UTF-8');
		preg_match_all('/^(.+) \:\: (.+)?/m', $content, $matches);
		$BOLTlanguageArray[$language] = array_combine($matches[1], $matches[2]);
		}
	if ($case == 'true') $id = mb_convert_case($text, MB_CASE_LOWER, 'UTF-8');
	else $id = $text;
	if ($reverse == true) $out = array_search($id, $BOLTlanguageArray[$language]);
	else $out = $BOLTlanguageArray[$language][$id];
	if ($out == '') return $text;
	if ($case == 'false') return $out;
	if ($text == strtoupper($text)) return mb_convert_case($out, MB_CASE_UPPER, 'UTF-8');
	if ($text == ucwords($text)) return mb_convert_case($out, MB_CASE_TITLE, 'UTF-8');
	if ($text == ucfirst($text)) return mb_convert_case(mb_substr($out, 0, 1), MB_CASE_UPPER, 'UTF-8') . mb_substr($out, 1);
	return $out;
	}

function BOLTtrimQuotes($text) {
## A UTILITY FUNCTION TO STRIP OUT ' AND " IF AT BEGINNING AND END OF STRING
	if (substr($text, 0, 1) == "'" && substr($text, -1) == "'") $text = substr($text, 1, -1);
	if (substr($text, 0, 1) == '"' && substr($text, -1) == '"') $text = substr($text, 1, -1);
	return $text;
	}

function BOLTtrimLines($text) {
## A UTILITY FUNCTION TO GET RID OF UNWANTED LINE RETURNS FROM CERTAIN BLOCK ELEMENTS
	if (substr($text, 0, 1) == "\n") {
		if (strpos($text, '!') != 1 && strpos($text, '->') !== 1 && strpos($text, '-&gt;') !== 1) $text = substr($text, 1);
		}
	if (substr($text, -1) == "\n") {
		if (substr($text, -2, 1) != '!' && substr($text, -3, 2) != '->' && substr($text, -6, 5) != '&lt;-') $text = substr($text, 0, -1);
		}
	return $text;
	}

function BOLTurl2utf ($x) {
## THIS FUNCTION RESTORES UTF8 PAGENAME FROM BOLTWIRE URL. 
	global $BOLTutfEscape;
	if (strpos($x, '%') === false) return $x;
	$x = strtr($x, $BOLTutfEscape);
	$x =  urldecode($x);
	return $x;
	}

function BOLTutf2url ($x) {
## THIS FUNCTION CONVERTS UTF8 PAGENAME TO AN ACCEPTABLE BOLTWIRE URL.
	global $BOLTutfEscape;
	$x = urlencode($x);
	$x = strtr($x, $BOLTutfEscape);
	return $x;
	}

function BOLTvars($var, $auth=true) {
## THIS FUNCTION RETRIEVES A PAGE VARIABLE, CREATING FOR A CACHE IF ONE DOESN'T EXIST
	global $BOLTvar, $pageLink, $BOLTid;
	if (strpos($var, '*:') !== false) {  // Vars from stamped pages
		if (strpos($var, '*::') === false) {
			$field = substr($var, strpos($var, '*:') + 1);
			$page = substr($var, 0, strpos($var, '*:'));
			if (isset($BOLTvar['*'][$page][$field])) return $BOLTvar['*'][$page][$field];
			BOLTvarCache($field, $page, 'stamps');
			return $BOLTvar['*'][$page][$field];
			}
		}
	$var = strtolower(BOLTpageshortcuts($var));
	if (strpos($var, '::') !== false) {  // Info vars
		$page = substr($var, 0, strpos($var, '::'));
		if ($page == '') $page = $pageLink;
		$field = substr($var, strpos($var, '::') + 2);
		return BOLTinfoVar($page, $field, '', $auth);
		}
	if (strpos($var, ":") === false) {  // System vars
		if (isset($BOLTvar[$var])) return $BOLTvar[$var];
		if (BOLTskinSettings($var) != '') return BOLTskinSettings($var); // special skin setting variable...		
		$page = $pageLink;
		$field = $var;
		}
	else {  // Data Vars
		$page = substr($var, 0, strpos($var, ":"));
		$field = substr($var, strpos($var, ":"));
		if (strpos(substr($field, 1), ':') !== false) { // info parts
			$part = substr($field, strrpos($field, ':') + 1);
			$field = substr($field, 0, strrpos($field, ':'));
			}
		if ($auth && ! BOLTauth("$page$field", $BOLTid, 'data')) return;
		if (inlist($field, ":p,:page,:title,:data,:parent,:parents,:p0,:p1,:p2,:p3,:p4,:p5,:p6,:p7,:p8,:p9")) $field = substr($field, 1); 
		if ($page == '') $page = $pageLink;
		}
	if (is_array($BOLTvar['#'][$page])) $out = $BOLTvar['#'][$page][$field]; 
	else {
		BOLTvarCache($field, $page, '', $auth);
		$out = $BOLTvar['#'][$page][$field]; 
		}
	if (is_number($part)) {
		$out = explode(' | ', $out);
		return $out[$part - 1];
		}
	return $out;
	}

function BOLTvarCache($field, $page, $dir='', $auth=true) {  // no need for $field parameter
## THIS FUNCTIONS CREATES A FULL SET OF PAGE VARIABLES FOR A GIVEN PAGE AND CACHES THEM	
	global $BOLTvar, $pageArray, $BOLTid, $systemPath;
	$page2 = BOLTurl2utf($page);
	$tempArray = explode(".", $page2);
	$BOLTvar['#'][$page]['p0'] = count($tempArray);
	foreach ($tempArray as $i => $ii) {
		$index = "p" . ($i + 1);
		$BOLTvar['#'][$page][$index] = $ii;
		}
	$BOLTvar['#'][$page]['p'] = $page2;
	$BOLTvar['#'][$page]['page'] = $ii;
	$BOLTvar['#'][$page]['parent'] = $tempArray[$i - 1];
	$BOLTvar['#'][$page]['parents'] = substr($page,0,strrpos($page2,'.'));
	if (BOLTexists($page, $dir)) {
		$d = BOLTloadpage($page, $dir, 'data', $auth);
		$d = str_replace(Array('<', "'", '"'), Array('&lt;', '&apos;', '&quot;'), $d);
		if (strpos($d, "\n~data~\n") !== false) {
			$d = substr($d, strpos($d, "\n~data~\n") + 8);
//			$d = BOLTsafetext($d);
			$d = explode("\n~\n", $d);
			foreach ($d as $line) {
				if (strpos($line, ": ") === false) continue;
				$f = strtolower(BOLTutf2url(substr($line, 0, strpos($line, ": "))));
				$v = substr($line, strpos($line, ": ") + 2);
				if (($f == '') || ($v == '')) continue;
				if ($auth && BOLTexists('site.auth.data') && ! BOLTauth("$rpage:$f", $BOLTid, 'data')) continue;
				$v = str_replace('&#126;', '~', $v);
				$v = str_replace('&amp;', '&', $v);
				if (inlist($f, BOLTconfig('safeData'))) $v = BOLTstrip($v);
				if (BOLTconfig('escapeTitle') == 'true' && $f == 'title') $v = BOLTescape($v);
				if ($dir == 'stamps') $BOLTvar['*'][$page][":$f"] = $v;
				$BOLTvar['#'][$page][":$f"] = $v;
				$flist[] = $f;
				}
			}
		if (is_array($flist)) $BOLTvar['#'][$page]['data'] = BOLTurl2utf(implode(',', $flist));
		}

	if (isset($BOLTvar['#'][$page][':title'])) $BOLTvar['#'][$page]['title'] = $BOLTvar['#'][$page][':title'];
	else {
		if (BOLTurl2utf($BOLTvar['#'][$page]['page']) != $BOLTvar['#'][$page]['page']) $BOLTvar['#'][$page]['title'] = BOLTurl2utf($BOLTvar[$page]['page']);
		else $BOLTvar['#'][$page]['title'] = ucwords($BOLTvar['#'][$page]['page']);
		}
	return;
	}

function BOLTvspace($text) {
	if (BOLTconfig('vSpacing', 'true') == 'false') return $text;
	if (strpos($text, "\n") === false) return $text;
	$text = preg_replace_callback('/<nolines>(.*)<\/nolines>/Usi', function($m) { return BOLTescape(BOLTstripSlashes($m[1]), true, true); }, $text);
	$text = preg_replace_callback('/<(h[1-6]|blockquote|div|th|td|fieldset|legend)([^>\n]*)>(.*)<\/\1>/Uis', function($m) { return BOLTvspaceBlock($m[3], $m[1], $m[2]); }, $text);
	$text = preg_replace_callback('/(<table.+\/table>)/Usi', function($m) { return BOLTescape(BOLTstripSlashes($m[1], true, true)); }, $text);
	$text = str_replace('<p></p>', '', $text);
	$text = BOLTtrimLines($text);
	if (strpos($text, "\n\n") === false) $nowrap = true;
	$paragraphs = explode("\n\n", $text);
	foreach ($paragraphs as $p => $pp) {
		if (strpos($pp, "\n") !== false) {
			$lines = explode("\n", $pp);
			foreach($lines as $l => $ll) {
//				$ll = BOLTescape($ll, false);
				if(BOLTvspaceCheck($ll)) $lines[$l] = $ll . '<br />';
				else $lines[$l] = "$ll\n";
				}
			$pp = implode('', $lines);
			if (substr($pp, -6) == '<br />') $pp = substr($pp, 0, -6);				
			}
		if (BOLTvspaceCheck($pp)) $paragraphs[$p] = "<p>$pp</p>";		
		if (strpos($out, "\n") !== false) {
			if (preg_match('/^~~([0-9]+)~~$/', $pp)) $paragraphs[$p] = "$pp<p />";
			}
		}
	$text = implode("\n\n", $paragraphs);
	if ($nowrap) {
		if (substr($text, 0, 3) == '<p>' && substr($text, -4) == '</p>') $text = substr($text, 3, -4);
		}
	$text = str_replace('<p></p>', '', $text);
	return $text;
	}

function BOLTvspaceBlock($text, $type, $attr) {
	$text = BOLTstripSlashes(BOLTtrimLines($text));
	if (strpos($attr, "class='code'") == false) $text = BOLTvspace($text);
	if (substr($type, 0, 1) == 'h' || $type == 'legend') $end = "\n";
	return BOLTescape("<$type$attr>$text</$type>", true, true) . $end;
	}

function BOLTvspaceCheck($text) {
## FUNCTION USED TO TELL WHETHER A LINE OF TEXT SHOULD BE GIVEN PARAGRAPH OR LINEBREAK MARKS, OR LEFT ALONE
	if (strpos($text, "\n") !== false) return;
	$text = str_replace(Array('&lt;', '&gt;'), Array('<', '>'), $text);
	if (preg_match('/^<br \/>(\n<br \/>){0,}$/', $text) == 1) return;
	if (strpos(',</div>,<hr />,</p>,<br />,</blockquote>,', ",$text,") !== false) return;
	if (preg_match('/^<(p|div|blockquote|ul|ol|h[1-6])([^>\n]*)>((.*)<\/\1>)?$/s', $text) == 1) return;
	if (preg_match('/^(<\/?(table|tr|th|td)([^>]*)>)+$/', $text) == 1) return; 
	if (preg_match('/^\[(form|session)[^\]]*\]$/', $text) == 1) return;
	if (preg_match('/^(~~([0-9]+)\*~~\n?)+$/', $text) == 1) return;
	if ($text == '[results]' || $text == '[messages]' || $text == '<hr />') return;
	return true;
	}